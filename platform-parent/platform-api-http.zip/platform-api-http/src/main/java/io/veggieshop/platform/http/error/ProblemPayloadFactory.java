package io.veggieshop.platform.http.error;

import io.veggieshop.platform.domain.error.ProblemTypes;
import io.veggieshop.platform.domain.error.ProblemTypes.ProblemType;
import io.veggieshop.platform.domain.error.VeggieException;
import io.veggieshop.platform.domain.tenant.TenantContext;
import io.veggieshop.platform.domain.tenant.TenantId;
import io.veggieshop.platform.http.filters.CorrelationIdFilter;
import io.veggieshop.platform.http.filters.PiiLogGuardFilter;
import org.slf4j.MDC;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpServletRequest;
import java.net.URI;
import java.time.Instant;
import java.util.*;

/**
 * ProblemPayloadFactory
 *
 * Factory for RFC 7807 Problem+JSON payloads.
 * - No PII echoing; enrich with safe context (trace/request/correlation/tenant).
 * - Stable contract: type, title, status, detail, instance + extensions:
 *   problemCode, traceId, spanId, requestId, correlationId, tenantId, timestamp, errors.
 */
@Component
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public final class ProblemPayloadFactory {

    /**
     * Build a ProblemDetail from a VeggieException or a generic Throwable.
     * The provided {@code status} is authoritative (handlers decide mapping).
     */
    public ProblemDetail fromException(
            @NonNull HttpServletRequest request,
            @NonNull HttpStatus status,
            @NonNull Throwable ex
    ) {
        ProblemType type = null;
        String detail = safeDetail(ex);

        if (ex instanceof VeggieException ve) {
            type = extractProblemType(ve);
            if (ve.getMessage() != null && !ve.getMessage().isBlank()) {
                detail = ve.getMessage();
            }
        }

        return build(request, status, type, detail, /*problemCode*/ null, /*errors*/ null);
    }

    /**
     * Build a ProblemDetail with explicit inputs.
     */
    public ProblemDetail build(
            @NonNull HttpServletRequest request,
            @NonNull HttpStatus status,
            @Nullable ProblemType type,
            @Nullable String detail,
            @Nullable String problemCode,
            @Nullable List<Map<String, Object>> errors // e.g. field violations [{field, message, code}]
    ) {
        // Base RFC7807 fields
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(status, safeDetail(detail));
        pd.setTitle(defaultTitle(status, type));
        pd.setType(safeType(type));
        pd.setInstance(URI.create(safeInstance(request)));

        // Enriched, non-PII context (stable keys across services)
        Map<String, Object> ctx = contextMap(request);
        ctx.forEach(pd::setProperty);

        // Optional problemCode override (else derive from ProblemTypes if present)
        String code = (problemCode != null && !problemCode.isBlank())
                ? problemCode
                : deriveProblemCode(type);
        if (code != null) {
            pd.setProperty("problemCode", code);
        }

        // Optional structured errors/violations (already sanitized upstream)
        if (errors != null && !errors.isEmpty()) {
            pd.setProperty("errors", errors);
        }

        return pd;
    }

    // =================================================================================================
    // Context & helpers
    // =================================================================================================

    private static String safeDetail(@Nullable Object msg) {
        String s = (msg == null ? null : String.valueOf(msg));
        return (s == null || s.isBlank()) ? "Request could not be processed." : s;
    }

    private static String defaultTitle(HttpStatus status, @Nullable ProblemType type) {
        // Prefer specific ProblemType title; else use HTTP reason phrase.
        return (type != null && type.title() != null && !type.title().isBlank())
                ? type.title()
                : status.getReasonPhrase();
    }

    private static URI safeType(@Nullable ProblemType type) {
        // Prefer canonical URI from ProblemType; else about:blank.
        return (type != null && type.uri() != null) ? type.uri() : URI.create("about:blank");
    }

    private static String deriveProblemCode(@Nullable ProblemType type) {
        if (type == null) return null;
        // Use the slug as a stable, machine-friendly code (kebab-case).
        return type.slug();
    }

    private static String safeInstance(HttpServletRequest req) {
        // RFC7807 'instance' is a URI reference. Keep it as a path to avoid leaking host/PII.
        String uri = req.getRequestURI();
        return (uri == null || uri.isBlank()) ? "/" : uri;
    }

    private static Map<String, Object> contextMap(HttpServletRequest request) {
        Map<String, Object> ctx = new LinkedHashMap<>(8);

        // Stable ids from MDC (populated by filters)
        putIfNonBlank(ctx, "traceId", MDC.get("traceId"));
        putIfNonBlank(ctx, "spanId", MDC.get("spanId"));
        putIfNonBlank(ctx, "requestId", MDC.get(CorrelationIdFilter.MDC_REQUEST_ID));
        putIfNonBlank(ctx, "correlationId", MDC.get(CorrelationIdFilter.MDC_CORRELATION_ID));

        // Tenant from context/MDC/header (non-PII)
        String tenant = TenantContext.currentTenantId().map(TenantId::value).orElse(null);
        if (tenant == null) tenant = MDC.get(TenantContext.MDC_TENANT_ID);
        if (tenant == null) {
            String raw = request.getHeader(TenantContext.REQUEST_HEADER);
            tenant = firstHeaderValue(raw);
        }
        putIfNonBlank(ctx, "tenantId", tenant);

        // Lightweight request context (no raw headers/params)
        ctx.put("timestamp", Instant.now().toEpochMilli());
        ctx.put("method", request.getMethod());
        ctx.put("path", safeInstance(request));

        // If the PII guard produced sanitized header/param views, attach tiny hints (counts only).
        @SuppressWarnings("unchecked")
        Map<String, ?> safeHeaders = (Map<String, ?>) request.getAttribute(PiiLogGuardFilter.ATTR_SANITIZED_HEADERS);
        if (safeHeaders != null) {
            ctx.put("headerCount", safeHeaders.size());
        }
        @SuppressWarnings("unchecked")
        Map<String, ?> safeParams = (Map<String, ?>) request.getAttribute(PiiLogGuardFilter.ATTR_SANITIZED_PARAMETERS);
        if (safeParams != null) {
            ctx.put("paramCount", safeParams.size());
        }

        return ctx;
    }

    private static void putIfNonBlank(Map<String, Object> map, String key, @Nullable String value) {
        if (value != null && !value.isBlank()) {
            map.put(key, value);
        }
    }

    private static String firstHeaderValue(@Nullable String raw) {
        if (raw == null) return null;
        int comma = raw.indexOf(',');
        return (comma >= 0 ? raw.substring(0, comma) : raw).trim();
    }

    private static ProblemType extractProblemType(VeggieException ve) {
        // Prefer strong accessor: ve.type()
        try {
            var m = ve.getClass().getMethod("type");
            Object v = m.invoke(ve);
            if (v instanceof ProblemType pt) return pt;
        } catch (ReflectiveOperationException ignored) { }
        // Fallback to getType()
        try {
            var m = ve.getClass().getMethod("getType");
            Object v = m.invoke(ve);
            if (v instanceof ProblemType pt) return pt;
        } catch (ReflectiveOperationException ignored) { }
        return null;
    }

    // ------------------------------------------------------------------------------------------------
    // Convenience builders for common cases
    // ------------------------------------------------------------------------------------------------

    /**
     * 400 Bad Request with structured field errors.
     * Each error entry may contain: {@code field}, {@code message}, and optional {@code code}.
     */
    public ProblemDetail badRequestWithErrors(
            @NonNull HttpServletRequest request,
            @Nullable ProblemType type,
            @NonNull List<Map<String, Object>> errors,
            @Nullable String detail
    ) {
        return build(request, HttpStatus.BAD_REQUEST, type, detail, null, errors);
    }

    /**
     * Minimal 500 Internal Server Error (no internal details leaked).
     */
    public ProblemDetail internalServerError(@NonNull HttpServletRequest request) {
        return build(request, HttpStatus.INTERNAL_SERVER_ERROR, null,
                "An unexpected error occurred.", null, null);
    }

    /**
     * 429 Too Many Requests helper. Caller may add {@link HttpHeaders#RETRY_AFTER} to the response.
     */
    public ProblemDetail tooManyRequests(@NonNull HttpServletRequest request, @Nullable String detail) {
        return build(request, HttpStatus.TOO_MANY_REQUESTS, null, detail, "RATE_LIMITED", null);
    }
}

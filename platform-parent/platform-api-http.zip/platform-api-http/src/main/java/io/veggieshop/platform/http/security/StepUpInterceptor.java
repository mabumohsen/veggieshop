package io.veggieshop.platform.http.security;

import io.veggieshop.platform.application.security.StepUpService;
import io.veggieshop.platform.domain.security.RiskLevel;
import io.veggieshop.platform.domain.tenant.TenantContext;
import io.veggieshop.platform.domain.tenant.TenantId;
import io.veggieshop.platform.domain.error.ProblemTypes;
import io.veggieshop.platform.domain.error.VeggieException;
import io.veggieshop.platform.http.filters.HmacAuthFilter;
import io.veggieshop.platform.http.filters.OidcJwtAuthFilter;
import io.veggieshop.platform.http.filters.TenantFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import java.lang.annotation.*;
import java.lang.reflect.Method;
import java.time.Clock;
import java.util.*;

/**
 * StepUpInterceptor
 *
 * Enforces "step-up" (MFA / stronger auth) for high-risk operations.
 */
@Component
@Order(StepUpInterceptor.ORDER)
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
public final class StepUpInterceptor implements HandlerInterceptor {

    /** Execute late in the preHandle chain, just before the controller. */
    public static final int ORDER = Ordered.LOWEST_PRECEDENCE - 150;

    // --- Configuration (system properties or env fallbacks) ---
    private static final long DEFAULT_MAX_AGE_SECONDS =
            Long.getLong("veggieshop.security.stepup.defaultMaxAgeSeconds", 300L); // 5 minutes

    private static final Set<String> MFA_AMR_HINTS =
            Set.of("mfa", "otp", "sms", "email", "hwk", "webauthn", "u2f", "totp");

    // --- Hint/contract headers ---
    private static final String HDR_WWW_AUTHENTICATE = "WWW-Authenticate";
    private static final String HDR_STEPUP_REQUIRED  = "X-Step-Up-Required";
    private static final String HDR_STEPUP_RISK      = "X-Step-Up-Risk";
    private static final String HDR_STEPUP_MAX_AGE   = "X-Step-Up-Max-Age";
    private static final String HDR_TENANT_ID        = TenantFilter.HEADER_TENANT_ID;

    private final StepUpService stepUpService;
    private final Clock clock = Clock.systemUTC();

    public StepUpInterceptor(StepUpService stepUpService) {
        this.stepUpService = Objects.requireNonNull(stepUpService, "StepUpService is required");
    }

    @Override
    public boolean preHandle(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull Object handler
    ) {
        RequireStepUp requirement = resolveRequirement(handler);
        if (requirement == null) {
            return true; // no step-up required for this handler
        }

        // ---- Resolve tenant (must be present; TenantFilter normally enforces this) ----
        TenantId tenant = TenantContext.currentTenantId().orElse(null);
        if (tenant == null) {
            String headerTenant = firstHeaderValue(request.getHeader(HDR_TENANT_ID));
            if (headerTenant == null || headerTenant.isBlank()) {
                throw VeggieException.builder(ProblemTypes.TENANT_REQUIRED)
                        .detail("Missing required header: " + HDR_TENANT_ID)
                        .captureStackTrace(false)
                        .build();
            }
            tenant = TenantId.of(headerTenant);
        }

        // ---- Resolve authenticated principal (OIDC or HMAC) ----
        PrincipalView principal = principalFromRequest(request)
                .orElseThrow(() -> unauthorized(response, "Missing authenticated principal"));

        // ---- Quick allow-list checks (roles/scopes) if configured on annotation ----
        if (matchesAny(principal.roles, requirement.anyRole()) ||
                matchesAny(principal.scopes, requirement.anyScope())) {
            return true;
        }

        // ---- Determine policy (risk + maxAge) ----
        RiskLevel risk = requirement.value();
        long maxAge = (requirement.maxAgeSeconds() > 0 ? requirement.maxAgeSeconds() : DEFAULT_MAX_AGE_SECONDS);

        // ---- Evaluate satisfaction: (1) AMR+auth_time, or (2) active elevation in store ----
        boolean amrSatisfied = looksLikeRecentMfa(principal.amr, principal.authTimeEpochSec, maxAge);
        boolean elevationSatisfied = stepUpService.activeElevation(tenant.value(), principal.subject).isPresent();

        if (amrSatisfied || elevationSatisfied) {
            return true; // step-up satisfied
        }

        // ---- Not satisfied → emit hints + fail with Problem+JSON (handled by our exception handler) ----
        attachHints(response, risk, maxAge);
        throw VeggieException.builder(ProblemTypes.STEP_UP_REQUIRED)
                .detail("Step-up authentication is required for this operation.")
                .captureStackTrace(false)
                .build();
    }

    // ================================================================================================
    // Requirement resolution
    // ================================================================================================

    private static RequireStepUp resolveRequirement(Object handler) {
        if (handler instanceof HandlerMethod hm) {
            RequireStepUp onMethod = hm.getMethodAnnotation(RequireStepUp.class);
            if (onMethod != null) return onMethod;
            Class<?> type = hm.getBeanType();
            return type.getAnnotation(RequireStepUp.class);
        }
        return null;
    }

    // ================================================================================================
    // Principal extraction (duck-typed from auth filters)
    // ================================================================================================

    private Optional<PrincipalView> principalFromRequest(HttpServletRequest request) {
        // OIDC attribute
        Object oidcAttr = request.getAttribute(OidcJwtAuthFilter.REQUEST_ATTR_PRINCIPAL);
        PrincipalView fromOidc = tryBuildPrincipal(oidcAttr, /*prefixIfKeyId*/ null);
        if (fromOidc != null) return Optional.of(fromOidc);

        // HMAC attribute
        Object hmacAttr = request.getAttribute(HmacAuthFilter.REQUEST_ATTR_PRINCIPAL);
        PrincipalView fromHmac = tryBuildPrincipal(hmacAttr, /*prefixIfKeyId*/ "hmac:");
        if (fromHmac != null) return Optional.of(fromHmac);

        return Optional.empty();
    }

    /**
     * Attempts to build a PrincipalView from either:
     *  - a Map-like object (keys: subject, roles, scopes, amr, authTime or authTimeEpochSec, keyId)
     *  - an object exposing methods subject()/roles()/scopes()/amr()/authTime() (Optional&lt;Long&gt; or Long)
     *  - an object exposing keyId() when subject is missing (for HMAC)
     */
    @SuppressWarnings("unchecked")
    private PrincipalView tryBuildPrincipal(Object attr, String keyIdPrefix) {
        if (attr == null) return null;

        String subject = null;
        Set<String> roles  = Set.of();
        Set<String> scopes = Set.of();
        Set<String> amr    = Set.of();
        Long authTime = null;

        if (attr instanceof Map<?, ?> map) {
            subject  = asString(map.get("subject"));
            roles    = toStringSet(map.get("roles"));
            scopes   = toStringSet(map.get("scopes"));
            amr      = toStringSet(map.get("amr"));
            authTime = asLong(map.get("authTime")).orElseGet(() -> asLong(map.get("authTimeEpochSec")).orElse(null));
            if (subject == null && map.get("keyId") != null && keyIdPrefix != null) {
                subject = keyIdPrefix + asString(map.get("keyId"));
            }
        } else {
            subject  = invokeString(attr, "subject").orElse(null);
            roles    = toStringSet(invoke(attr, "roles").orElse(null));
            scopes   = toStringSet(invoke(attr, "scopes").orElse(null));
            amr      = toStringSet(invoke(attr, "amr").orElse(null));
            // Optional<Long> or Long
            authTime = invokeOptionalLong(attr, "authTime").orElseGet(() -> invokeLong(attr, "authTimeEpochSec").orElse(null));
            if (subject == null && keyIdPrefix != null) {
                String keyId = invokeString(attr, "keyId").orElse(null);
                if (keyId != null) subject = keyIdPrefix + keyId;
            }
        }

        if (subject == null || subject.isBlank()) return null;
        return new PrincipalView(subject, roles, scopes, amr, authTime);
    }

    // ================================================================================================
    // Evaluation helpers
    // ================================================================================================

    private boolean looksLikeRecentMfa(Set<String> amr, Long authTimeEpochSec, long maxAgeSeconds) {
        if (amr == null || amr.isEmpty() || authTimeEpochSec == null) return false;
        boolean hasMfa = amr.stream().map(String::toLowerCase).anyMatch(MFA_AMR_HINTS::contains);
        if (!hasMfa) return false;

        long now = clock.instant().getEpochSecond();
        long age = Math.max(0, now - authTimeEpochSec);
        return age <= maxAgeSeconds;
    }

    private static boolean matchesAny(Set<String> bag, String[] requiredAny) {
        if (requiredAny == null || requiredAny.length == 0) return false;
        if (bag == null || bag.isEmpty()) return false;
        Set<String> lower = toLower(bag);
        for (String r : requiredAny) {
            if (r != null && lower.contains(r.toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        return false;
    }

    private static Set<String> toLower(Set<String> in) {
        if (in == null || in.isEmpty()) return Set.of();
        Set<String> out = new HashSet<>(in.size());
        for (String s : in) if (s != null) out.add(s.toLowerCase(Locale.ROOT));
        return out;
    }

    private static Set<String> safeSet(Set<String> in) {
        return (in == null ? Set.of() : Set.copyOf(in));
    }

    private static String firstHeaderValue(String raw) {
        if (raw == null) return null;
        int comma = raw.indexOf(',');
        return (comma >= 0 ? raw.substring(0, comma) : raw).trim();
    }

    private static VeggieException unauthorized(HttpServletResponse res, String msg) {
        res.setHeader(HDR_WWW_AUTHENTICATE,
                "Bearer error=\"insufficient_authentication\", error_description=\"step-up required\"");
        return VeggieException.builder(ProblemTypes.AUTHENTICATION_FAILED)
                .detail(msg)
                .captureStackTrace(false)
                .build();
    }

    private static void attachHints(HttpServletResponse res, RiskLevel risk, long maxAge) {
        res.setHeader(HDR_WWW_AUTHENTICATE,
                "Bearer error=\"insufficient_authentication\", error_description=\"step-up required\"");
        res.setHeader(HDR_STEPUP_REQUIRED, "true");
        res.setHeader(HDR_STEPUP_RISK, risk.name());
        res.setHeader(HDR_STEPUP_MAX_AGE, String.valueOf(maxAge));
    }

    // ================================================================================================
    // Local view model
    // ================================================================================================

    private static final class PrincipalView {
        final String subject;
        final Set<String> roles;
        final Set<String> scopes;
        final Set<String> amr;
        final Long authTimeEpochSec;

        PrincipalView(String subject, Set<String> roles, Set<String> scopes, Set<String> amr, Long authTimeEpochSec) {
            this.subject = Objects.requireNonNullElse(subject, "unknown");
            this.roles = safeSet(roles);
            this.scopes = safeSet(scopes);
            this.amr = safeSet(amr);
            this.authTimeEpochSec = authTimeEpochSec;
        }
    }

    // ================================================================================================
    // Reflection / coercion helpers (duck-typing)
    // ================================================================================================

    private static Optional<Object> invoke(Object target, String method) {
        try {
            Method m = target.getClass().getMethod(method);
            m.setAccessible(true);
            return Optional.ofNullable(m.invoke(target));
        } catch (Exception ignore) {
            return Optional.empty();
        }
    }

    private static Optional<String> invokeString(Object target, String method) {
        return invoke(target, method).map(StepUpInterceptor::asString);
    }

    private static Optional<Long> invokeLong(Object target, String method) {
        return invoke(target, method).flatMap(StepUpInterceptor::asLong);
    }

    private static Optional<Long> invokeOptionalLong(Object target, String method) {
        return invoke(target, method).flatMap(obj -> {
            if (obj instanceof Optional<?> opt) {
                return opt.map(StepUpInterceptor::asLong).orElse(Optional.empty());
            }
            return Optional.empty();
        });
    }

    private static String asString(Object o) {
        if (o == null) return null;
        if (o instanceof String s) return s;
        return String.valueOf(o);
    }

    @SuppressWarnings("unchecked")
    private static Set<String> toStringSet(Object o) {
        if (o == null) return Set.of();
        if (o instanceof Set<?> set) {
            Set<String> out = new LinkedHashSet<>();
            for (Object v : set) if (v != null) out.add(String.valueOf(v));
            return out;
        }
        if (o instanceof Collection<?> col) {
            Set<String> out = new LinkedHashSet<>();
            for (Object v : col) if (v != null) out.add(String.valueOf(v));
            return out;
        }
        if (o instanceof String s) {
            // Allow space or comma separated (common encodings)
            String[] parts = s.split("[,\\s]+");
            Set<String> out = new LinkedHashSet<>();
            for (String p : parts) if (!p.isBlank()) out.add(p);
            return out;
        }
        return Set.of(String.valueOf(o));
    }

    private static Optional<Long> asLong(Object o) {
        if (o == null) return Optional.empty();
        if (o instanceof Number n) return Optional.of(n.longValue());
        if (o instanceof String s) {
            try { return Optional.of(Long.parseLong(s)); } catch (NumberFormatException ignore) {}
        }
        return Optional.empty();
    }

    // ================================================================================================
    // Annotation to mark handlers that require step-up
    // ================================================================================================

    /**
     * Declares that the annotated controller class or handler method requires "step-up" authentication.
     */
    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.METHOD, ElementType.TYPE})
    public @interface RequireStepUp {
        RiskLevel value() default RiskLevel.HIGH;
        long maxAgeSeconds() default -1; // -1 → use interceptor default
        String[] anyRole() default {};
        String[] anyScope() default {};
    }
}

package io.veggieshop.platform.http;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.convert.DurationUnit;
import org.springframework.validation.annotation.Validated;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * Central configuration for VeggieShop HTTP layer (filters, guards & preconditions).
 * <p>
 * Prefix: veggieshop.http
 * <p>
 * This class is defined in platform-api-http (components only).
 * Auto-configuration & wiring happen in platform-starter-web.
 */
@Validated
@ConfigurationProperties(prefix = "veggieshop.http")
public class VeggieShopHttpProperties {

    /**
     * Master switch for the entire HTTP platform layer.
     */
    private boolean enabled = true;

    @Valid
    private final Tenant tenant = new Tenant();
    @Valid
    private final Correlation correlation = new Correlation();
    @Valid
    private final Hmac hmac = new Hmac();
    @Valid
    private final RateLimit rateLimit = new RateLimit();
    @Valid
    private final PiiLog piiLog = new PiiLog();
    @Valid
    private final Cors cors = new Cors();
    @Valid
    private final Consistency consistency = new Consistency();

    // ---------- Getters / Setters ----------
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public Tenant getTenant() {
        return tenant;
    }

    public Correlation getCorrelation() {
        return correlation;
    }

    public Hmac getHmac() {
        return hmac;
    }

    public RateLimit getRateLimit() {
        return rateLimit;
    }

    public PiiLog getPiiLog() {
        return piiLog;
    }

    public Cors getCors() {
        return cors;
    }

    public Consistency getConsistency() {
        return consistency;
    }

    // ---------- Nested types ----------

    /**
     * Tenant guard & MDC population.
     */
    public static class Tenant {
        private boolean enabled = true;

        /**
         * Header carrying the tenant id.
         */
        @NotBlank
        private String header = "X-Tenant-Id";

        /**
         * Whether the tenant header is required for non-public endpoints.
         */
        private boolean required = true;

        /**
         * MDC key to store the resolved tenant id.
         */
        @NotBlank
        private String mdcKey = "tenantId";

        /**
         * Ant-style patterns considered public (bypass tenant requirement).
         */
        @NotNull
        private List<@NotBlank String> publicPaths = new ArrayList<>(List.of(
                "/actuator/**", "/v3/api-docs/**", "/swagger-ui/**", "/health", "/metrics"
        ));

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getHeader() {
            return header;
        }

        public void setHeader(String header) {
            this.header = header;
        }

        public boolean isRequired() {
            return required;
        }

        public void setRequired(boolean required) {
            this.required = required;
        }

        public String getMdcKey() {
            return mdcKey;
        }

        public void setMdcKey(String mdcKey) {
            this.mdcKey = mdcKey;
        }

        public List<String> getPublicPaths() {
            return publicPaths;
        }

        public void setPublicPaths(List<String> publicPaths) {
            this.publicPaths = publicPaths == null ? new ArrayList<>() : publicPaths;
        }
    }

    /**
     * Correlation-ID generation/propagation.
     */
    public static class Correlation {
        private boolean enabled = true;

        @NotBlank
        private String header = "X-Correlation-Id";
        private boolean generateIfMissing = true;

        public enum Generator {UUID_V4, ULID}

        @NotNull
        private Generator generator = Generator.ULID;

        @NotBlank
        private String mdcKey = "correlationId";

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getHeader() {
            return header;
        }

        public void setHeader(String header) {
            this.header = header;
        }

        public boolean isGenerateIfMissing() {
            return generateIfMissing;
        }

        public void setGenerateIfMissing(boolean generateIfMissing) {
            this.generateIfMissing = generateIfMissing;
        }

        public Generator getGenerator() {
            return generator;
        }

        public void setGenerator(Generator generator) {
            this.generator = generator;
        }

        public String getMdcKey() {
            return mdcKey;
        }

        public void setMdcKey(String mdcKey) {
            this.mdcKey = mdcKey;
        }
    }

    /**
     * HMAC partner authentication.
     */
    public static class Hmac {
        private boolean enabled = false;

        @NotBlank
        private String signatureHeader = "X-Signature";
        @NotBlank
        private String keyIdHeader = "X-Key-Id";
        @NotBlank
        private String timestampHeader = "X-Timestamp";

        /**
         * e.g. HmacSHA256, HmacSHA512.
         */
        @NotEmpty
        private Set<@Pattern(regexp = "HmacSHA(256|384|512)") String> acceptedAlgorithms =
                new LinkedHashSet<>(List.of("HmacSHA256"));

        /**
         * Acceptable clock skew on timestamp header.
         */
        @DurationUnit(ChronoUnit.SECONDS)
        @PositiveOrZero
        private Duration clockSkew = Duration.ofSeconds(90);

        /**
         * Message validity window.
         */
        @DurationUnit(ChronoUnit.MINUTES)
        @Positive
        private Duration ttl = Duration.ofMinutes(5);

        /**
         * Require X-Content-SHA256 and verify body hash as part of signature.
         */
        private boolean enforceBodySha256 = false;

        /**
         * Additional headers that must be covered by the signature.
         */
        @NotNull
        private List<@Pattern(regexp = "^[A-Za-z0-9-]+$") String> requiredSignedHeaders = new ArrayList<>();

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getSignatureHeader() {
            return signatureHeader;
        }

        public void setSignatureHeader(String signatureHeader) {
            this.signatureHeader = signatureHeader;
        }

        public String getKeyIdHeader() {
            return keyIdHeader;
        }

        public void setKeyIdHeader(String keyIdHeader) {
            this.keyIdHeader = keyIdHeader;
        }

        public String getTimestampHeader() {
            return timestampHeader;
        }

        public void setTimestampHeader(String timestampHeader) {
            this.timestampHeader = timestampHeader;
        }

        public Set<String> getAcceptedAlgorithms() {
            return acceptedAlgorithms;
        }

        public void setAcceptedAlgorithms(Set<String> acceptedAlgorithms) {
            this.acceptedAlgorithms = acceptedAlgorithms == null ? new LinkedHashSet<>() : acceptedAlgorithms;
        }

        public Duration getClockSkew() {
            return clockSkew;
        }

        public void setClockSkew(Duration clockSkew) {
            this.clockSkew = clockSkew;
        }

        public Duration getTtl() {
            return ttl;
        }

        public void setTtl(Duration ttl) {
            this.ttl = ttl;
        }

        public boolean isEnforceBodySha256() {
            return enforceBodySha256;
        }

        public void setEnforceBodySha256(boolean enforceBodySha256) {
            this.enforceBodySha256 = enforceBodySha256;
        }

        public List<String> getRequiredSignedHeaders() {
            return requiredSignedHeaders;
        }

        public void setRequiredSignedHeaders(List<String> requiredSignedHeaders) {
            this.requiredSignedHeaders = requiredSignedHeaders == null ? new ArrayList<>() : requiredSignedHeaders;
        }
    }

    /**
     * Token-bucket rate limiting + optional response headers.
     */
    public static class RateLimit {
        private boolean enabled = true;

        /**
         * Expose standard X-RateLimit-* headers.
         */
        private boolean headers = true;

        /**
         * Keys composing the bucket id: ip, tenant, header:NAME
         */
        @NotNull
        private List<@Pattern(regexp = "ip|tenant|header:[A-Za-z0-9-]+") String> keys =
                new ArrayList<>(List.of("ip", "tenant"));

        @Valid
        @NotNull
        private Policy _default = Policy.defaults();

        /**
         * Ant patterns -> policy overrides.
         */
        @Valid
        @NotNull
        private Map<String, Policy> overrides = new LinkedHashMap<>();

        public static class Policy {
            /**
             * Max tokens in the bucket (capacity).
             */
            @Positive
            private int capacity = 100;

            /**
             * Tokens added on each refill event.
             */
            @Positive
            private int refillTokens = 100;

            /**
             * Period between refills.
             */
            @DurationUnit(ChronoUnit.SECONDS)
            @Positive
            private Duration refillPeriod = Duration.ofMinutes(1);

            public static Policy defaults() {
                return new Policy();
            }

            public int getCapacity() {
                return capacity;
            }

            public void setCapacity(int capacity) {
                this.capacity = capacity;
            }

            public int getRefillTokens() {
                return refillTokens;
            }

            public void setRefillTokens(int refillTokens) {
                this.refillTokens = refillTokens;
            }

            public Duration getRefillPeriod() {
                return refillPeriod;
            }

            public void setRefillPeriod(Duration refillPeriod) {
                this.refillPeriod = refillPeriod;
            }
        }

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public boolean isHeaders() {
            return headers;
        }

        public void setHeaders(boolean headers) {
            this.headers = headers;
        }

        public List<String> getKeys() {
            return keys;
        }

        public void setKeys(List<String> keys) {
            this.keys = keys == null ? new ArrayList<>() : keys;
        }

        public Policy getDefault() {
            return _default;
        }

        public void setDefault(Policy _default) {
            this._default = (_default == null) ? Policy.defaults() : _default;
        }

        public Map<String, Policy> getOverrides() {
            return overrides;
        }

        public void setOverrides(Map<String, Policy> overrides) {
            this.overrides = overrides == null ? new LinkedHashMap<>() : overrides;
        }
    }

    /**
     * PII log guard & redaction.
     */
    public static class PiiLog {
        private boolean enabled = true;

        /**
         * Max characters from payload/body to include in logs (after redaction).
         */
        @Positive
        private int payloadMaxChars = 2048;

        /**
         * Case-insensitive header names to drop or mask.
         */
        @NotNull
        private Set<String> headerDenylist = new LinkedHashSet<>(List.of(
                "authorization", "cookie", "set-cookie", "x-api-key"
        ));

        /**
         * Regex patterns to redact from payload lines.
         */
        @NotNull
        private List<String> redactPatterns = new ArrayList<>(List.of(
                "\\b[0-9]{13,19}\\b",                              // PAN-like sequences
                "[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"  // emails
        ));

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public int getPayloadMaxChars() {
            return payloadMaxChars;
        }

        public void setPayloadMaxChars(int payloadMaxChars) {
            this.payloadMaxChars = payloadMaxChars;
        }

        public Set<String> getHeaderDenylist() {
            return headerDenylist;
        }

        public void setHeaderDenylist(Set<String> headerDenylist) {
            this.headerDenylist = headerDenylist == null ? new LinkedHashSet<>() : headerDenylist;
        }

        public List<String> getRedactPatterns() {
            return redactPatterns;
        }

        public void setRedactPatterns(List<String> redactPatterns) {
            this.redactPatterns = redactPatterns == null ? new ArrayList<>() : redactPatterns;
        }
    }

    /**
     * CORS (global defaults; app may add fine-grained rules).
     */
    public static class Cors {
        private boolean enabled = true;

        @NotNull
        private List<String> allowedOrigins = new ArrayList<>();
        @NotNull
        private List<String> allowedMethods = new ArrayList<>(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        @NotNull
        private List<String> allowedHeaders = new ArrayList<>(List.of("Authorization", "Content-Type", "X-Tenant-Id", "X-Correlation-Id"));
        @NotNull
        private List<String> exposedHeaders = new ArrayList<>();
        private boolean allowCredentials = true;

        @DurationUnit(ChronoUnit.SECONDS)
        @Positive
        private Duration maxAge = Duration.ofMinutes(30);

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public List<String> getAllowedOrigins() {
            return allowedOrigins;
        }

        public void setAllowedOrigins(List<String> allowedOrigins) {
            this.allowedOrigins = allowedOrigins == null ? new ArrayList<>() : allowedOrigins;
        }

        public List<String> getAllowedMethods() {
            return allowedMethods;
        }

        public void setAllowedMethods(List<String> allowedMethods) {
            this.allowedMethods = allowedMethods == null ? new ArrayList<>() : allowedMethods;
        }

        public List<String> getAllowedHeaders() {
            return allowedHeaders;
        }

        public void setAllowedHeaders(List<String> allowedHeaders) {
            this.allowedHeaders = allowedHeaders == null ? new ArrayList<>() : allowedHeaders;
        }

        public List<String> getExposedHeaders() {
            return exposedHeaders;
        }

        public void setExposedHeaders(List<String> exposedHeaders) {
            this.exposedHeaders = exposedHeaders == null ? new ArrayList<>() : exposedHeaders;
        }

        public boolean isAllowCredentials() {
            return allowCredentials;
        }

        public void setAllowCredentials(boolean allowCredentials) {
            this.allowCredentials = allowCredentials;
        }

        public Duration getMaxAge() {
            return maxAge;
        }

        public void setMaxAge(Duration maxAge) {
            this.maxAge = maxAge;
        }
    }

    /**
     * Consistency preconditions & ETag emission.
     */
    public static class Consistency {
        private boolean enabled = true;

        /**
         * Request header holding a conditional token (read-your-writes).
         */
        @NotBlank
        private String requestHeader = "If-Consistent-With";

        /**
         * Whether to emit strong ETags (vs weak).
         */
        private boolean etagStrong = false;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getRequestHeader() {
            return requestHeader;
        }

        public void setRequestHeader(String requestHeader) {
            this.requestHeader = requestHeader;
        }

        public boolean isEtagStrong() {
            return etagStrong;
        }

        public void setEtagStrong(boolean etagStrong) {
            this.etagStrong = etagStrong;
        }
    }
}

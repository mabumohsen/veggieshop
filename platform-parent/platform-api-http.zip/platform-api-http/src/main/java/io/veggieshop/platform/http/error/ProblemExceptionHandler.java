package io.veggieshop.platform.http.error;

import io.veggieshop.platform.domain.error.ProblemTypes;
import io.veggieshop.platform.domain.error.VeggieException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.ErrorResponseException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

/**
 * ProblemExceptionHandler
 *
 * Global RFC7807 Problem+JSON handler (Servlet stack).
 * - Never leaks PII; delegates payload shaping to ProblemPayloadFactory (which uses sanitized views).
 * - Stable extension properties (problemCode, traceId, spanId, requestId, correlationId, tenantId, timestamp).
 * - Maps framework exceptions to sensible problem types defined in domain ProblemTypes.
 */
@RestControllerAdvice
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@Order(Ordered.HIGHEST_PRECEDENCE)
public final class ProblemExceptionHandler {

    private final ProblemPayloadFactory problemFactory;

    public ProblemExceptionHandler(ProblemPayloadFactory problemFactory) {
        this.problemFactory = Objects.requireNonNull(problemFactory, "ProblemPayloadFactory is required");
    }

    // --------------------------------------------------------------------------------------------
    // Domain & security/auth paths
    // --------------------------------------------------------------------------------------------

    @ExceptionHandler(VeggieException.class)
    public ResponseEntity<ProblemDetail> handleVeggieException(
            HttpServletRequest request, VeggieException ex) {

        // VeggieException already carries the intended HTTP status and ProblemTypes.ProblemType
        HttpStatus status = HttpStatus.valueOf(ex.status());
        ProblemDetail pd = problemFactory.fromException(request, status, ex);
        return withProblemJson(pd, status);
    }

    // --------------------------------------------------------------------------------------------
    // Validation & request shape
    // --------------------------------------------------------------------------------------------

    @ExceptionHandler(BindException.class)
    public ResponseEntity<ProblemDetail> handleBindException(
            HttpServletRequest request, BindException ex) {

        List<Map<String, Object>> errors = new ArrayList<>(ex.getErrorCount());
        for (var err : ex.getBindingResult().getAllErrors()) {
            if (err instanceof FieldError fe) {
                errors.add(fieldViolation(fe.getField(), safeMessage(err.getDefaultMessage()), fe.getCode()));
            } else {
                errors.add(fieldViolation(err.getObjectName(), safeMessage(err.getDefaultMessage()), err.getCode()));
            }
        }
        ProblemDetail pd = problemFactory.badRequestWithErrors(
                request,
                ProblemTypes.VALIDATION_FAILED,
                errors,
                "Validation failed for request."
        );
        return withProblemJson(pd, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ProblemDetail> handleTypeMismatch(
            HttpServletRequest request, MethodArgumentTypeMismatchException ex) {

        String field = (ex.getName() != null ? ex.getName() : "parameter");
        String required = (ex.getRequiredType() != null ? ex.getRequiredType().getSimpleName() : "type");
        var errors = List.of(fieldViolation(field, "Invalid value", "TYPE_MISMATCH"));
        ProblemDetail pd = problemFactory.badRequestWithErrors(
                request,
                ProblemTypes.VALIDATION_FAILED,
                errors,
                "Expected " + required + " for '" + field + "'."
        );
        return withProblemJson(pd, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ProblemDetail> handleMissingParam(
            HttpServletRequest request, MissingServletRequestParameterException ex) {

        var errors = List.of(fieldViolation(ex.getParameterName(), "Required parameter is missing", "MISSING"));
        ProblemDetail pd = problemFactory.badRequestWithErrors(
                request,
                ProblemTypes.VALIDATION_FAILED,
                errors,
                "Missing required parameter '" + ex.getParameterName() + "'."
        );
        return withProblemJson(pd, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<ProblemDetail> handleMissingHeader(
            HttpServletRequest request, MissingRequestHeaderException ex) {

        var errors = List.of(fieldViolation(ex.getHeaderName(), "Required header is missing", "MISSING"));
        ProblemDetail pd = problemFactory.badRequestWithErrors(
                request,
                ProblemTypes.VALIDATION_FAILED,
                errors,
                "Missing required header '" + ex.getHeaderName() + "'."
        );
        return withProblemJson(pd, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ProblemDetail> handleNotReadable(
            HttpServletRequest request, HttpMessageNotReadableException ex) {

        ProblemDetail pd = problemFactory.build(
                request,
                HttpStatus.BAD_REQUEST,
                ProblemTypes.VALIDATION_FAILED,
                "Malformed request body.",
                /*problemCode*/ "MALFORMED_BODY",
                /*errors*/ null
        );
        return withProblemJson(pd, HttpStatus.BAD_REQUEST);
    }

    // --------------------------------------------------------------------------------------------
    // HTTP protocol & negotiation
    // --------------------------------------------------------------------------------------------

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<ProblemDetail> handleUnsupportedMediaType(
            HttpServletRequest request, HttpMediaTypeNotSupportedException ex) {

        HttpHeaders headers = new HttpHeaders();
        if (!ex.getSupportedMediaTypes().isEmpty()) {
            headers.setAccept(ex.getSupportedMediaTypes());
        }
        ProblemDetail pd = problemFactory.build(
                request,
                HttpStatus.UNSUPPORTED_MEDIA_TYPE,
                ProblemTypes.UNSUPPORTED_MEDIA_TYPE,
                "Unsupported media type.",
                "UNSUPPORTED_MEDIA_TYPE",
                null
        );
        return withProblemJson(pd, HttpStatus.UNSUPPORTED_MEDIA_TYPE, headers);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ProblemDetail> handleMethodNotSupported(
            HttpServletRequest request, HttpRequestMethodNotSupportedException ex) {

        HttpHeaders headers = new HttpHeaders();
        if (ex.getSupportedHttpMethods() != null && !ex.getSupportedHttpMethods().isEmpty()) {
            headers.setAllow(ex.getSupportedHttpMethods());
        }
        ProblemDetail pd = problemFactory.build(
                request,
                HttpStatus.METHOD_NOT_ALLOWED,
                /*problem type*/ null, // No specific ProblemTypes entry; status is sufficient.
                "HTTP method not allowed for this endpoint.",
                "METHOD_NOT_ALLOWED",
                null
        );
        return withProblemJson(pd, HttpStatus.METHOD_NOT_ALLOWED, headers);
    }

    // --------------------------------------------------------------------------------------------
    // Framework exceptions with explicit statuses
    // --------------------------------------------------------------------------------------------

    @ExceptionHandler({ResponseStatusException.class, ErrorResponseException.class})
    public ResponseEntity<ProblemDetail> handleStatusExceptions(
            HttpServletRequest request, Exception ex) {

        HttpStatus status;
        String detail;

        if (ex instanceof ResponseStatusException rse) {
            status = HttpStatus.resolve(rse.getStatusCode().value());
            detail = safeMessage(rse.getReason());
        } else if (ex instanceof ErrorResponseException ere) {
            status = HttpStatus.resolve(ere.getStatusCode().value());
            detail = safeMessage(ere.getBody() != null ? ere.getBody().getDetail() : null);
        } else {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
            detail = "Request could not be processed.";
        }
        if (status == null) status = HttpStatus.INTERNAL_SERVER_ERROR;

        ProblemDetail pd = problemFactory.build(request, status, null, detail, null, null);
        return withProblemJson(pd, status);
    }

    // --------------------------------------------------------------------------------------------
    // Fallback (last resort)
    // --------------------------------------------------------------------------------------------

    @ExceptionHandler(Throwable.class)
    public ResponseEntity<ProblemDetail> handleOther(HttpServletRequest request, Throwable ex) {
        ProblemDetail pd = problemFactory.internalServerError(request);
        return withProblemJson(pd, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // --------------------------------------------------------------------------------------------
    // Utilities
    // --------------------------------------------------------------------------------------------

    private ResponseEntity<ProblemDetail> withProblemJson(ProblemDetail pd, HttpStatus status) {
        return withProblemJson(pd, status, new HttpHeaders());
    }

    private ResponseEntity<ProblemDetail> withProblemJson(ProblemDetail pd, HttpStatus status, HttpHeaders headers) {
        // Enforce RFC 7807 media type
        headers.setContentType(MediaType.APPLICATION_PROBLEM_JSON);
        return new ResponseEntity<>(pd, headers, status);
    }

    private static Map<String, Object> fieldViolation(String field, String message, @Nullable String code) {
        Map<String, Object> m = new LinkedHashMap<>(3);
        m.put("field", field);
        m.put("message", message);
        if (StringUtils.hasText(code)) m.put("code", code);
        return m;
    }

    private static String safeMessage(@Nullable Object msg) {
        String s = (msg == null ? null : String.valueOf(msg));
        return (s == null || s.isBlank()) ? "Request could not be processed." : s;
    }
}

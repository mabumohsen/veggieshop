package io.veggieshop.platform.http.consistency;

import io.veggieshop.platform.application.consistency.ConsistencyService;
import io.veggieshop.platform.domain.consistency.EntityVersion;
import io.veggieshop.platform.domain.tenant.TenantContext;
import io.veggieshop.platform.domain.tenant.TenantId;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import java.lang.reflect.Method;
import java.lang.reflect.RecordComponent;
import java.util.*;

public final class ETagResponseAdvice implements ResponseBodyAdvice<Object> {

    public static final String HDR_VARY = "Vary";
    public static final String HDR_IF_CONSISTENT_WITH = "If-Consistent-With";
    public static final String HDR_ETAG = HttpHeaders.ETAG;
    public static final String HDR_ENTITY_VERSION = "X-Entity-Version";
    public static final String HDR_CONSISTENCY_TOKEN = "X-Consistency-Token";

    /**
     * Optional request attributes that, when present, allow token issuance on mutation responses.
     * Controllers can set these before returning the body:
     *   request.setAttribute(ETagResponseAdvice.ATTR_AGGREGATE_TYPE, "order");
     *   request.setAttribute(ETagResponseAdvice.ATTR_AGGREGATE_ID,   orderId);
     */
    public static final String ATTR_AGGREGATE_TYPE = ETagResponseAdvice.class.getName() + ".AGGREGATE_TYPE";
    public static final String ATTR_AGGREGATE_ID   = ETagResponseAdvice.class.getName() + ".AGGREGATE_ID";

    private final ConsistencyService consistency;

    public ETagResponseAdvice(ConsistencyService consistency) {
        this.consistency = Objects.requireNonNull(consistency, "ConsistencyService is required");
    }

    @Override
    public boolean supports(@NonNull MethodParameter returnType,
                            @NonNull Class<? extends HttpMessageConverter<?>> converterType) {
        // Apply broadly to REST responses. We no-op if we can't determine a version.
        return true;
    }

    @Override
    public Object beforeBodyWrite(@Nullable Object body,
                                  @NonNull MethodParameter returnType,
                                  @NonNull MediaType selectedContentType,
                                  @NonNull Class<? extends HttpMessageConverter<?>> selectedConverterType,
                                  @NonNull ServerHttpRequest request,
                                  @NonNull ServerHttpResponse response) {

        // Ensure proxies/caches consider the consistency dimension (idempotent).
        response.getHeaders().add(HDR_VARY, HDR_IF_CONSISTENT_WITH);

        if (!is2xx(response)) {
            return body;
        }

        HttpHeaders headers = response.getHeaders();

        // Respect explicit headers set by controllers.
        boolean alreadyHasAll =
                headers.containsKey(HDR_ETAG) &&
                        headers.containsKey(HDR_ENTITY_VERSION) &&
                        headers.containsKey(HDR_CONSISTENCY_TOKEN);
        if (alreadyHasAll) {
            return body;
        }

        // Resolve tenant (needed for token; ETag/X-Entity-Version can still be set without it).
        TenantId tenant = TenantContext.currentTenantId().orElse(null);

        // Extract entity version from the response body shape.
        Long version = extractVersion(body).or(() -> extractVersionFromResponseEntity(body)).orElse(null);
        if (version == null) {
            return body;
        }

        if (!headers.containsKey(HDR_ETAG)) {
            headers.set(HDR_ETAG, consistency.etagFor(version));
        }
        if (!headers.containsKey(HDR_ENTITY_VERSION)) {
            headers.set(HDR_ENTITY_VERSION, "v" + version);
        }

        // Best-effort: issue a consistency token only if we have tenant + aggregate identity.
        if (tenant != null && !headers.containsKey(HDR_CONSISTENCY_TOKEN)) {
            var servletReq = toServletRequest(request);
            if (servletReq != null) {
                Object t = servletReq.getAttribute(ATTR_AGGREGATE_TYPE);
                Object i = servletReq.getAttribute(ATTR_AGGREGATE_ID);
                if (t instanceof String aggType && i instanceof String aggId) {
                    String token = consistency.newToken(tenant.value(), aggType, aggId, version);
                    headers.set(HDR_CONSISTENCY_TOKEN, token);
                }
            }
        }

        return body;
    }

    // --------------------------------------------------------------------------------------------
    // Version extraction helpers
    // --------------------------------------------------------------------------------------------

    private static Optional<Long> extractVersion(@Nullable Object body) {
        if (body == null) return Optional.empty();

        // 1) Collection: use max version among elements
        if (body instanceof Collection<?> col && !col.isEmpty()) {
            long max = -1;
            for (Object o : col) {
                long v = extractVersion(o).orElse(-1L);
                if (v > max) max = v;
            }
            return (max >= 0) ? Optional.of(max) : Optional.empty();
        }

        // 2) Map payloads
        if (body instanceof Map<?, ?> map) {
            Object ev = firstNonNull(map.get("entityVersion"), map.get("version"), map.get("v"));
            return toVersion(ev);
        }

        // 3) Records: component named entityVersion/version/v
        if (body.getClass().isRecord()) {
            for (RecordComponent rc : body.getClass().getRecordComponents()) {
                String name = rc.getName();
                if ("entityVersion".equals(name) || "version".equals(name) || "v".equals(name)) {
                    try {
                        Method accessor = rc.getAccessor();
                        Object val = accessor.invoke(body);
                        return toVersion(val);
                    } catch (ReflectiveOperationException ignore) { }
                }
            }
        }

        // 4) Methods: getEntityVersion(), entityVersion(), getVersion(), version()
        for (String m : new String[]{"getEntityVersion", "entityVersion", "getVersion", "version"}) {
            try {
                Method method = body.getClass().getMethod(m);
                if (!method.canAccess(body)) method.setAccessible(true);
                Object val = method.invoke(body);
                Optional<Long> v = toVersion(val);
                if (v.isPresent()) return v;
            } catch (NoSuchMethodException ignored) {
            } catch (ReflectiveOperationException ignored) {
            }
        }

        return Optional.empty();
    }

    private static Optional<Long> extractVersionFromResponseEntity(@Nullable Object body) {
        if (body instanceof ResponseEntity<?> re) {
            return extractVersion(re.getBody());
        }
        return Optional.empty();
    }

    private static Optional<Long> toVersion(@Nullable Object val) {
        if (val == null) return Optional.empty();
        if (val instanceof EntityVersion ev) {
            return Optional.of(ev.value());
        }
        if (val instanceof Number n) {
            long v = n.longValue();
            return (v >= 0) ? Optional.of(v) : Optional.empty();
        }
        try {
            long v = Long.parseLong(String.valueOf(val));
            return (v >= 0) ? Optional.of(v) : Optional.empty();
        } catch (NumberFormatException ignore) {
            return Optional.empty();
        }
    }

    private static boolean is2xx(ServerHttpResponse response) {
        if (response instanceof ServletServerHttpResponse s) {
            HttpStatusCode status = HttpStatusCode.valueOf(s.getServletResponse().getStatus());
            return status.is2xxSuccessful();
        }
        // Unknown impl: assume success (headers are harmless).
        return true;
    }

    @SafeVarargs
    private static <T> T firstNonNull(T... vals) {
        for (T v : vals) if (v != null) return v;
        return null;
    }

    private static jakarta.servlet.http.HttpServletRequest toServletRequest(ServerHttpRequest request) {
        if (request instanceof ServletServerHttpRequest sreq) {
            return sreq.getServletRequest();
        }
        return null;
    }
}

package io.veggieshop.platform.domain.tenant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * TenantResolver
 *
 * <p>Enterprise-grade, framework-agnostic resolver that extracts a {@link TenantId} from
 * common carriers: HTTP headers, JWT/OIDC claims, messaging headers, or MDC. Designed
 * to live in the <em>domain</em> module (no servlet/Spring/Kafka dependencies).</p>
 *
 * <h2>Principles</h2>
 * <ul>
 *   <li><b>Explicit precedence:</b> explicit parameter &gt; HTTP header &gt; JWT claim &gt; message header &gt; MDC.</li>
 *   <li><b>Consistency guard:</b> if multiple sources are present and disagree, fail fast.</li>
 *   <li><b>No preview/unsafe APIs:</b> plain Java 21, no container/library coupling.</li>
 *   <li><b>Observability:</b> emits DEBUG for normal decisions and WARN for inconsistencies.</li>
 *   <li><b>Security note:</b> MDC is never a trusted source for authorization; it is a last-resort hint.</li>
 * </ul>
 *
 * <h3>Typical use (HTTP filter)</h3>
 * <pre>{@code
 * var resolved = TenantResolver.resolve(
 *     null,                      // explicit (if already known), else null
 *     requestHeadersMap,         // Map<String,String>
 *     jwtClaimsMap,              // Map<String,Object>
 *     null,                      // message headers if any
 *     true                       // enforce cross-source consistency
 * );
 * try (var ignored = TenantContext.open(resolved.tenantId())) {
 *     chain.doFilter(request, response);
 * }
 * }</pre>
 */
public final class TenantResolver {

    private static final Logger LOG = LoggerFactory.getLogger(TenantResolver.class);

    /** Canonical inbound header (kept in sync with {@link TenantContext#REQUEST_HEADER}). */
    public static final String HEADER_X_TENANT_ID = TenantContext.REQUEST_HEADER;

    /** Additional header aliases tolerated in partner / legacy integrations. */
    private static final List<String> HEADER_ALIASES = List.of(
            HEADER_X_TENANT_ID,
            "x-tenant-id",
            "X_TENANT_ID",
            "Tenant-Id",
            "tenant-id"
    );

    /** Common JWT/OIDC claim names for tenant. Prefer a namespaced claim when available. */
    private static final List<String> CLAIM_CANDIDATES = List.of(
            "https://veggieshop.io/tenant_id",
            "https://schemas.veggieshop.io/tenant_id",
            "tenantId",
            "tenant_id",
            "tid"
    );

    /** Messaging header aliases (Kafka, etc.). */
    private static final List<String> MSG_HEADER_ALIASES = List.of(
            "x-tenant-id",
            "tenant-id",
            "tenantId",
            "x_tenant_id"
    );

    /** MDC key used in our JSON logs (read-only; do not rely on this for auth). */
    private static final String MDC_TENANT_ID = TenantContext.MDC_TENANT_ID;

    private TenantResolver() {
        /* utility */
    }

    // -------------------------------------------------------------------------------------
    // Public API
    // -------------------------------------------------------------------------------------

    /**
     * Resolve a tenant using the defined precedence. If {@code enforceConsistency} is true and
     * more than one source supplies a tenant but the values differ, this method throws an {@link IllegalStateException}.
     *
     * @param explicit            explicit tenant (strongest precedence), may be null
     * @param httpHeaders         case-insensitive headers map, may be null
     * @param jwtClaims           JWT/OIDC claims map, may be null
     * @param messageHeadersBytes message headers (binary values), may be null
     * @param enforceConsistency  whether to fail on cross-source mismatches
     * @return a {@link Resolution} containing the chosen tenant and its source
     * @throws NoSuchElementException if no tenant can be resolved
     * @throws IllegalStateException  if inconsistent tenants are detected while {@code enforceConsistency} is true
     */
    public static Resolution resolve(
            TenantId explicit,
            Map<String, ?> httpHeaders,
            Map<String, ?> jwtClaims,
            Map<String, byte[]> messageHeadersBytes,
            boolean enforceConsistency
    ) {
        final List<Resolution> candidates = new ArrayList<>(4);

        if (explicit != null) {
            candidates.add(new Resolution(explicit, Source.EXPLICIT));
        }

        resolveFromHttpHeaders(httpHeaders).ifPresent(candidates::add);
        resolveFromJwtClaims(jwtClaims).ifPresent(candidates::add);
        resolveFromMessageHeaders(messageHeadersBytes).ifPresent(candidates::add);
        resolveFromMdc().ifPresent(candidates::add);

        if (candidates.isEmpty()) {
            throw new NoSuchElementException("Unable to resolve tenant: none of [explicit, HTTP header, JWT claim, message header, MDC] provided a value");
        }

        if (enforceConsistency) {
            assertConsistent(candidates);
        }

        // Choose the first by precedence (list is built in precedence order).
        final Resolution chosen = candidates.get(0);
        if (LOG.isDebugEnabled()) {
            LOG.debug("Tenant resolved: id='{}' source={}", chosen.tenantId().value(), chosen.source());
        }
        return chosen;
    }

    /**
     * Resolve from HTTP headers only (case-insensitive).
     */
    public static Optional<Resolution> resolveFromHttpHeaders(Map<String, ?> headers) {
        if (headers == null || headers.isEmpty()) return Optional.empty();
        return findFirstString(headers, HEADER_ALIASES)
                .flatMap(TenantResolver::toTenantId)
                .map(id -> new Resolution(id, Source.HTTP_HEADER));
    }

    /**
     * Resolve from JWT/OIDC claims only.
     */
    public static Optional<Resolution> resolveFromJwtClaims(Map<String, ?> claims) {
        if (claims == null || claims.isEmpty()) return Optional.empty();
        return findFirstString(claims, CLAIM_CANDIDATES)
                .flatMap(TenantResolver::toTenantId)
                .map(id -> new Resolution(id, Source.JWT_CLAIM));
    }

    /**
     * Resolve from binary message headers (e.g., Kafka) only.
     */
    public static Optional<Resolution> resolveFromMessageHeaders(Map<String, byte[]> headers) {
        if (headers == null || headers.isEmpty()) return Optional.empty();
        return findFirstBytes(headers, MSG_HEADER_ALIASES)
                .map(bytes -> new String(bytes, StandardCharsets.UTF_8))
                .flatMap(TenantResolver::toTenantId)
                .map(id -> new Resolution(id, Source.MESSAGE_HEADER));
    }

    /**
     * Resolve from MDC (observability), as a last resort. Not for authorization.
     */
    public static Optional<Resolution> resolveFromMdc() {
        final String mdc = MDC.get(MDC_TENANT_ID);
        return toTenantId(mdc).map(id -> new Resolution(id, Source.MDC));
    }

    // -------------------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------------------

    private static Optional<String> findFirstString(Map<String, ?> map, List<String> keys) {
        if (map == null || map.isEmpty()) return Optional.empty();
        // Build a case-insensitive view once.
        Map<String, Object> ci = new HashMap<>(map.size());
        for (Map.Entry<String, ?> e : map.entrySet()) {
            if (e.getKey() == null) continue;
            ci.put(e.getKey().toLowerCase(Locale.ROOT), e.getValue());
        }
        for (String key : keys) {
            Object v = ci.get(key.toLowerCase(Locale.ROOT));
            if (v != null) {
                String s = String.valueOf(v);
                String cleaned = normalize(s);
                if (cleaned != null) return Optional.of(cleaned);
            }
        }
        return Optional.empty();
    }

    private static Optional<byte[]> findFirstBytes(Map<String, byte[]> map, List<String> keys) {
        if (map == null || map.isEmpty()) return Optional.empty();
        // Case-insensitive search
        Map<String, byte[]> ci = new HashMap<>(map.size());
        for (Map.Entry<String, byte[]> e : map.entrySet()) {
            if (e.getKey() == null) continue;
            ci.put(e.getKey().toLowerCase(Locale.ROOT), e.getValue());
        }
        for (String key : keys) {
            byte[] v = ci.get(key.toLowerCase(Locale.ROOT));
            if (v != null && v.length > 0) return Optional.of(v);
        }
        return Optional.empty();
    }

    private static Optional<TenantId> toTenantId(String raw) {
        String cleaned = normalize(raw);
        if (cleaned == null) return Optional.empty();
        try {
            // Rely on TenantId's validation (format/length/charset).
            return Optional.of(TenantId.of(cleaned));
        } catch (IllegalArgumentException ex) {
            LOG.warn("Rejected tenant identifier from carrier due to validation error: {}", ex.getMessage());
            return Optional.empty();
        }
    }

    private static String normalize(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty() || "null".equalsIgnoreCase(t)) return null;
        return t;
    }

    private static void assertConsistent(List<Resolution> candidates) {
        if (candidates.size() <= 1) return;
        TenantId first = candidates.get(0).tenantId();
        for (int i = 1; i < candidates.size(); i++) {
            TenantId other = candidates.get(i).tenantId();
            if (!first.equals(other)) {
                LOG.warn("Inconsistent tenant identifiers across sources: chosen={}({}) conflicting={}({})",
                        first.value(), candidates.get(0).source(),
                        other.value(), candidates.get(i).source());
                throw new IllegalStateException("Conflicting tenant identifiers provided by multiple sources");
            }
        }
    }

    // -------------------------------------------------------------------------------------
    // Types
    // -------------------------------------------------------------------------------------

    /** Resolution source for observability and policy. */
    public enum Source {
        EXPLICIT,
        HTTP_HEADER,
        JWT_CLAIM,
        MESSAGE_HEADER,
        MDC
    }

    /** Small value object capturing the resolved tenant and where it came from. */
    public record Resolution(TenantId tenantId, Source source) {
        public Resolution {
            Objects.requireNonNull(tenantId, "tenantId");
            Objects.requireNonNull(source, "source");
        }
    }
}

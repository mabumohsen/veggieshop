package io.veggieshop.platform.domain.consistency;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;

/**
 * EntityVersion
 *
 * <p>Immutable value object representing a monotonic, non-negative entity version used
 * for ETag generation and the {@code If-Consistent-With} handshake (PRD v2.0 §10).</p>
 *
 * <h2>Design</h2>
 * <ul>
 *   <li><b>Strict domain constraints:</b> version is {@code >= 0} and fits in a signed {@code long}.</li>
 *   <li><b>HTTP-friendly helpers:</b> strong/weak ETag formatting and tolerant parsing of
 *       {@code "v42"}, {@code W/"v42"}, {@code v42}, or plain {@code 42} header values.</li>
 *   <li><b>Monotonic operations:</b> safe increment via {@link Math#addExact(long, long)}.</li>
 *   <li><b>No external deps:</b> pure JDK 21, serialization-friendly, {@link Comparable}.</li>
 * </ul>
 *
 * <h3>Headers (aligned with PRD)</h3>
 * <ul>
 *   <li>Response: {@code ETag: "v&lt;n&gt;"} and {@code X-Entity-Version: &lt;n&gt;}</li>
 *   <li>Request: {@code If-Consistent-With: v&lt;n&gt;}</li>
 * </ul>
 */
public final class EntityVersion implements Comparable<EntityVersion>, Serializable {

    @Serial private static final long serialVersionUID = 1L;

    /** Header name carrying the raw numeric version in responses (aux to ETag). */
    public static final String RESPONSE_HEADER = "X-Entity-Version";

    /** Request header name carrying the client-observed version (without quotes). */
    public static final String REQUEST_HEADER = "If-Consistent-With";

    /** Prefix used in ETag/If-Consistent-With values: {@code v}. */
    public static final String ETAG_PREFIX = "v";

    /** A convenient zero version instance. */
    public static final EntityVersion ZERO = new EntityVersion(0L);

    private final long value;

    private EntityVersion(long value) {
        if (value < 0) throw new IllegalArgumentException("EntityVersion must be >= 0");
        this.value = value;
    }

    // -------------------------------------------------------------------------------------
    // Factories
    // -------------------------------------------------------------------------------------

    /** Create a version with the given non-negative value. */
    public static EntityVersion of(long value) {
        return value == 0 ? ZERO : new EntityVersion(value);
    }

    /**
     * Parse an ETag / header value into an {@link EntityVersion}.
     * Accepts the following forms: {@code "v42"}, {@code W/"v42"}, {@code v42}, {@code 42}.
     */
    public static Optional<EntityVersion> parse(String raw) {
        if (raw == null) return Optional.empty();
        String t = raw.trim();
        if (t.isEmpty()) return Optional.empty();

        // Strip weak validator and surrounding quotes if present.
        if (t.startsWith("W/")) t = t.substring(2).trim();
        if (t.length() >= 2 && t.charAt(0) == '"' && t.charAt(t.length() - 1) == '"') {
            t = t.substring(1, t.length() - 1).trim();
        }

        // Strip optional prefix v
        if (t.startsWith(ETAG_PREFIX)) {
            t = t.substring(ETAG_PREFIX.length());
        }

        try {
            long n = Long.parseLong(t);
            return n >= 0 ? Optional.of(of(n)) : Optional.empty();
        } catch (NumberFormatException ex) {
            return Optional.empty();
        }
    }

    /** Parse or throw {@link IllegalArgumentException} with a clear message. */
    public static EntityVersion parseRequired(String raw) {
        return parse(raw).orElseThrow(() ->
                new IllegalArgumentException("Invalid entity version value: " + raw));
    }

    // -------------------------------------------------------------------------------------
    // HTTP helpers
    // -------------------------------------------------------------------------------------

    /** Strong ETag value, e.g. {@code "\"v42\""}. */
    public String toStrongETag() {
        return "\"" + ETAG_PREFIX + value + "\"";
    }

    /** Weak ETag value, e.g. {@code "W/\"v42\""}. */
    public String toWeakETag() {
        return "W/" + toStrongETag();
    }

    /** Header value for {@code If-Consistent-With}: {@code v&lt;n&gt;}. */
    public String toIfConsistentWith() {
        return ETAG_PREFIX + value;
    }

    /** Header value for {@code X-Entity-Version}: raw numeric string. */
    public String toNumericHeader() {
        return Long.toString(value);
    }

    /** Numeric string form used in canonical audit payloads. */
    public String asString() {
        return Long.toString(value);
    }

    // -------------------------------------------------------------------------------------
    // Domain ops
    // -------------------------------------------------------------------------------------

    /** Return the underlying numeric value. */
    public long value() {
        return value;
    }

    /** Return {@code this + 1} with overflow safety. */
    public EntityVersion increment() {
        return of(Math.addExact(value, 1L));
    }

    // -------------------------------------------------------------------------------------
    // Object contract
    // -------------------------------------------------------------------------------------

    @Override
    public int compareTo(EntityVersion o) {
        return Long.compare(this.value, o.value);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        return (obj instanceof EntityVersion that) && this.value == that.value;
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }

    @Override
    public String toString() {
        // Human-friendly; not the wire format.
        return "EntityVersion{value=" + value + '}';
    }
}

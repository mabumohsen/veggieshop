package io.veggieshop.platform.starter.web.autoconfig;

import io.veggieshop.platform.http.VeggieShopHttpProperties;
import io.veggieshop.platform.http.consistency.ConsistencyPreconditionInterceptor;
import io.veggieshop.platform.http.consistency.ETagResponseAdvice;
import io.veggieshop.platform.http.filters.CorrelationIdFilter;
import io.veggieshop.platform.http.filters.HmacAuthFilter;
import io.veggieshop.platform.http.filters.PiiLogGuardFilter;
import io.veggieshop.platform.http.filters.RateLimitFilter;
import io.veggieshop.platform.http.filters.TenantFilter;
import io.veggieshop.platform.domain.tenant.TenantResolver;
import io.veggieshop.platform.application.consistency.ConsistencyService;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;
import org.springframework.web.filter.ForwardedHeaderFilter;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.time.Clock;

/**
 * Assembles VeggieShop HTTP components (filters/interceptors/advice) from platform-api-http.
 * Master switch: veggieshop.http.enabled=true (default).
 */
@AutoConfiguration
@EnableConfigurationProperties(VeggieShopHttpProperties.class)
@ConditionalOnClass(DispatcherServlet.class)
@ConditionalOnProperty(prefix = "veggieshop.http", name = "enabled", matchIfMissing = true)
public class VeggieShopWebAutoConfiguration {

    private static final int DEFAULT_MAX_BODY_BYTES = 1_000_000; // 1 MB

    // --- Core & always-safe ---

    @Bean
    @ConditionalOnMissingBean
    ForwardedHeaderFilter forwardedHeaderFilter() {
        return new ForwardedHeaderFilter();
    }

    // --- Correlation ---

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.http.correlation", name = "enabled", matchIfMissing = true)
    CorrelationIdFilter correlationIdFilter(VeggieShopHttpProperties p) {
        return new CorrelationIdFilter(
                p.getCorrelation().getHeader(),
                p.getCorrelation().isGenerateIfMissing(),
                p.getCorrelation().getGenerator().name(),
                p.getCorrelation().getMdcKey()
        );
    }

    // --- Tenant guard ---

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.http.tenant", name = "enabled", matchIfMissing = true)
    TenantFilter tenantFilter(TenantResolver tenantResolver, VeggieShopHttpProperties p) {
        return new TenantFilter(
                tenantResolver,
                p.getTenant().getHeader(),
                p.getTenant().isRequired(),
                p.getTenant().getPublicPaths(),
                p.getTenant().getMdcKey()
        );
    }

    // --- PII log guard ---

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.http.pii-log", name = "enabled", matchIfMissing = true)
    PiiLogGuardFilter piiLogGuardFilter(VeggieShopHttpProperties p) {
        return new PiiLogGuardFilter(
                p.getPiiLog().getPayloadMaxChars(),
                p.getPiiLog().getHeaderDenylist(),
                p.getPiiLog().getRedactPatterns()
        );
    }

    // --- Rate limiting ---

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.http.rate-limit", name = "enabled", matchIfMissing = true)
    RateLimitFilter rateLimitFilter(VeggieShopHttpProperties p) {
        return new RateLimitFilter(
                p.getRateLimit().isHeaders(),
                p.getRateLimit().getKeys(),
                p.getRateLimit().getDefault(),
                p.getRateLimit().getOverrides()
        );
    }

    // --- HMAC partner auth ---

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.http.hmac", name = "enabled")
    HmacAuthFilter hmacAuthFilter(
            VeggieShopHttpProperties p,
            HmacAuthFilter.HmacKeyResolver keyResolver,
            ObjectProvider<HmacAuthFilter.NonceStore> nonceStore,
            ObjectProvider<Clock> clock
    ) {
        var hp = p.getHmac();
        return new HmacAuthFilter(
                keyResolver,
                nonceStore.getIfAvailable(() -> HmacAuthFilter.inMemoryNonceStore(500_000, hp.getTtl())),
                clock.getIfAvailable(Clock::systemUTC),
                hp.getKeyIdHeader(),
                hp.getTimestampHeader(),
                "X-Hmac-Nonce", // consider adding to properties later
                hp.getSignatureHeader(),
                DEFAULT_MAX_BODY_BYTES, // consider exposing in properties later
                hp.getClockSkew(),
                hp.isEnforceBodySha256(),
                hp.getAcceptedAlgorithms().stream().findFirst().orElse("HmacSHA256")
        );
    }

    // --- Consistency (preconditions + ETag) ---

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.http.consistency", name = "enabled", matchIfMissing = true)
    ETagResponseAdvice eTagResponseAdvice(ConsistencyService consistency) {
        return new ETagResponseAdvice(consistency);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.http.consistency", name = "enabled", matchIfMissing = true)
    ConsistencyPreconditionInterceptor consistencyPreconditionInterceptor(ConsistencyService consistencyService) {
        return new ConsistencyPreconditionInterceptor(consistencyService);
    }

    // --- MVC glue (interceptors + CORS) ---

    @Bean
    WebMvcConfigurer veggieshopWebConfigurer(
            ObjectProvider<ConsistencyPreconditionInterceptor> cpiProvider,
            VeggieShopHttpProperties p
    ) {
        return new WebMvcConfigurer() {
            @Override
            public void addInterceptors(InterceptorRegistry reg) {
                var cpi = cpiProvider.getIfAvailable();
                if (cpi != null) {
                    reg.addInterceptor(cpi).order(Ordered.HIGHEST_PRECEDENCE + 10);
                }
            }

            @Override
            public void addCorsMappings(CorsRegistry reg) {
                if (p.getCors().isEnabled()) {
                    reg.addMapping("/**")
                            .allowedOrigins(p.getCors().getAllowedOrigins().toArray(String[]::new))
                            .allowedMethods(p.getCors().getAllowedMethods().toArray(String[]::new))
                            .allowedHeaders(p.getCors().getAllowedHeaders().toArray(String[]::new))
                            .exposedHeaders(p.getCors().getExposedHeaders().toArray(String[]::new))
                            .allowCredentials(p.getCors().isAllowCredentials())
                            .maxAge(p.getCors().getMaxAge().toSeconds());
                }
            }
        };
    }
}

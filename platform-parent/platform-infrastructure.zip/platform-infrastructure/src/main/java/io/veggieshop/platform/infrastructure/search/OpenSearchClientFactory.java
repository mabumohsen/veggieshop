package io.veggieshop.platform.infrastructure.search;

import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.message.BasicHeader;
import org.opensearch.client.RestClient;
import org.opensearch.client.opensearch.OpenSearchClient;
import org.opensearch.client.json.jackson.JacksonJsonpMapper;
import org.opensearch.client.transport.OpenSearchTransport;
import org.opensearch.client.transport.rest_client.RestClientTransport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;

/**
 * OpenSearchClientFactory
 *
 * Enterprise-grade OpenSearch client wiring with:
 *  - Hardened HTTP timeouts/retries and optional TLS trust store
 *  - Auth support (NONE/BASIC/BEARER) without leaking secrets
 *  - Multi-tenant guardrails: index name policy `tenant-{id}-{domain}-*`
 *  - ISM (Index State Management) policy + index template + bootstrap index/alias per-tenant
 *
 * PRD alignment:
 *  - Multi-tenant ILM (ISM) per tenant with rollover/retention and shard/replica policy by tier (§8)
 *  - No PII in logs; tenant guardrails; index-level auth assumed on cluster side (§4, §15, §17)
 *  - Works with Servlet + Virtual Threads; callers should respect consistency tokens on reads (§6)
 *
 * Since: 2.0
 */
@Configuration
@EnableConfigurationProperties(OpenSearchClientFactory.OpenSearchProps.class)
public class OpenSearchClientFactory {

    private static final Logger log = LoggerFactory.getLogger(OpenSearchClientFactory.class);
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy.MM.dd");
    private static final Pattern TENANT_ID = Pattern.compile("^[a-z0-9_-]{1,64}$");

    // =====================================================================================
    // Beans
    // =====================================================================================

    @Bean(destroyMethod = "close")
    public RestClient osLowLevel(OpenSearchProps props) {
        Objects.requireNonNull(props.getEndpoints(), "endpoints");
        if (props.getEndpoints().isEmpty()) {
            throw new IllegalStateException("OpenSearch endpoints are not configured");
        }

        List<HttpHost> hosts = new ArrayList<>();
        for (String ep : props.getEndpoints()) {
            hosts.add(HttpHost.create(ep));
        }

        RestClient.Builder builder = RestClient.builder(hosts.toArray(HttpHost[]::new))
                .setRequestConfigCallback(cfg -> cfg
                        .setConnectTimeout(Math.toIntExact(props.getConnectTimeout().toMillis()))
                        .setSocketTimeout(Math.toIntExact(props.getSocketTimeout().toMillis()))
                        .setConnectionRequestTimeout(Math.toIntExact(props.getConnectionRequestTimeout().toMillis()))
                )
                .setHttpClientConfigCallback(http -> {
                    // Disable auth caching, set max conn per route if needed
                    http.disableAuthCaching();
                    http.setMaxConnPerRoute(props.getMaxConnPerRoute());
                    http.setMaxConnTotal(props.getMaxConnTotal());
                    // TLS trust store if provided
                    SSLContext ssl = sslContext(props);
                    if (ssl != null) {
                        http.setSSLContext(ssl);
                    }
                    // Auth headers
                    List<Header> defaultHeaders = new ArrayList<>();
                    switch (props.getAuth().getType()) {
                        case BASIC -> {
                            String token = Base64.getEncoder().encodeToString(
                                    (props.getAuth().getUsername() + ":" + props.getAuth().getPassword())
                                            .getBytes(StandardCharsets.UTF_8));
                            defaultHeaders.add(new BasicHeader("Authorization", "Basic " + token));
                        }
                        case BEARER -> {
                            defaultHeaders.add(new BasicHeader("Authorization", "Bearer " + props.getAuth().getBearerToken()));
                        }
                        case NONE -> { /* no-op */ }
                    }
                    if (!defaultHeaders.isEmpty()) {
                        http.setDefaultHeaders(defaultHeaders.toArray(Header[]::new));
                    }
                    return http;
                })
                .setStrictDeprecationMode(false) // avoid throwing on 299 headers; handle in telemetry if desired
                .setMaxRetryTimeout(Math.toIntExact(props.getMaxRetryTimeout().toMillis()));

        return builder.build();
    }

    @Bean(destroyMethod = "close")
    public OpenSearchTransport osTransport(RestClient lowLevel) {
        return new RestClientTransport(lowLevel, new JacksonJsonpMapper());
    }

    @Bean
    public OpenSearchClient openSearchClient(OpenSearchTransport transport) {
        return new OpenSearchClient(transport);
    }

    // =====================================================================================
    // Public helpers (tenancy & scaffolding)
    // =====================================================================================

    /**
     * Ensures a tenant has the ISM policy, index template, and a bootstrap index with a write alias.
     * Safe to call repeatedly (idempotent).
     */
    public void ensureTenantScaffolding(RestClient low, OpenSearchProps props, String tenantId, Tier tier, String domain) {
        String normalized = validateTenant(tenantId);
        String policyName = policyName(normalized, domain);
        String templateName = templateName(normalized, domain);
        String indexPattern = indexPattern(normalized, domain);
        String alias = aliasName(normalized, domain);

        try {
            // 1) ISM policy (rollover + retention)
            upsertIsmPolicy(low, policyName, props, tier);

            // 2) Index template (attach ISM policy to indices; shards/replicas per tier)
            upsertTemplate(low, templateName, indexPattern, alias, policyName, props, tier);

            // 3) Bootstrap index with write alias if none exists yet
            createBootstrapIndexIfMissing(low, firstIndexName(normalized, domain), alias, props);
            log.info("OpenSearch scaffolding ensured for tenant={}, domain={}, tier={}", normalized, domain, tier);
        } catch (IOException e) {
            throw new RuntimeException("OpenSearch scaffolding failed for tenant=" + tenantId, e);
        }
    }

    /** Index alias used for writes (stable across rollovers). */
    public String aliasName(String tenantId, String domain) {
        return "tenant-" + validateTenant(tenantId) + "-" + domain;
    }

    /** Index pattern for templates (data indices). */
    public String indexPattern(String tenantId, String domain) {
        return "tenant-" + validateTenant(tenantId) + "-" + domain + "-*";
    }

    /** Compute the first physical index name (bootstrap) using date suffix (daily) or sequence. */
    public String firstIndexName(String tenantId, String domain) {
        if (Boolean.TRUE.equals(OpenSearchProps.RollStrategy.DAILY.equals(OpenSearchProps.RollStrategy.DAILY))) {
            // Keep the daily format option visible; default props pick the strategy.
        }
        // Default bootstrap with sequence "000001" to allow ISM rollover to "-000002", etc.
        return "tenant-" + validateTenant(tenantId) + "-" + domain + "-000001";
    }

    /** Resolve today's date-based index (useful for read-only naming styles). */
    public String dateIndex(String tenantId, String domain, LocalDate date) {
        return "tenant-" + validateTenant(tenantId) + "-" + domain + "-" + DATE.format(date);
    }

    public String templateName(String tenantId, String domain) {
        return "tpl-tenant-" + validateTenant(tenantId) + "-" + domain;
    }

    public String policyName(String tenantId, String domain) {
        return "pol-tenant-" + validateTenant(tenantId) + "-" + domain;
    }

    // =====================================================================================
    // Low-level calls (ISM + templates)
    // =====================================================================================

    private void upsertIsmPolicy(RestClient low, String policyName, OpenSearchProps props, Tier tier) throws IOException {
        // ISM endpoint: /_plugins/_ism/policies/{policyName}
        // Rollover conditions and retention window per tier
        String json = """
            {
              "policy": {
                "description": "VeggieShop tenant policy (rollover + retention)",
                "default_state": "hot",
                "ism_template": [],
                "states": [
                  {
                    "name": "hot",
                    "actions": [
                      { "rollover": {
                          "min_size": "%s",
                          "min_index_age": "%s"
                        }
                      }
                    ],
                    "transitions": [
                      { "state_name": "delete", "conditions": {
                          "min_index_age": "%s"
                        }
                      }
                    ]
                  },
                  {
                    "name": "delete",
                    "actions": [ { "delete": {} } ],
                    "transitions": []
                  }
                ],
                "error_notification": null
              }
            }
            """.formatted(
                props.getRolloverMaxSize(tier),
                props.getRolloverMaxAge(tier),
                props.getRetentionMaxAge(tier)
        );

        var req = new org.apache.http.client.methods.HttpPut("/_plugins/_ism/policies/" + policyName);
        req.setHeader("Content-Type", "application/json");
        req.setEntity(new org.apache.http.entity.StringEntity(json, StandardCharsets.UTF_8));
        try (var resp = low.getLowLevelClient().performRequest(req)) {
            int code = resp.getStatusLine().getStatusCode();
            if (code == 200 || code == 201) {
                log.debug("ISM policy upserted: {}", policyName);
            } else if (code == 409) {
                log.debug("ISM policy exists: {}", policyName);
            } else {
                log.warn("ISM policy upsert returned status={} for policy={}", code, policyName);
            }
        }
    }

    private void upsertTemplate(RestClient low,
                                String templateName,
                                String indexPattern,
                                String alias,
                                String policyName,
                                OpenSearchProps props,
                                Tier tier) throws IOException {

        int shards = props.getShards(tier);
        int replicas = props.getReplicas(tier);

        // Composable index template (v2) binding the ISM policy and defaults
        String json = """
            {
              "index_patterns": ["%s"],
              "template": {
                "settings": {
                  "index.number_of_shards": %d,
                  "index.number_of_replicas": %d,
                  "index.refresh_interval": "%s",
                  "index.routing.allocation.require._tier_preference": "%s",
                  "index.plugins.index_state_management.policy_id": "%s",
                  "index.codec": "best_compression"
                },
                "mappings": {
                  "_source": { "enabled": true },
                  "dynamic": "false"
                },
                "aliases": {
                  "%s": { "is_write_index": true }
                }
              },
              "priority": %d,
              "version": %d,
              "_meta": {
                "owner": "veggieshop",
                "purpose": "tenant data projection",
                "pii": false
              }
            }
            """.formatted(
                indexPattern,
                shards,
                replicas,
                props.getRefreshInterval(),
                props.getPreferredTier(),
                policyName,
                alias,
                props.getTemplatePriority(),
                props.getTemplateVersion()
        );

        var req = new org.apache.http.client.methods.HttpPut("/_index_template/" + templateName);
        req.setHeader("Content-Type", "application/json");
        req.setEntity(new org.apache.http.entity.StringEntity(json, StandardCharsets.UTF_8));
        try (var resp = low.getLowLevelClient().performRequest(req)) {
            int code = resp.getStatusLine().getStatusCode();
            if (code == 200 || code == 201) {
                log.debug("Index template upserted: {}", templateName);
            } else {
                log.warn("Index template upsert returned status={} for template={}", code, templateName);
            }
        }
    }

    private void createBootstrapIndexIfMissing(RestClient low, String indexName, String writeAlias, OpenSearchProps props) throws IOException {
        // HEAD index
        var head = new org.apache.http.client.methods.HttpHead("/" + indexName);
        try (var resp = low.getLowLevelClient().performRequest(head)) {
            int code = resp.getStatusLine().getStatusCode();
            if (code == 200) {
                log.debug("Bootstrap index exists: {}", indexName);
                return;
            }
        } catch (org.opensearch.client.ResponseException notFound) {
            // proceed to create
        }

        String body = """
            {
              "aliases": {
                "%s": { "is_write_index": true }
              }
            }
            """.formatted(writeAlias);

        var put = new org.apache.http.client.methods.HttpPut("/" + indexName);
        put.setHeader("Content-Type", "application/json");
        put.setEntity(new org.apache.http.entity.StringEntity(body, StandardCharsets.UTF_8));
        try (var resp = low.getLowLevelClient().performRequest(put)) {
            int code = resp.getStatusLine().getStatusCode();
            if (code == 200 || code == 201) {
                log.info("Bootstrap index created: {} (alias={})", indexName, writeAlias);
            } else {
                log.warn("Bootstrap index create returned status={} for index={}", code, indexName);
            }
        }
    }

    // =====================================================================================
    // Utilities
    // =====================================================================================

    private static String validateTenant(String tenantId) {
        Objects.requireNonNull(tenantId, "tenantId");
        String t = tenantId.trim().toLowerCase(Locale.ROOT);
        if (!TENANT_ID.matcher(t).matches()) {
            throw new IllegalArgumentException("Invalid tenantId format");
        }
        return t;
    }

    private SSLContext sslContext(OpenSearchProps props) {
        if (!props.isSslEnabled()) return null;
        try {
            if (props.getTruststorePath() == null) {
                // Default JVM trust; return null to use HTTP client defaults
                return null;
            }
            KeyStore ts = KeyStore.getInstance("JKS");
            try (InputStream in = props.getTruststorePath().getInputStream()) {
                ts.load(in, props.getTruststorePassword() != null ? props.getTruststorePassword().toCharArray() : null);
            }
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(ts);
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, tmf.getTrustManagers(), null);
            return ctx;
        } catch (Exception e) {
            throw new IllegalStateException("Failed to initialize SSL context for OpenSearch", e);
        }
    }

    // =====================================================================================
    // Properties
    // =====================================================================================

    /**
     * OpenSearch client and ISM/template defaults.
     *
     * Example:
     *  veggieshop.search:
     *    endpoints: ["https://os:9200"]
     *    auth:
     *      type: BASIC
     *      username: "svc"
     *      password: "****"
     *    connect-timeout: 500ms
     *    socket-timeout: 3s
     *    max-retry-timeout: 5s
     *    max-conn-total: 200
     *    max-conn-per-route: 100
     *    refresh-interval: 1s
     *    preferred-tier: "data_content"
     *    template-priority: 500
     *    template-version: 1
     *    ilm:
     *      standard:
     *        rollover-max-size: "50gb"
     *        rollover-max-age: "7d"
     *        retention-max-age: "30d"
     *        shards: 1
     *        replicas: 1
     *      enterprise:
     *        rollover-max-size: "100gb"
     *        rollover-max-age: "7d"
     *        retention-max-age: "90d"
     *        shards: 3
     *        replicas: 1
     */
    @ConfigurationProperties(prefix = "veggieshop.search")
    public static class OpenSearchProps {

        /** OpenSearch HTTPS endpoints (e.g., https://host:9200). */
        private List<String> endpoints = List.of("http://localhost:9200");

        /** Enable TLS with optional custom truststore (JKS). If truststorePath is null, JVM default trust is used. */
        private boolean sslEnabled = true;

        /** Spring Resource to JKS truststore (optional). */
        private org.springframework.core.io.Resource truststorePath;

        /** Password for the truststore (optional). */
        private String truststorePassword;

        /** HTTP connection timeouts/settings. */
        private Duration connectTimeout = Duration.ofMillis(500);
        private Duration socketTimeout = Duration.ofSeconds(3);
        private Duration connectionRequestTimeout = Duration.ofSeconds(2);
        private Duration maxRetryTimeout = Duration.ofSeconds(5);
        private int maxConnTotal = 200;
        private int maxConnPerRoute = 100;

        /** Auth configuration. */
        private Auth auth = new Auth();

        /** Desired refresh interval for tenant indices. */
        private String refreshInterval = "1s";

        /** Data tier preference (if configured in the cluster). */
        private String preferredTier = "data_content";

        /** Template management. */
        private int templatePriority = 500;
        private int templateVersion = 1;

        /** ILM/ISM policies per tier. */
        private Ilm standard = Ilm.standardDefault();
        private Ilm enterprise = Ilm.enterpriseDefault();

        // ---- getters/setters

        public List<String> getEndpoints() { return endpoints; }
        public void setEndpoints(List<String> endpoints) { this.endpoints = endpoints; }

        public boolean isSslEnabled() { return sslEnabled; }
        public void setSslEnabled(boolean sslEnabled) { this.sslEnabled = sslEnabled; }

        public org.springframework.core.io.Resource getTruststorePath() { return truststorePath; }
        public void setTruststorePath(org.springframework.core.io.Resource truststorePath) { this.truststorePath = truststorePath; }

        public String getTruststorePassword() { return truststorePassword; }
        public void setTruststorePassword(String truststorePassword) { this.truststorePassword = truststorePassword; }

        public Duration getConnectTimeout() { return connectTimeout; }
        public void setConnectTimeout(Duration connectTimeout) { this.connectTimeout = connectTimeout; }
        public Duration getSocketTimeout() { return socketTimeout; }
        public void setSocketTimeout(Duration socketTimeout) { this.socketTimeout = socketTimeout; }
        public Duration getConnectionRequestTimeout() { return connectionRequestTimeout; }
        public void setConnectionRequestTimeout(Duration connectionRequestTimeout) { this.connectionRequestTimeout = connectionRequestTimeout; }
        public Duration getMaxRetryTimeout() { return maxRetryTimeout; }
        public void setMaxRetryTimeout(Duration maxRetryTimeout) { this.maxRetryTimeout = maxRetryTimeout; }

        public int getMaxConnTotal() { return maxConnTotal; }
        public void setMaxConnTotal(int maxConnTotal) { this.maxConnTotal = maxConnTotal; }
        public int getMaxConnPerRoute() { return maxConnPerRoute; }
        public void setMaxConnPerRoute(int maxConnPerRoute) { this.maxConnPerRoute = maxConnPerRoute; }

        public Auth getAuth() { return auth; }
        public void setAuth(Auth auth) { this.auth = auth; }

        public String getRefreshInterval() { return refreshInterval; }
        public void setRefreshInterval(String refreshInterval) { this.refreshInterval = refreshInterval; }

        public String getPreferredTier() { return preferredTier; }
        public void setPreferredTier(String preferredTier) { this.preferredTier = preferredTier; }

        public int getTemplatePriority() { return templatePriority; }
        public void setTemplatePriority(int templatePriority) { this.templatePriority = templatePriority; }

        public int getTemplateVersion() { return templateVersion; }
        public void setTemplateVersion(int templateVersion) { this.templateVersion = templateVersion; }

        public String getRolloverMaxSize(Tier tier) { return tier == Tier.ENTERPRISE ? enterprise.rolloverMaxSize : standard.rolloverMaxSize; }
        public String getRolloverMaxAge(Tier tier)  { return tier == Tier.ENTERPRISE ? enterprise.rolloverMaxAge  : standard.rolloverMaxAge; }
        public String getRetentionMaxAge(Tier tier) { return tier == Tier.ENTERPRISE ? enterprise.retentionMaxAge : standard.retentionMaxAge; }
        public int getShards(Tier tier)             { return tier == Tier.ENTERPRISE ? enterprise.shards          : standard.shards; }
        public int getReplicas(Tier tier)           { return tier == Tier.ENTERPRISE ? enterprise.replicas        : standard.replicas; }

        // ---- nested types

        public static final class Auth {
            public enum Type { NONE, BASIC, BEARER }
            private Type type = Type.NONE;
            private String username;
            private String password;
            private String bearerToken;

            public Type getType() { return type; }
            public void setType(Type type) { this.type = type; }
            public String getUsername() { return username; }
            public void setUsername(String username) { this.username = username; }
            public String getPassword() { return password; }
            public void setPassword(String password) { this.password = password; }
            public String getBearerToken() { return bearerToken; }
            public void setBearerToken(String bearerToken) { this.bearerToken = bearerToken; }
        }

        /** Rollover/retention + topology per tier. */
        public static final class Ilm {
            private String rolloverMaxSize;
            private String rolloverMaxAge;
            private String retentionMaxAge;
            private int shards;
            private int replicas;

            public static Ilm standardDefault() {
                Ilm i = new Ilm();
                i.rolloverMaxSize = "50gb";
                i.rolloverMaxAge  = "7d";
                i.retentionMaxAge = "30d";
                i.shards = 1;
                i.replicas = 1;
                return i;
            }

            public static Ilm enterpriseDefault() {
                Ilm i = new Ilm();
                i.rolloverMaxSize = "100gb";
                i.rolloverMaxAge  = "7d";
                i.retentionMaxAge = "90d";
                i.shards = 3;
                i.replicas = 1;
                return i;
            }
        }

        /** Selection for index naming style if needed later. */
        public enum RollStrategy { SEQUENCE, DAILY }
    }

    /** Service tier to drive ILM/replicas/shards policy. */
    public enum Tier { STANDARD, ENTERPRISE }
}

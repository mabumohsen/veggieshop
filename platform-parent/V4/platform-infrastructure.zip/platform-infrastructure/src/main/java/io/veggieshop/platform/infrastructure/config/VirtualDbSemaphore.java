package io.veggieshop.platform.infrastructure.config;

import com.zaxxer.hikari.HikariDataSource;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.Timer;
import io.micrometer.core.instrument.Gauge;
import jakarta.annotation.Nullable;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.*;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.*;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

import javax.sql.DataSource;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * VirtualDbSemaphore
 *
 * Enterprise-grade DB bulkhead to cap concurrency towards the database in a Servlet + Virtual Threads model.
 * This protects the DB and the connection pool from overload during spikes or hot-key events.
 *
 * PRD alignment:
 * - Deadlock/Starvation policy and bounded concurrency towards DB (PRD §6, §16)
 * - Works with Virtual Threads; keeps the number of concurrent DB-bound sections in check
 * - Observability via Micrometer metrics (optional) (PRD §17)
 *
 * Usage:
 *  - Programmatic: inject DbBulkhead and wrap DB-bound code via run/submit/call or try-with-resources guard().
 *  - Declarative: annotate methods with @DbLimited; the Aspect will guard them automatically.
 *
 * Since: 2.0
 */
@Configuration
@EnableConfigurationProperties(VirtualDbSemaphore.DbBulkheadProperties.class)
public class VirtualDbSemaphore {

    private static final Logger log = LoggerFactory.getLogger(VirtualDbSemaphore.class);

    // -------------------------------------------------------------------------
    // Bean factory
    // -------------------------------------------------------------------------

    @Bean
    @ConditionalOnMissingBean
    public DbBulkhead dbBulkhead(DbBulkheadProperties props,
                                 ObjectProvider<DataSource> dataSource,
                                 ObjectProvider<MeterRegistry> registry) {
        int computedLimit = computeLimit(props, dataSource.getIfAvailable());
        DbBulkhead bulkhead = new DbBulkhead(computedLimit, props.isFair(), props.getAcquireTimeout(),
                props.getPolicy(), registry.getIfAvailable());
        log.info("DB Bulkhead initialized: limit={}, fair={}, acquireTimeout={}, policy={}",
                computedLimit, props.isFair(), props.getAcquireTimeout(), props.getPolicy());
        return bulkhead;
    }

    @Bean
    @ConditionalOnClass(name = "org.aspectj.lang.JoinPoint")
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.db.bulkhead", name = "aspect-enabled", havingValue = "true", matchIfMissing = true)
    public DbBulkheadAspect dbBulkheadAspect(DbBulkhead bulkhead) {
        return new DbBulkheadAspect(bulkhead);
    }

    private static int computeLimit(DbBulkheadProperties props, @Nullable DataSource ds) {
        if (!props.isEnabled()) {
            return Integer.MAX_VALUE; // effectively no limit
        }
        if (props.getMaxConcurrent() > 0) {
            return props.getMaxConcurrent();
        }
        // Heuristic: if Hikari is present, start from maximumPoolSize and apply headroom multiplier.
        int base = 32; // sensible default if we know nothing
        if (ds instanceof HikariDataSource hikari) {
            base = Math.max(1, hikari.getMaximumPoolSize());
        }
        // Ensure [min..max] bounds and apply multiplier (>=1.0)
        double mult = Math.max(1.0, props.getHeadroomMultiplier());
        long candidate = Math.round(Math.floor(base * mult));
        int bounded = (int) Math.max(props.getMinBound(), Math.min(props.getMaxBound(), candidate));
        return Math.max(1, bounded);
    }

    // -------------------------------------------------------------------------
    // Public API (bean)
    // -------------------------------------------------------------------------

    /**
     * Bulkhead guarding DB-bound sections. Thread-safe.
     */
    public static final class DbBulkhead {

        private final Semaphore semaphore;
        private final int limit;
        private final boolean fair;
        private final Duration acquireTimeout;
        private final Policy policy;

        // Metrics (optional)
        @Nullable private final MeterRegistry registry;
        @Nullable private final Counter acquired;
        @Nullable private final Counter rejected;
        @Nullable private final Counter timeouts;
        @Nullable private final Timer waitTimer;
        private final AtomicInteger inUse = new AtomicInteger();

        DbBulkhead(int limit, boolean fair, Duration acquireTimeout, Policy policy, @Nullable MeterRegistry registry) {
            this.limit = limit;
            this.fair = fair;
            this.acquireTimeout = Objects.requireNonNull(acquireTimeout);
            this.policy = Objects.requireNonNull(policy);
            this.semaphore = new Semaphore(limit, fair);

            this.registry = registry;
            if (registry != null) {
                Tags tags = Tags.empty();
                Gauge.builder("db.bulkhead.available", semaphore, s -> s.availablePermits())
                        .description("Available DB bulkhead permits")
                        .register(registry);
                Gauge.builder("db.bulkhead.inuse", inUse, AtomicInteger::get)
                        .description("In-use DB bulkhead permits")
                        .register(registry);
                Gauge.builder("db.bulkhead.limit", () -> this.limit)
                        .description("Configured DB bulkhead limit")
                        .register(registry);

                this.acquired = Counter.builder("db.bulkhead.acquired").tags(tags)
                        .description("Successful bulkhead acquisitions").register(registry);
                this.rejected = Counter.builder("db.bulkhead.rejected").tags(tags)
                        .description("Rejected due to bulkhead policy").register(registry);
                this.timeouts = Counter.builder("db.bulkhead.timeouts").tags(tags)
                        .description("Timed out waiting for bulkhead").register(registry);
                this.waitTimer = Timer.builder("db.bulkhead.wait")
                        .description("Time spent waiting for a bulkhead permit")
                        .publishPercentileHistogram()
                        .register(registry);
            } else {
                this.acquired = this.rejected = this.timeouts = null;
                this.waitTimer = null;
            }
        }

        /** Maximum concurrent sections allowed. */
        public int limit() { return limit; }

        /** Currently available permits. */
        public int available() { return semaphore.availablePermits(); }

        /** Guard block that acquires a permit and releases on close (try-with-resources). */
        public Guard guard() {
            long start = System.nanoTime();
            boolean ok;
            try {
                ok = semaphore.tryAcquire(acquireTimeout.toNanos(), TimeUnit.NANOSECONDS);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                ok = false;
            }
            recordWait(start, ok);
            if (!ok) {
                if (policy == Policy.FAIL_FAST || policy == Policy.TIMEOUT_FAIL) {
                    if (timeouts != null) timeouts.increment();
                    if (rejected != null) rejected.increment();
                    throw new DbConcurrencyLimitExceededException("DB bulkhead limit reached (timeout=" + acquireTimeout + ")");
                } else {
                    // Should not happen: WAIT policy uses tryAcquire with timeout; treat as failure.
                    if (rejected != null) rejected.increment();
                    throw new DbConcurrencyLimitExceededException("DB bulkhead rejected");
                }
            }
            inUse.incrementAndGet();
            if (acquired != null) acquired.increment();
            return new Guard(this);
        }

        /** Execute a Runnable under the bulkhead. */
        public void run(Runnable task) {
            try (Guard ignored = guard()) {
                task.run();
            }
        }

        /** Execute a Supplier under the bulkhead. */
        public <T> T call(Supplier<T> task) {
            try (Guard ignored = guard()) {
                return task.get();
            }
        }

        private void releaseInternal() {
            inUse.decrementAndGet();
            semaphore.release();
        }

        private void recordWait(long startNanos, boolean success) {
            if (waitTimer != null) {
                waitTimer.record(System.nanoTime() - startNanos, TimeUnit.NANOSECONDS);
            }
            if (!success && timeouts != null) timeouts.increment();
        }

        /** Auto-closeable guard for try-with-resources. */
        public static final class Guard implements AutoCloseable {
            private final DbBulkhead owner;
            private boolean released;

            Guard(DbBulkhead owner) { this.owner = owner; }

            @Override public void close() {
                if (!released) {
                    released = true;
                    owner.releaseInternal();
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Annotation + Aspect (optional declarative usage)
    // -------------------------------------------------------------------------

    /**
     * Annotate methods that are expected to perform DB-bound work (repositories, services).
     * The aspect will guard execution with the bulkhead and apply the configured policy.
     */
    @Documented
    @Retention(RetentionPolicy.RUNTIME)
    @Target({ElementType.METHOD, ElementType.TYPE})
    public @interface DbLimited { }

    @Aspect
    @Order(Ordered.HIGHEST_PRECEDENCE + 50) // early to cap concurrency before deeper stacks
    public static class DbBulkheadAspect implements AopInfrastructureBean {
        private final DbBulkhead bulkhead;

        public DbBulkheadAspect(DbBulkhead bulkhead) {
            this.bulkhead = Objects.requireNonNull(bulkhead);
        }

        @Around("@within(io.veggieshop.platform.infrastructure.config.VirtualDbSemaphore.DbLimited) || " +
                "@annotation(io.veggieshop.platform.infrastructure.config.VirtualDbSemaphore.DbLimited)")
        public Object limit(ProceedingJoinPoint pjp) throws Throwable {
            try (DbBulkhead.Guard ignored = bulkhead.guard()) {
                return pjp.proceed();
            } catch (DbConcurrencyLimitExceededException ex) {
                // Surface as RejectedExecutionException to integrate with retry/backoff policies if needed.
                throw new RejectedExecutionException(ex.getMessage(), ex);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Properties
    // -------------------------------------------------------------------------

    /**
     * Configuration for the DB bulkhead (virtual DB semaphore).
     *
     * Properties:
     *  veggieshop.db.bulkhead.enabled=true
     *  veggieshop.db.bulkhead.max-concurrent=0            # 0 -> derive from Hikari maximumPoolSize
     *  veggieshop.db.bulkhead.headroom-multiplier=1.25    # limit ~= pool * 1.25
     *  veggieshop.db.bulkhead.min-bound=8
     *  veggieshop.db.bulkhead.max-bound=128
     *  veggieshop.db.bulkhead.fair=true
     *  veggieshop.db.bulkhead.acquire-timeout=200ms
     *  veggieshop.db.bulkhead.policy=TIMEOUT_FAIL         # WAIT | TIMEOUT_FAIL | FAIL_FAST
     *  veggieshop.db.bulkhead.aspect-enabled=true
     */
    @ConfigurationProperties(prefix = "veggieshop.db.bulkhead")
    public static class DbBulkheadProperties {

        private boolean enabled = true;

        /** Hard cap; if 0 or negative, the cap is derived from Hikari maximumPoolSize. */
        private int maxConcurrent = 0;

        /** Derivation multiplier applied to the pool size when maxConcurrent <= 0. Minimum 1.0. */
        private double headroomMultiplier = 1.25d;

        /** Lower/upper bounds when deriving the cap. */
        private int minBound = 8;
        private int maxBound = 128;

        /** Fair semaphore (FIFO) to avoid starvation under contention. */
        private boolean fair = true;

        /** Time to wait for a permit. */
        private Duration acquireTimeout = Duration.ofMillis(200);

        /** Policy to apply when a permit cannot be obtained. */
        private Policy policy = Policy.TIMEOUT_FAIL;

        /** Enable the @DbLimited Aspect. */
        private boolean aspectEnabled = true;

        // getters/setters
        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public int getMaxConcurrent() { return maxConcurrent; }
        public void setMaxConcurrent(int maxConcurrent) { this.maxConcurrent = maxConcurrent; }
        public double getHeadroomMultiplier() { return headroomMultiplier; }
        public void setHeadroomMultiplier(double headroomMultiplier) { this.headroomMultiplier = headroomMultiplier; }
        public int getMinBound() { return minBound; }
        public void setMinBound(int minBound) { this.minBound = minBound; }
        public int getMaxBound() { return maxBound; }
        public void setMaxBound(int maxBound) { this.maxBound = maxBound; }
        public boolean isFair() { return fair; }
        public void setFair(boolean fair) { this.fair = fair; }
        public Duration getAcquireTimeout() { return acquireTimeout; }
        public void setAcquireTimeout(Duration acquireTimeout) { this.acquireTimeout = acquireTimeout; }
        public Policy getPolicy() { return policy; }
        public void setPolicy(Policy policy) { this.policy = policy; }
        public boolean isAspectEnabled() { return aspectEnabled; }
        public void setAspectEnabled(boolean aspectEnabled) { this.aspectEnabled = aspectEnabled; }
    }

    /** Behavior when a permit cannot be obtained. */
    public enum Policy {
        /** Block up to acquireTimeout; if still unavailable, throw. */
        TIMEOUT_FAIL,
        /** Throw immediately without waiting. (Not used by default with tryAcquire+timeout.) */
        FAIL_FAST,
        /** Block indefinitely (discouraged). */
        WAIT
    }

    /** Exception thrown when the DB bulkhead rejects execution. */
    public static final class DbConcurrencyLimitExceededException extends RuntimeException {
        public DbConcurrencyLimitExceededException(String message) { super(message); }
    }
}

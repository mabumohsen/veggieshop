package io.veggieshop.platform.messaging.outbox;

import io.micrometer.core.instrument.MeterRegistry;
import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.lang.Nullable;

import java.time.Clock;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import static java.lang.Math.min;

/**
 * Plain scheduler facade: يستدعى من TaskScheduler في الـstarter.
 * لا يحتوي أي @Scheduled/@Value/@Component.
 */
public class OutboxDrainScheduler {

    private static final Logger log = LoggerFactory.getLogger(OutboxDrainScheduler.class);

    private final OutboxPublisher outboxPublisher;
    private final MeterRegistry metrics;
    private final Tracer tracer;
    private final Clock clock;
    private final JdbcTemplate jdbc;

    private final boolean enabled;
    private final int burstBatches;
    private final Duration maxBurstDuration;
    private final Duration idleSleep;
    private final boolean backlogMetricsEnabled;
    private final String outboxTable;

    private final AtomicBoolean inFlight = new AtomicBoolean(false);
    private volatile int emptyStreak = 0;

    public OutboxDrainScheduler(OutboxPublisher outboxPublisher,
                                MeterRegistry meterRegistry,
                                Clock clock,
                                JdbcTemplate jdbc,
                                boolean enabled,
                                int burstBatches,
                                Duration maxBurstDuration,
                                Duration idleSleep,
                                boolean backlogMetricsEnabled,
                                String outboxTable) {
        this.outboxPublisher = Objects.requireNonNull(outboxPublisher, "outboxPublisher");
        this.metrics = Objects.requireNonNull(meterRegistry, "meterRegistry");
        this.tracer = GlobalOpenTelemetry.get().getTracer("io.veggieshop.platform.outbox");
        this.clock = Objects.requireNonNull(clock, "clock");
        this.jdbc = Objects.requireNonNull(jdbc, "jdbc");
        this.enabled = enabled;
        this.burstBatches = burstBatches;
        this.maxBurstDuration = Objects.requireNonNull(maxBurstDuration, "maxBurstDuration");
        this.idleSleep = Objects.requireNonNull(idleSleep, "idleSleep");
        this.backlogMetricsEnabled = backlogMetricsEnabled;
        this.outboxTable = Objects.requireNonNull(outboxTable, "outboxTable");

        log.info("outbox_scheduler_init enabled={} burstBatches={} maxBurst={} idleSleep={} backlogMetricsEnabled={} table={}",
                enabled, burstBatches, maxBurstDuration, idleSleep, backlogMetricsEnabled, outboxTable);
    }

    /** تستدعى دوريًا من TaskScheduler في الـstarter. */
    public void tick() {
        if (!enabled) return;
        if (!inFlight.compareAndSet(false, true)) {
            metrics.counter("outbox.scheduler.skipped.overlap").increment();
            return;
        }

        final long wallStart = System.nanoTime();
        final Span tick = tracer.spanBuilder("outbox.scheduler.tick").setSpanKind(SpanKind.INTERNAL).startSpan();

        int totalPublished = 0;
        int totalAttempts = 0;
        int loops = 0;

        try {
            if (backlogMetricsEnabled) {
                Long backlog = estimateBacklog();
                if (backlog != null) {
                    metrics.gauge("outbox.backlog", backlog);
                    tick.setAttribute("outbox.backlog", backlog);
                }
            }

            final long maxBurstNanos = maxBurstDuration.toNanos();
            final long burstStart = System.nanoTime();
            final int window = min(Math.max(burstBatches, 1), 20);

            for (int i = 0; i < window; i++) {
                loops++;
                totalAttempts++;
                int published = outboxPublisher.drainOnce();
                totalPublished += published;

                if (published == 0) break;
                if ((System.nanoTime() - burstStart) > maxBurstNanos) break;
            }

            if (totalPublished == 0) {
                emptyStreak = Math.min(emptyStreak + 1, 5);
                long boundedMs = Math.min(idleSleep.multipliedBy(emptyStreak).toMillis(),
                        idleSleep.multipliedBy(5).toMillis());
                if (boundedMs > 0) {
                    try { Thread.sleep(boundedMs); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
                }
            } else {
                emptyStreak = 0;
            }

            tick.setAttribute("outbox.published", totalPublished);
            tick.setAttribute("outbox.attempts", totalAttempts);
            tick.setAttribute("outbox.loops", loops);
            tick.setStatus(StatusCode.OK);
            metrics.counter("outbox.scheduler.ticks").increment();
            metrics.counter("outbox.scheduler.published").increment(totalPublished);
            metrics.summary("outbox.scheduler.published.per.tick").record(totalPublished);

        } catch (Exception e) {
            tick.recordException(e);
            tick.setStatus(StatusCode.ERROR, safeMsg(e));
            io.micrometer.core.instrument.Counter.builder("outbox.scheduler.error")
                    .tag("class", e.getClass().getSimpleName())
                    .register(metrics)
                    .increment();
            log.warn("outbox_scheduler_tick_error class={} msg={}", e.getClass().getSimpleName(), safeMsg(e));
        } finally {
            long wallNs = System.nanoTime() - wallStart;
            metrics.timer("outbox.scheduler.tick.latency").record(wallNs, TimeUnit.NANOSECONDS);
            tick.end();
            inFlight.set(false);
        }
    }

    @Nullable
    private Long estimateBacklog() {
        try {
            String sql = """
                SELECT count(*) FROM %s
                WHERE status IN ('NEW','RETRY') AND next_attempt_at <= now()
                """.formatted(outboxTable);
            return jdbc.queryForObject(sql, Long.class);
        } catch (Exception e) {
            metrics.counter("outbox.scheduler.backlog.query_error").increment();
            return null;
        }
    }

    private static String safeMsg(Throwable t) {
        String m = t.getMessage();
        if (m == null || m.isBlank()) return t.getClass().getSimpleName();
        return m.length() > 400 ? m.substring(0, 400) + "..." : m;
    }
}

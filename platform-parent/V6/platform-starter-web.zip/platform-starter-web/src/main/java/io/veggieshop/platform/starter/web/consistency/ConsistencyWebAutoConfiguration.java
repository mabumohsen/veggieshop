package io.veggieshop.platform.starter.web.consistency;

import io.veggieshop.platform.application.consistency.ConsistencyProperties;
import io.veggieshop.platform.application.consistency.ConsistencyService;
import io.veggieshop.platform.application.consistency.TokenSigner;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Clock;

@AutoConfiguration
@EnableConfigurationProperties(VeggieConsistencyProperties.class)
public class ConsistencyWebAutoConfiguration {

    @Bean @ConditionalOnMissingBean
    TokenSigner hmacTokenSigner(VeggieConsistencyProperties p) {
        return (kid, payload) -> {
            if (!kid.equals(p.getKid())) throw new IllegalArgumentException("Unknown KID");
            try {
                Mac mac = Mac.getInstance("HmacSHA256");
                mac.init(new SecretKeySpec(p.secretBytes(), "HmacSHA256"));
                return mac.doFinal(payload);
            } catch (Exception e) { throw new IllegalStateException("HMAC failure", e); }
        };
    }

    @Bean @ConditionalOnMissingBean
    ConsistencyService consistencyService(Clock clock, VeggieConsistencyProperties p, TokenSigner signer) {
        ConsistencyProperties app = p.toAppProps();
        return new ConsistencyService(clock, app, signer);
    }

    @Bean
    WebMvcConfigurer consistencyMvc(ConsistencyService service, VeggieConsistencyProperties p,
                                    TenantIdResolver tenantIdResolver) {
        return new WebMvcConfigurer() {
            @Override public void addInterceptors(InterceptorRegistry registry) {
                registry.addInterceptor(new ConsistencyHeadersInterceptor(service, p, tenantIdResolver));
            }
        };
    }

    @Bean @ConditionalOnMissingBean
    TenantIdResolver tenantIdResolver() {
        return request -> null; // وفّر تطبيقًا حقيقيًا يقرأ من SecurityContext/JWT
    }
}

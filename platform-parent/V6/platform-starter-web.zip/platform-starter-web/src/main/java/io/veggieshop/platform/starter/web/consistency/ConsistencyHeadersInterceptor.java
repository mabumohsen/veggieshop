package io.veggieshop.platform.starter.web.consistency;

import io.veggieshop.platform.application.consistency.ConsistencyService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerInterceptor;

final class ConsistencyHeadersInterceptor implements HandlerInterceptor {
    private final ConsistencyService service;
    private final VeggieConsistencyProperties p;
    private final TenantIdResolver tenant;

    ConsistencyHeadersInterceptor(ConsistencyService service, VeggieConsistencyProperties p, TenantIdResolver tenant) {
        this.service = service; this.p = p; this.tenant = tenant;
    }

    @Override public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) {
        String tid = tenant.resolve(req);
        String icw = req.getHeader(p.getHeaderIfConsistentWith());
        String tok = req.getHeader(p.getHeaderConsistencyToken());
        if (tid != null && !tid.isBlank()) {
            service.openRequest(tid, icw, tok);
        }
        return true;
    }

    @Override public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        service.clear();
    }
}

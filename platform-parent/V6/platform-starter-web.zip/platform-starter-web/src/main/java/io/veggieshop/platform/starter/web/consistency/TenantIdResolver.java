package io.veggieshop.platform.starter.web.consistency;

import jakarta.servlet.http.HttpServletRequest;

public interface TenantIdResolver {
    String resolve(HttpServletRequest request);
}

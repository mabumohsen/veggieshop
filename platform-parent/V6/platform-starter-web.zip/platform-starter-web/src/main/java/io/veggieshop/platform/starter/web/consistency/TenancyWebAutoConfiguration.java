package io.veggieshop.platform.starter.web.consistency;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@EnableConfigurationProperties(WebTenancyProperties.class)
public class TenancyWebAutoConfiguration {

    @Bean @ConditionalOnMissingBean
    JwtClaimsExtractor jwtClaimsExtractor() { return JwtClaimsExtractor.noop(); }

    @Bean @ConditionalOnMissingBean
    TenantIdResolver tenantIdResolver(WebTenancyProperties p, JwtClaimsExtractor extractor) {
        return new DefaultTenantIdResolver(p.isEnforceConsistency(), extractor);
    }
}

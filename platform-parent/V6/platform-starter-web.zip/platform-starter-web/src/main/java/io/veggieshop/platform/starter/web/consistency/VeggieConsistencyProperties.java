package io.veggieshop.platform.starter.web.consistency;

import io.veggieshop.platform.application.consistency.ConsistencyProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.Base64;
import java.util.Objects;

@ConfigurationProperties(prefix = "veggieshop.consistency")
public class VeggieConsistencyProperties {
    private Duration window = Duration.ofSeconds(60);
    private String kid = "consistency-default";
    private String secretBase64;

    private String headerIfConsistentWith = "If-Consistent-With";
    private String headerConsistencyToken = "X-Consistency-Token";
    private String headerEtag = "ETag";
    private ConsistencyProperties.IfHeaderPolicy ifHeaderPolicy = ConsistencyProperties.IfHeaderPolicy.ETAG_OR_NUMBER;

    public Duration getWindow(){ return window; }
    public void setWindow(Duration v){ this.window=v; }
    public String getKid(){ return kid; }
    public void setKid(String v){ this.kid=v; }
    public String getSecretBase64(){ return secretBase64; }
    public void setSecretBase64(String v){ this.secretBase64=v; }
    public String getHeaderIfConsistentWith(){ return headerIfConsistentWith; }
    public void setHeaderIfConsistentWith(String v){ this.headerIfConsistentWith=v; }
    public String getHeaderConsistencyToken(){ return headerConsistencyToken; }
    public void setHeaderConsistencyToken(String v){ this.headerConsistencyToken=v; }
    public String getHeaderEtag(){ return headerEtag; }
    public void setHeaderEtag(String v){ this.headerEtag=v; }
    public ConsistencyProperties.IfHeaderPolicy getIfHeaderPolicy(){ return ifHeaderPolicy; }
    public void setIfHeaderPolicy(ConsistencyProperties.IfHeaderPolicy v){ this.ifHeaderPolicy=v; }

    public byte[] secretBytes(){
        Objects.requireNonNull(secretBase64, "veggieshop.consistency.secretBase64 must be set");
        return Base64.getDecoder().decode(secretBase64);
    }

    public ConsistencyProperties toAppProps(){
        return new ConsistencyProperties()
                .window(window)
                .kid(kid)
                .headerIfConsistentWith(headerIfConsistentWith)
                .headerConsistencyToken(headerConsistencyToken)
                .headerEtag(headerEtag)
                .ifHeaderPolicy(ifHeaderPolicy);
    }
}

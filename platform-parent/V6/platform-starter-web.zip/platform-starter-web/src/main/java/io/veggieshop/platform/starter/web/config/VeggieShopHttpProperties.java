package io.veggieshop.platform.starter.web.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.convert.DurationUnit;
import org.springframework.validation.annotation.Validated;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 * Central configuration for VeggieShop HTTP layer (filters, guards & preconditions).
 * <p>
 * Prefix: veggieshop.http
 * <p>
 * This class is defined in platform-api-http (components only).
 * Auto-configuration & wiring happen in platform-starter-web.
 */
@Validated
@ConfigurationProperties(prefix = "veggieshop.http")
public class VeggieShopHttpProperties {

    /**
     * Master switch for the entire HTTP platform layer.
     */
    private boolean enabled = true;

    @Valid
    private final Tenant tenant = new Tenant();
    @Valid
    private final Correlation correlation = new Correlation();
    @Valid
    private final Hmac hmac = new Hmac();
    @Valid
    private final Oidc oidc = new Oidc();
    @Valid
    private final RateLimit rateLimit = new RateLimit();
    @Valid
    private final PiiLog piiLog = new PiiLog();
    @Valid
    private final Cors cors = new Cors();
    @Valid
    private final Consistency consistency = new Consistency();
    @Valid
    private StepUp stepUp = new StepUp();


    // ---------- Getters / Setters ----------
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public Tenant getTenant() {
        return tenant;
    }

    public Correlation getCorrelation() {
        return correlation;
    }

    public Hmac getHmac() {
        return hmac;
    }

    public Oidc getOidc() { return oidc; }

    public RateLimit getRateLimit() {
        return rateLimit;
    }

    public PiiLog getPiiLog() {
        return piiLog;
    }

    public Cors getCors() {
        return cors;
    }

    public Consistency getConsistency() {
        return consistency;
    }

    public StepUp getStepUp() { return stepUp; }
    public void setStepUp(StepUp v) { this.stepUp = v; }

    // ---------- Nested types ----------

    /**
     * Tenant guard & MDC population.
     */
    public static class Tenant {
        private boolean enabled = true;

        /**
         * Header carrying the tenant id.
         */
        @NotBlank
        private String header = "X-Tenant-Id";

        /**
         * Whether the tenant header is required for non-public endpoints.
         */
        private boolean required = true;

        /**
         * MDC key to store the resolved tenant id.
         */
        @NotBlank
        private String mdcKey = "tenantId";

        /**
         * Ant-style patterns considered public (bypass tenant requirement).
         */
        @NotNull
        private List<@NotBlank String> publicPaths = new ArrayList<>(List.of(
                "/actuator/**", "/v3/api-docs/**", "/swagger-ui/**", "/health", "/metrics"
        ));

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getHeader() {
            return header;
        }

        public void setHeader(String header) {
            this.header = header;
        }

        public boolean isRequired() {
            return required;
        }

        public void setRequired(boolean required) {
            this.required = required;
        }

        public String getMdcKey() {
            return mdcKey;
        }

        public void setMdcKey(String mdcKey) {
            this.mdcKey = mdcKey;
        }

        public List<String> getPublicPaths() {
            return publicPaths;
        }

        public void setPublicPaths(List<String> publicPaths) {
            this.publicPaths = publicPaths == null ? new ArrayList<>() : publicPaths;
        }
    }

    /**
     * Correlation-ID generation/propagation.
     */
    public static class Correlation {
        private boolean enabled = true;

        @NotBlank
        private String header = "X-Correlation-Id";
        private boolean generateIfMissing = true;

        public enum Generator {UUID_V4, ULID}

        @NotNull
        private Generator generator = Generator.ULID;

        @NotBlank
        private String mdcKey = "correlationId";

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getHeader() {
            return header;
        }

        public void setHeader(String header) {
            this.header = header;
        }

        public boolean isGenerateIfMissing() {
            return generateIfMissing;
        }

        public void setGenerateIfMissing(boolean generateIfMissing) {
            this.generateIfMissing = generateIfMissing;
        }

        public Generator getGenerator() {
            return generator;
        }

        public void setGenerator(Generator generator) {
            this.generator = generator;
        }

        public String getMdcKey() {
            return mdcKey;
        }

        public void setMdcKey(String mdcKey) {
            this.mdcKey = mdcKey;
        }
    }

    /**
     * HMAC partner authentication.
     */
    public static class Hmac {
        private boolean enabled = false;

        @NotBlank
        private String signatureHeader = "X-Signature";
        @NotBlank
        private String keyIdHeader = "X-Key-Id";
        @NotBlank
        private String timestampHeader = "X-Timestamp";
        @NotBlank
        private String nonceHeader = "X-Hmac-Nonce";

        /**
         * e.g. HmacSHA256, HmacSHA512.
         */
        @NotEmpty
        private Set<@Pattern(regexp = "HmacSHA(256|384|512)") String> acceptedAlgorithms =
                new LinkedHashSet<>(List.of("HmacSHA256"));

        /**
         * Acceptable clock skew on timestamp header.
         */
        @DurationUnit(ChronoUnit.SECONDS)
        @PositiveOrZero
        private Duration clockSkew = Duration.ofSeconds(90);

        /**
         * Message validity window.
         */
        @DurationUnit(ChronoUnit.MINUTES)
        @Positive
        private Duration ttl = Duration.ofMinutes(5);

        /**
         * Require X-Content-SHA256 and verify body hash as part of signature.
         */
        private boolean enforceBodySha256 = false;

        /**
         * Additional headers that must be covered by the signature.
         */
        @NotNull
        private List<@Pattern(regexp = "^[A-Za-z0-9-]+$") String> requiredSignedHeaders = new ArrayList<>();

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getSignatureHeader() {
            return signatureHeader;
        }

        public void setSignatureHeader(String signatureHeader) {
            this.signatureHeader = signatureHeader;
        }

        public String getKeyIdHeader() {
            return keyIdHeader;
        }

        public void setKeyIdHeader(String keyIdHeader) {
            this.keyIdHeader = keyIdHeader;
        }

        public String getTimestampHeader() {
            return timestampHeader;
        }

        public void setTimestampHeader(String timestampHeader) {
            this.timestampHeader = timestampHeader;
        }

        public Set<String> getAcceptedAlgorithms() {
            return acceptedAlgorithms;
        }

        public void setAcceptedAlgorithms(Set<String> acceptedAlgorithms) {
            this.acceptedAlgorithms = acceptedAlgorithms == null ? new LinkedHashSet<>() : acceptedAlgorithms;
        }

        public Duration getClockSkew() {
            return clockSkew;
        }

        public void setClockSkew(Duration clockSkew) {
            this.clockSkew = clockSkew;
        }

        public Duration getTtl() {
            return ttl;
        }

        public void setTtl(Duration ttl) {
            this.ttl = ttl;
        }

        public boolean isEnforceBodySha256() {
            return enforceBodySha256;
        }

        public void setEnforceBodySha256(boolean enforceBodySha256) {
            this.enforceBodySha256 = enforceBodySha256;
        }

        public List<String> getRequiredSignedHeaders() {
            return requiredSignedHeaders;
        }

        public void setRequiredSignedHeaders(List<String> requiredSignedHeaders) {
            this.requiredSignedHeaders = requiredSignedHeaders == null ? new ArrayList<>() : requiredSignedHeaders;
        }

        public String getNonceHeader() { return nonceHeader; }

        public void setNonceHeader(String nonceHeader) { this.nonceHeader = nonceHeader; }

    }

    /**
     * OIDC JWT verification settings used by the servlet filter.
     * The starter should read these properties to build the JWT processor and the filter.
     * - The first item in {@code allowedAlgs} will be enforced as the expected JWS algorithm.
     * - {@code publicPaths} are Ant-style patterns that bypass the filter.
     */
    public static class Oidc {

        /** Enable/disable the OIDC filter. */
        private boolean enabled = false;

        /** OIDC Issuer identifier (required). */
        @NotBlank
        private String issuer;

        /**
         * Optional explicit JWKS URI. If blank, it will be derived from {@code issuer}
         * as {@code <issuer>/.well-known/jwks.json}.
         */
        private String jwksUri;

        /**
         * Allowed JWS algorithms in preference order.
         * The first element will be enforced on incoming tokens.
         */
        @NotNull
        private List<String> allowedAlgs = new ArrayList<>(List.of("RS256", "ES256", "EdDSA"));

        /** Optional audience that must be present in the token. */
        private String audience;

        /** Accepted clock skew when validating exp/nbf. */
        @NotNull
        private Duration clockSkew = Duration.ofSeconds(60);

        /**
         * Ant-style public paths that bypass the filter.
         * Keep actuator and internal endpoints here if you want them unauthenticated.
         */
        @NotNull
        private List<String> publicPaths = new ArrayList<>(List.of(
                "/error",
                "/favicon.ico",
                "/actuator/**",
                "/_internal/**",
                "/internal/**"
        ));

        /** JWKS HTTP connect timeout. */
        @NotNull
        private Duration jwksConnectTimeout = Duration.ofSeconds(2);

        /** JWKS HTTP read timeout. */
        @NotNull
        private Duration jwksReadTimeout = Duration.ofSeconds(2);

        /** Maximum JWKS response size in bytes. */
        private int jwksSizeLimitBytes = 4096;

        /** Require a tenant claim to be present in the token. */
        private boolean requireTenantClaim = true;

        /** Claim name that carries the tenant id. */
        @NotBlank
        private String tenantClaim = "tenantId";

        /** Optional claim name for vendor id. */
        private String vendorClaim = "vendorId";

        /** Claim name that carries roles (if any). */
        private String rolesClaim = "roles";

        /** Claim names that may carry scopes (space-delimited or array). */
        @NotNull
        private List<String> scopeClaims = new ArrayList<>(List.of("scope", "scp"));

        // -------------- Getters / Setters --------------

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }

        public String getIssuer() { return issuer; }
        public void setIssuer(String issuer) { this.issuer = issuer; }

        public String getJwksUri() { return jwksUri; }
        public void setJwksUri(String jwksUri) { this.jwksUri = jwksUri; }

        public List<String> getAllowedAlgs() { return allowedAlgs; }
        public void setAllowedAlgs(List<String> allowedAlgs) { this.allowedAlgs = allowedAlgs; }

        public String getAudience() { return audience; }
        public void setAudience(String audience) { this.audience = audience; }

        public Duration getClockSkew() { return clockSkew; }
        public void setClockSkew(Duration clockSkew) { this.clockSkew = clockSkew; }

        public List<String> getPublicPaths() { return publicPaths; }
        public void setPublicPaths(List<String> publicPaths) { this.publicPaths = publicPaths; }

        public Duration getJwksConnectTimeout() { return jwksConnectTimeout; }
        public void setJwksConnectTimeout(Duration jwksConnectTimeout) { this.jwksConnectTimeout = jwksConnectTimeout; }

        public Duration getJwksReadTimeout() { return jwksReadTimeout; }
        public void setJwksReadTimeout(Duration jwksReadTimeout) { this.jwksReadTimeout = jwksReadTimeout; }

        public int getJwksSizeLimitBytes() { return jwksSizeLimitBytes; }
        public void setJwksSizeLimitBytes(int jwksSizeLimitBytes) { this.jwksSizeLimitBytes = jwksSizeLimitBytes; }

        public boolean isRequireTenantClaim() { return requireTenantClaim; }
        public void setRequireTenantClaim(boolean requireTenantClaim) { this.requireTenantClaim = requireTenantClaim; }

        public String getTenantClaim() { return tenantClaim; }
        public void setTenantClaim(String tenantClaim) { this.tenantClaim = tenantClaim; }

        public String getVendorClaim() { return vendorClaim; }
        public void setVendorClaim(String vendorClaim) { this.vendorClaim = vendorClaim; }

        public String getRolesClaim() { return rolesClaim; }
        public void setRolesClaim(String rolesClaim) { this.rolesClaim = rolesClaim; }

        public List<String> getScopeClaims() { return scopeClaims; }
        public void setScopeClaims(List<String> scopeClaims) { this.scopeClaims = scopeClaims; }
    }

    /**
     * Token-bucket rate limiting + optional response headers.
     */
    public static class RateLimit {
        private boolean enabled = true;

        /**
         * Expose standard X-RateLimit-* headers.
         */
        private boolean headers = true;

        /**
         * Keys composing the bucket id: ip, tenant, header:NAME
         */
        @NotNull
        private List<@Pattern(regexp = "ip|tenant|header:[A-Za-z0-9-]+") String> keys =
                new ArrayList<>(List.of("ip", "tenant"));

        @Valid
        @NotNull
        private Policy _default = Policy.defaults();

        /**
         * Ant patterns -> policy overrides.
         */
        @Valid
        @NotNull
        private Map<String, Policy> overrides = new LinkedHashMap<>();

        /** NEW: Upper bound for in-memory buckets. */
        @Positive
        private int maxBuckets = 200_000;

        /** NEW: Evict idle buckets after this duration. */
        @NotNull
        private Duration idleEvictAfter = Duration.ofMinutes(15);

        public static class Policy {
            /**
             * Max tokens in the bucket (capacity).
             */
            @Positive
            private int capacity = 100;

            /**
             * Tokens added on each refill event.
             */
            @Positive
            private int refillTokens = 100;

            /**
             * Period between refills.
             */
            @DurationUnit(ChronoUnit.SECONDS)
            @Positive
            private Duration refillPeriod = Duration.ofMinutes(1);

            public static Policy defaults() {
                return new Policy();
            }

            public int getCapacity() {
                return capacity;
            }

            public void setCapacity(int capacity) {
                this.capacity = capacity;
            }

            public int getRefillTokens() {
                return refillTokens;
            }

            public void setRefillTokens(int refillTokens) {
                this.refillTokens = refillTokens;
            }

            public Duration getRefillPeriod() {
                return refillPeriod;
            }

            public void setRefillPeriod(Duration refillPeriod) {
                this.refillPeriod = refillPeriod;
            }
        }

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public boolean isHeaders() {
            return headers;
        }

        public void setHeaders(boolean headers) {
            this.headers = headers;
        }

        public List<String> getKeys() {
            return keys;
        }

        public void setKeys(List<String> keys) {
            this.keys = keys == null ? new ArrayList<>() : keys;
        }

        public Policy getDefault() {
            return _default;
        }

        public void setDefault(Policy _default) {
            this._default = (_default == null) ? Policy.defaults() : _default;
        }

        public Map<String, Policy> getOverrides() {
            return overrides;
        }

        public void setOverrides(Map<String, Policy> overrides) {
            this.overrides = overrides == null ? new LinkedHashMap<>() : overrides;
        }

        public int getMaxBuckets() { return maxBuckets; }
        public void setMaxBuckets(int maxBuckets) { this.maxBuckets = maxBuckets; }
        public Duration getIdleEvictAfter() { return idleEvictAfter; }
        public void setIdleEvictAfter(Duration idleEvictAfter) { this.idleEvictAfter = idleEvictAfter; }
    }

    /**
     * PII log guard & redaction.
     */
    public static class PiiLog {
        private boolean enabled = true;

        /**
         * Max characters from payload/body to include in logs (after redaction).
         */
        @Positive
        private int payloadMaxChars = 2048;

        /** NEW: Fail requests that put sensitive credentials in querystring. */
        private boolean rejectSensitiveInQuery = true;

        /**
         * Case-insensitive header names to drop or mask.
         */
        @NotNull
        private Set<String> headerDenylist = new LinkedHashSet<>(List.of(
                "authorization", "cookie", "set-cookie", "x-api-key"
        ));

        /**
         * Regex patterns to redact from payload lines.
         */
        @NotNull
        private List<String> redactPatterns = new ArrayList<>(List.of(
                "\\b[0-9]{13,19}\\b",                              // PAN-like sequences
                "[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"  // emails
        ));

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public int getPayloadMaxChars() {
            return payloadMaxChars;
        }

        public void setPayloadMaxChars(int payloadMaxChars) {
            this.payloadMaxChars = payloadMaxChars;
        }

        public Set<String> getHeaderDenylist() {
            return headerDenylist;
        }

        public void setHeaderDenylist(Set<String> headerDenylist) {
            this.headerDenylist = headerDenylist == null ? new LinkedHashSet<>() : headerDenylist;
        }

        public List<String> getRedactPatterns() {
            return redactPatterns;
        }

        public void setRedactPatterns(List<String> redactPatterns) {
            this.redactPatterns = redactPatterns == null ? new ArrayList<>() : redactPatterns;
        }

        public boolean isRejectSensitiveInQuery() { return rejectSensitiveInQuery; }

        public void setRejectSensitiveInQuery(boolean v) { this.rejectSensitiveInQuery = v; }
    }

    /**
     * CORS (global defaults; app may add fine-grained rules).
     */
    public static class Cors {
        private boolean enabled = true;

        @NotNull
        private List<String> allowedOrigins = new ArrayList<>();
        @NotNull
        private List<String> allowedMethods = new ArrayList<>(List.of("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"));
        @NotNull
        private List<String> allowedHeaders = new ArrayList<>(List.of("Authorization", "Content-Type", "X-Tenant-Id", "X-Correlation-Id"));
        @NotNull
        private List<String> exposedHeaders = new ArrayList<>();
        private boolean allowCredentials = true;

        @DurationUnit(ChronoUnit.SECONDS)
        @Positive
        private Duration maxAge = Duration.ofMinutes(30);

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public List<String> getAllowedOrigins() {
            return allowedOrigins;
        }

        public void setAllowedOrigins(List<String> allowedOrigins) {
            this.allowedOrigins = allowedOrigins == null ? new ArrayList<>() : allowedOrigins;
        }

        public List<String> getAllowedMethods() {
            return allowedMethods;
        }

        public void setAllowedMethods(List<String> allowedMethods) {
            this.allowedMethods = allowedMethods == null ? new ArrayList<>() : allowedMethods;
        }

        public List<String> getAllowedHeaders() {
            return allowedHeaders;
        }

        public void setAllowedHeaders(List<String> allowedHeaders) {
            this.allowedHeaders = allowedHeaders == null ? new ArrayList<>() : allowedHeaders;
        }

        public List<String> getExposedHeaders() {
            return exposedHeaders;
        }

        public void setExposedHeaders(List<String> exposedHeaders) {
            this.exposedHeaders = exposedHeaders == null ? new ArrayList<>() : exposedHeaders;
        }

        public boolean isAllowCredentials() {
            return allowCredentials;
        }

        public void setAllowCredentials(boolean allowCredentials) {
            this.allowCredentials = allowCredentials;
        }

        public Duration getMaxAge() {
            return maxAge;
        }

        public void setMaxAge(Duration maxAge) {
            this.maxAge = maxAge;
        }
    }

    /**
     * Consistency preconditions & ETag emission.
     */
    public static class Consistency {
        private boolean enabled = true;

        /**
         * Request header holding a conditional token (read-your-writes).
         */
        @NotBlank
        private String requestHeader = "If-Consistent-With";

        /**
         * Whether to emit strong ETags (vs weak).
         */
        private boolean etagStrong = false;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getRequestHeader() {
            return requestHeader;
        }

        public void setRequestHeader(String requestHeader) {
            this.requestHeader = requestHeader;
        }

        public boolean isEtagStrong() {
            return etagStrong;
        }

        public void setEtagStrong(boolean etagStrong) {
            this.etagStrong = etagStrong;
        }
    }

    /**
     * Step-Up (stronger auth) policy for high-risk operations.
     * Bound at: veggieshop.http.stepup.*
     */
    public static class StepUp {

        /**
         * Master toggle for the StepUpInterceptor.
         */
        private boolean enabled = false;

        /**
         * Default maximum age for MFA/AMR evidence to be considered fresh.
         * Example: "PT5M" (5 minutes) in properties/yaml.
         */
        @NotNull
        private Duration defaultMaxAge = Duration.ofMinutes(5);

        /**
         * Whether HMAC principals may ever satisfy step-up checks.
         * Usually false; HMAC requests typically lack AMR/auth_time signals.
         */
        private boolean allowHmacPrincipals = false;

        /**
         * Accepted AMR hint values that indicate MFA was performed.
         * Case-insensitive check.
         */
        @NotNull
        private List<String> mfaAmrHints = new ArrayList<>(List.of(
                "mfa", "otp", "webauthn", "u2f", "totp"
        ));

        // --- getters/setters ---

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public Duration getDefaultMaxAge() {
            return defaultMaxAge;
        }

        public void setDefaultMaxAge(Duration defaultMaxAge) {
            this.defaultMaxAge = defaultMaxAge;
        }

        public boolean isAllowHmacPrincipals() {
            return allowHmacPrincipals;
        }

        public void setAllowHmacPrincipals(boolean allowHmacPrincipals) {
            this.allowHmacPrincipals = allowHmacPrincipals;
        }

        public List<String> getMfaAmrHints() {
            return mfaAmrHints;
        }

        public void setMfaAmrHints(List<String> mfaAmrHints) {
            this.mfaAmrHints = (mfaAmrHints == null ? new ArrayList<>() : new ArrayList<>(mfaAmrHints));
        }
    }
}

package io.veggieshop.platform.starter.web.autoconfig;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jose.util.DefaultResourceRetriever;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import io.veggieshop.platform.application.consistency.ConsistencyService;
import io.veggieshop.platform.application.security.StepUpService;
import io.veggieshop.platform.domain.tenant.TenantResolver;
import io.veggieshop.platform.starter.web.config.VeggieShopHttpProperties;
import io.veggieshop.platform.http.consistency.ConsistencyPreconditionInterceptor;
import io.veggieshop.platform.http.consistency.ETagResponseAdvice;
import io.veggieshop.platform.http.error.ProblemHttpMapper;
import io.veggieshop.platform.http.filters.CorrelationIdFilter;
import io.veggieshop.platform.http.filters.HmacAuthFilter;
import io.veggieshop.platform.http.filters.OidcJwtAuthFilter;
import io.veggieshop.platform.http.filters.PiiLogGuardFilter;
import io.veggieshop.platform.http.filters.RateLimitFilter;
import io.veggieshop.platform.http.filters.TenantFilter;
import io.veggieshop.platform.starter.web.security.StepUpInterceptor;
import io.veggieshop.platform.http.security.StepUpSettings;
import io.veggieshop.platform.starter.web.error.ProblemExceptionAdvice;
import io.veggieshop.problem.core.ProblemFactory;
import jakarta.servlet.DispatcherType;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;
import org.springframework.web.filter.ForwardedHeaderFilter;
import org.springframework.web.servlet.DispatcherServlet;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.net.URL;
import java.time.Clock;
import java.util.EnumSet;

import static jakarta.servlet.DispatcherType.ASYNC;
import static jakarta.servlet.DispatcherType.ERROR;
import static jakarta.servlet.DispatcherType.REQUEST;

/**
 * Assembles VeggieShop HTTP components (filters/interceptors/advice) from platform-api-http.
 * Master switch: veggieshop.http.enabled=true (default).
 */
@AutoConfiguration
@EnableConfigurationProperties(VeggieShopHttpProperties.class)
@ConditionalOnClass(DispatcherServlet.class)
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnProperty(prefix = "veggieshop.http", name = "enabled", matchIfMissing = true)
public class VeggieShopWebAutoConfiguration {

    private static final int DEFAULT_MAX_BODY_BYTES = 1_000_000; // 1 MB
    private static final EnumSet<DispatcherType> DEFAULT_DISPATCHERS =
            EnumSet.of(REQUEST, ERROR, ASYNC);

    // ------------------------------------------------------------------------------------------------
    // Core
    // ------------------------------------------------------------------------------------------------

    @Bean
    @ConditionalOnMissingBean
    ForwardedHeaderFilter forwardedHeaderFilter() {
        // Ensures X-Forwarded-* and Forwarded headers are honored behind proxies/load balancers.
        return new ForwardedHeaderFilter();
    }

    // ------------------------------------------------------------------------------------------------
    // Correlation
    // ------------------------------------------------------------------------------------------------

    @Bean(name = "correlationIdFilterRegistration")
    @ConditionalOnProperty(prefix = "veggieshop.http.correlation", name = "enabled", matchIfMissing = true)
    FilterRegistrationBean<CorrelationIdFilter> correlationIdFilter(VeggieShopHttpProperties p) {
        var cfg = p.getCorrelation();
        var filter = new CorrelationIdFilter(
                cfg.getHeader(),
                cfg.isGenerateIfMissing(),
                cfg.getGenerator().name(),
                cfg.getMdcKey()
        );
        var reg = new FilterRegistrationBean<>(filter);
        reg.setDispatcherTypes(DEFAULT_DISPATCHERS);
        reg.setOrder(CorrelationIdFilter.ORDER);
        reg.addUrlPatterns("/*");
        reg.setAsyncSupported(true);
        return reg;
    }

    // ------------------------------------------------------------------------------------------------
    // Tenant guard
    // ------------------------------------------------------------------------------------------------

    @Bean(name = "tenantFilterRegistration")
    @ConditionalOnProperty(prefix = "veggieshop.http.tenant", name = "enabled", matchIfMissing = true)
    FilterRegistrationBean<TenantFilter> tenantFilter(TenantResolver tenantResolver, VeggieShopHttpProperties p) {
        var t = p.getTenant();
        var filter = new TenantFilter(
                tenantResolver,
                t.getHeader(),
                t.isRequired(),
                t.getPublicPaths(),
                t.getMdcKey()
        );
        var reg = new FilterRegistrationBean<>(filter);
        reg.setDispatcherTypes(DEFAULT_DISPATCHERS);
        reg.setOrder(TenantFilter.ORDER);
        reg.addUrlPatterns("/*");
        reg.setAsyncSupported(true);
        return reg;
    }

    // ------------------------------------------------------------------------------------------------
    // PII log guard
    // ------------------------------------------------------------------------------------------------

    @Bean(name = "piiLogGuardFilterRegistration")
    @ConditionalOnProperty(prefix = "veggieshop.http.pii-log", name = "enabled", matchIfMissing = true)
    FilterRegistrationBean<PiiLogGuardFilter> piiLogGuardFilter(VeggieShopHttpProperties p) {
        var pl = p.getPiiLog();
        var filter = new PiiLogGuardFilter(
                pl.getPayloadMaxChars(),
                pl.getHeaderDenylist(),
                pl.getRedactPatterns()
        );
        var reg = new FilterRegistrationBean<>(filter);
        reg.setDispatcherTypes(DEFAULT_DISPATCHERS);
        reg.setOrder(PiiLogGuardFilter.ORDER);
        reg.addUrlPatterns("/*");
        reg.setAsyncSupported(true);
        return reg;
    }

    // ------------------------------------------------------------------------------------------------
    // Rate limiting
    // ------------------------------------------------------------------------------------------------

    @Bean(name = "rateLimitFilterRegistration")
    @ConditionalOnProperty(prefix = "veggieshop.http.rate-limit", name = "enabled", matchIfMissing = true)
    FilterRegistrationBean<RateLimitFilter> rateLimitFilter(VeggieShopHttpProperties p) {
        var rl = p.getRateLimit();
        var filter = new RateLimitFilter(
                rl.isHeaders(),
                rl.getKeys(),
                rl.getDefault(),
                rl.getOverrides()
        );
        var reg = new FilterRegistrationBean<>(filter);
        reg.setDispatcherTypes(DEFAULT_DISPATCHERS);
        reg.setOrder(RateLimitFilter.ORDER);
        reg.addUrlPatterns("/*");
        reg.setAsyncSupported(true);
        return reg;
    }

    // ------------------------------------------------------------------------------------------------
    // HMAC partner auth
    // ------------------------------------------------------------------------------------------------

    @Bean(name = "hmacAuthFilterRegistration")
    @ConditionalOnProperty(prefix = "veggieshop.http.hmac", name = "enabled")
    FilterRegistrationBean<HmacAuthFilter> hmacAuthFilter(
            VeggieShopHttpProperties p,
            HmacAuthFilter.HmacKeyResolver keyResolver,
            ObjectProvider<HmacAuthFilter.NonceStore> nonceStore,
            ObjectProvider<Clock> clock
    ) {
        var hp = p.getHmac();
        var filter = new HmacAuthFilter(
                keyResolver,
                nonceStore.getIfAvailable(() -> HmacAuthFilter.inMemoryNonceStore(500_000, hp.getTtl())),
                clock.getIfAvailable(Clock::systemUTC),
                hp.getKeyIdHeader(),
                hp.getTimestampHeader(),
                hp.getNonceHeader(),                     // <-- use property, not a hardcoded value
                hp.getSignatureHeader(),
                /* max body bytes */ DEFAULT_MAX_BODY_BYTES,
                hp.getClockSkew(),
                hp.isEnforceBodySha256(),
                hp.getAcceptedAlgorithms().stream().findFirst().orElse("HmacSHA256")
        );
        var reg = new FilterRegistrationBean<>(filter);
        reg.setDispatcherTypes(DEFAULT_DISPATCHERS);
        // Runs after tenant filter (needs tenant) and before OIDC
        reg.setOrder(TenantFilter.ORDER + 15);
        reg.addUrlPatterns("/*");
        reg.setAsyncSupported(true);
        return reg;
    }

    // ------------------------------------------------------------------------------------------------
    // OIDC (Nimbus) – processor + filter
    // ------------------------------------------------------------------------------------------------

    /** Nimbus JWT processor wired from properties (issuer/jwks/algs/timeouts). */
    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.http.oidc", name = "enabled", havingValue = "true")
    ConfigurableJWTProcessor<SecurityContext> oidcJwtProcessor(VeggieShopHttpProperties props) throws Exception {
        var sp = props.getOidc();

        String jwksUri = (sp.getJwksUri() != null && !sp.getJwksUri().isBlank())
                ? sp.getJwksUri()
                : deriveJwksFromIssuer(sp.getIssuer());

        var retriever = new DefaultResourceRetriever(
                (int) sp.getJwksConnectTimeout().toMillis(),
                (int) sp.getJwksReadTimeout().toMillis(),
                sp.getJwksSizeLimitBytes()
        );

        JWKSource<SecurityContext> jwkSource = new RemoteJWKSet<>(new URL(jwksUri), retriever);
        String expectedAlg = sp.getAllowedAlgs().isEmpty() ? "RS256" : sp.getAllowedAlgs().get(0);
        JWSKeySelector<SecurityContext> keySelector =
                new JWSVerificationKeySelector<>(JWSAlgorithm.parse(expectedAlg), jwkSource);

        var proc = new DefaultJWTProcessor<SecurityContext>();
        proc.setJWSKeySelector(keySelector);
        return proc;
    }

    private static String deriveJwksFromIssuer(String issuer) {
        String base = issuer.endsWith("/") ? issuer.substring(0, issuer.length() - 1) : issuer;
        return base + "/.well-known/jwks.json";
    }

    /** Registers the OIDC filter using the prepared Nimbus processor. */
    @Bean(name = "oidcJwtAuthFilterRegistration")
    @ConditionalOnProperty(prefix = "veggieshop.http.oidc", name = "enabled", havingValue = "true")
    @ConditionalOnClass(OidcJwtAuthFilter.class)
    @ConditionalOnMissingBean(OidcJwtAuthFilter.class)
    FilterRegistrationBean<OidcJwtAuthFilter> oidcFilter(
            VeggieShopHttpProperties props,
            ConfigurableJWTProcessor<SecurityContext> proc
    ) {
        var sp = props.getOidc();

        var filter = OidcJwtAuthFilter.of(
                sp.getIssuer(),
                sp.getJwksUri(),
                sp.getAllowedAlgs(),
                sp.getClockSkew(),
                sp.getAudience(),
                sp.getPublicPaths(),          // <-- pass public paths from properties
                proc
        );

        var reg = new FilterRegistrationBean<>(filter);
        reg.setDispatcherTypes(DEFAULT_DISPATCHERS);
        // After rate limit (to avoid expensive JWT work on throttled requests)
        reg.setOrder(RateLimitFilter.ORDER + 10);
        reg.addUrlPatterns("/*");
        reg.setAsyncSupported(true);
        return reg;
    }

    // ------------------------------------------------------------------------------------------------
    // Consistency (preconditions + ETag)
    // ------------------------------------------------------------------------------------------------

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.http.consistency", name = "enabled", matchIfMissing = true)
    ETagResponseAdvice eTagResponseAdvice(ConsistencyService consistency) {
        return new ETagResponseAdvice(consistency);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.http.consistency", name = "enabled", matchIfMissing = true)
    ConsistencyPreconditionInterceptor consistencyPreconditionInterceptor(ConsistencyService consistency) {
        return new ConsistencyPreconditionInterceptor(consistency);
    }

    // ------------------------------------------------------------------------------------------------
    // MVC glue (interceptors + CORS)
    // ------------------------------------------------------------------------------------------------

    @Bean
    WebMvcConfigurer veggieshopWebConfigurer(
            ObjectProvider<ConsistencyPreconditionInterceptor> cpiProvider,
            VeggieShopHttpProperties p
    ) {
        return new WebMvcConfigurer() {
            @Override
            public void addInterceptors(InterceptorRegistry reg) {
                var cpi = cpiProvider.getIfAvailable();
                if (cpi != null) {
                    reg.addInterceptor(cpi).order(Ordered.HIGHEST_PRECEDENCE + 10);
                }
            }

            @Override
            public void addCorsMappings(CorsRegistry reg) {
                if (p.getCors().isEnabled()) {
                    reg.addMapping("/**")
                            .allowedOrigins(p.getCors().getAllowedOrigins().toArray(String[]::new))
                            .allowedMethods(p.getCors().getAllowedMethods().toArray(String[]::new))
                            .allowedHeaders(p.getCors().getAllowedHeaders().toArray(String[]::new))
                            .exposedHeaders(p.getCors().getExposedHeaders().toArray(String[]::new))
                            .allowCredentials(p.getCors().isAllowCredentials())
                            .maxAge(p.getCors().getMaxAge().toSeconds());
                }
            }
        };
    }

    // ------------------------------------------------------------------------------------------------
    // Problem+JSON glue (problem-core ↔ Spring ProblemDetail)
    // ------------------------------------------------------------------------------------------------

    @Bean
    @ConditionalOnMissingBean
    ProblemFactory problemFactory() {
        return new ProblemFactory();
    }

    @Bean
    @ConditionalOnMissingBean
    ProblemHttpMapper problemHttpMapper() {
        return new ProblemHttpMapper();
    }

    @Bean
    @ConditionalOnMissingBean
    ProblemExceptionAdvice problemExceptionAdvice(
            ProblemFactory factory,
            ProblemHttpMapper mapper
    ) {
        return new ProblemExceptionAdvice(factory, mapper);
    }

    // ------------------------------------------------------------------------------------------------
    // Step-Up (MFA elevation) – settings + interceptor + registration
    // ------------------------------------------------------------------------------------------------

    @Bean
    @ConditionalOnProperty(prefix = "veggieshop.http.step-up", name = "enabled", havingValue = "true")
    StepUpSettings stepUpSettings(VeggieShopHttpProperties p) {
        // NOTE: field name is 'stepUp' → kebab-case prefix is 'step-up'
        var sp = p.getStepUp();
        return new StepUpSettings.Builder()
                .defaultMaxAge(sp.getDefaultMaxAge())
                .mfaAmrHints(new java.util.LinkedHashSet<>(sp.getMfaAmrHints()))
                .allowHmacPrincipals(sp.isAllowHmacPrincipals())
                .build();
    }

    @Bean
    @ConditionalOnProperty(prefix = "veggieshop.http.step-up", name = "enabled", havingValue = "true")
    StepUpInterceptor stepUpInterceptor(
            StepUpService service,
            StepUpSettings settings,
            ObjectProvider<Clock> clock
    ) {
        return new StepUpInterceptor(service, settings, clock.getIfAvailable(Clock::systemUTC));
    }

    @Bean
    WebMvcConfigurer stepUpConfigurer(ObjectProvider<StepUpInterceptor> stepUp) {
        return new WebMvcConfigurer() {
            @Override
            public void addInterceptors(InterceptorRegistry reg) {
                var i = stepUp.getIfAvailable();
                if (i != null) reg.addInterceptor(i).order(StepUpInterceptor.ORDER);
            }
        };
    }
}

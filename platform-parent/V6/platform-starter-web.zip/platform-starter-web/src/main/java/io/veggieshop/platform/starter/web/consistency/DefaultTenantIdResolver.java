package io.veggieshop.platform.starter.web.consistency;

import io.veggieshop.platform.domain.tenant.TenantResolver;
import jakarta.servlet.http.HttpServletRequest;

import java.util.*;

final class DefaultTenantIdResolver implements TenantIdResolver {
    private final boolean enforceConsistency;
    private final JwtClaimsExtractor claimsExtractor;

    DefaultTenantIdResolver(boolean enforceConsistency, JwtClaimsExtractor claimsExtractor) {
        this.enforceConsistency = enforceConsistency;
        this.claimsExtractor = claimsExtractor;
    }

    @Override
    public String resolve(HttpServletRequest request) {
        Map<String, String> headers = toCaseInsensitiveMap(request);
        Map<String, Object> claims = claimsExtractor.extract(request);
        try {
            var res = TenantResolver.resolve(
                    null,                                 // لا explicit
                    headers,                              // HTTP headers
                    claims,                               // JWT claims (إن وجدت)
                    null,                                 // message headers (ليس سياق رسائل هنا)
                    enforceConsistency                    // سياسة الاتساق
            );
            return res.tenantId().value();
        } catch (NoSuchElementException | IllegalStateException ex) {
            // لا مستأجر موثوق → أعد null واترك طبقة الأمن/الكونترولر تقرر
            return null;
        }
    }

    private static Map<String,String> toCaseInsensitiveMap(HttpServletRequest req){
        Map<String,String> m = new HashMap<>();
        for (Enumeration<String> e = req.getHeaderNames(); e.hasMoreElements(); ) {
            String name = e.nextElement();
            m.put(name, req.getHeader(name));
        }
        return m;
    }
}

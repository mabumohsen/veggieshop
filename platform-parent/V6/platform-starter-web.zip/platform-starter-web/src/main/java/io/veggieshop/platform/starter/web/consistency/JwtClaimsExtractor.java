package io.veggieshop.platform.starter.web.consistency;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.Map;

@FunctionalInterface
public interface JwtClaimsExtractor {
    Map<String, Object> extract(HttpServletRequest request);

    /** افتراضي: بلا اعتماد على Spring Security */
    static JwtClaimsExtractor noop() { return req -> Collections.emptyMap(); }
}

package io.veggieshop.platform.starter.web.consistency;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "veggieshop.web.tenancy")
public class WebTenancyProperties {
    /** إن كان true سنفشل عند تعارض المصادر (هيدر/توكن/JWT) */
    private boolean enforceConsistency = true;
    public boolean isEnforceConsistency() { return enforceConsistency; }
    public void setEnforceConsistency(boolean enforceConsistency) { this.enforceConsistency = enforceConsistency; }
}

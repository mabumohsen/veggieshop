package io.veggieshop.platform.starter.web.consistency;

import io.veggieshop.platform.application.consistency.ConsistencyService;
import io.veggieshop.platform.application.consistency.ConsistencyStamped;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

@ControllerAdvice
class ConsistencyHeadersAdvice implements ResponseBodyAdvice<Object> {
    private final ConsistencyService service;
    private final VeggieConsistencyProperties p;
    ConsistencyHeadersAdvice(ConsistencyService s, VeggieConsistencyProperties p){ this.service=s; this.p=p; }

    @Override public boolean supports(MethodParameter returnType, Class converterType) { return true; }

    @Override public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType,
                                            Class selectedConverterType, ServerHttpRequest req, ServerHttpResponse res) {
        if (body instanceof ConsistencyStamped cs) {
            var headers = service.responseHeaders(cs.tenantId(), cs.aggregateType(), cs.aggregateId(), cs.version());
            headers.forEach((k,v) -> res.getHeaders().set(k, v));
        }
        return body;
    }
}

package io.veggieshop.platform.domain.tenant;

import org.slf4j.MDC;

import java.io.Serial;
import java.io.Serializable;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.function.Supplier;

/**
 * TenantContext
 *
 * <p>Enterprise-grade, virtual-thread-safe tenant context holder for VeggieShop.</p>
 *
 * <h2>Design goals (aligned with PRD v2.0)</h2>
 * <ul>
 *   <li><b>Multi-tenancy everywhere:</b> all request handling and background work must execute under a resolved tenant.</li>
 *   <li><b>Virtual Threads first:</b> safe on Java 21 Virtual Threads. Uses a minimal {@link ThreadLocal}—which is
 *       isolated per Virtual Thread—plus deterministic scope restoration to prevent leaks on platform-thread reuse.</li>
 *   <li><b>No preview APIs:</b> avoids {@code ScopedValue} so builds do not require {@code --enable-preview}.</li>
 *   <li><b>Observability:</b> the active tenant is mirrored into SLF4J MDC using key {@value #MDC_TENANT_ID} for JSON logs.</li>
 *   <li><b>Ergonomics:</b> explicit scoping ({@link #within(TenantId, Runnable)} / {@link #within(TenantId, Supplier)}),
 *       try-with-resources ({@link #open(TenantId)}), and cross-thread propagation helpers ({@link #wrap(Runnable)},
 *       {@link #wrap(Callable)}).</li>
 * </ul>
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * // Typical HTTP request flow (TenantFilter sets it):
 * try (var ignored = TenantContext.open(tenantId)) {
 *     // do work under tenant
 *     var id = TenantContext.requireTenantId(); // safe access
 * }
 *
 * // Concise scoping:
 * TenantContext.within(tenantId, () -> doSomething());
 *
 * // Crossing executors / spawning tasks:
 * executor.submit(TenantContext.wrap(() -> service.doSomething()));
 * }</pre>
 *
 * <p><b>IMPORTANT:</b> Never cache {@link TenantId} globally or store it in singletons. Always resolve from headers/events
 * and scope the task using this context. For background workers, resolve tenant from the message envelope and use
 * {@link #within(TenantId, Runnable)}.</p>
 */
public final class TenantContext {

    /**
     * Canonical inbound header used by HTTP filters to resolve the tenant.
     * Kept here to avoid duplications across modules.
     */
    public static final String REQUEST_HEADER = "X-Tenant-Id";

    /**
     * MDC key used in JSON logs; must be kept in sync with log configuration and PII guards.
     */
    public static final String MDC_TENANT_ID = "tenantId";

    /**
     * The sole state holder. ThreadLocals are isolated per Virtual Thread and cheap to set/clear.
     * We restore the previous value on scope close to avoid context bleed on platform-thread reuse.
     */
    private static final ThreadLocal<TenantId> TL_TENANT = new ThreadLocal<>();

    private TenantContext() {
        /* utility holder */
    }

    // ---------------------------------------------------------------------
    // Public API – Scoping
    // ---------------------------------------------------------------------

    /**
     * Open a tenant scope on the current thread and MDC.
     * The returned {@link Scope} <b>must</b> be closed (use try-with-resources) to avoid leaks.
     */
    public static Scope open(TenantId tenantId) {
        Objects.requireNonNull(tenantId, "tenantId");
        final TenantId previous = TL_TENANT.get();
        final String previousMdc = MDC.get(MDC_TENANT_ID);

        TL_TENANT.set(tenantId);
        MDC.put(MDC_TENANT_ID, tenantId.value());

        return new Scope(previous, previousMdc);
    }

    /**
     * Execute {@code runnable} within a tenant scope.
     */
    public static void within(TenantId tenantId, Runnable runnable) {
        Objects.requireNonNull(tenantId, "tenantId");
        Objects.requireNonNull(runnable, "runnable");
        try (var ignored = open(tenantId)) {
            runnable.run();
        }
    }

    /**
     * Execute {@code supplier} within a tenant scope and return its value.
     */
    public static <T> T within(TenantId tenantId, Supplier<T> supplier) {
        Objects.requireNonNull(tenantId, "tenantId");
        Objects.requireNonNull(supplier, "supplier");
        try (var ignored = open(tenantId)) {
            return supplier.get();
        }
    }

    // ---------------------------------------------------------------------
    // Public API – Accessors
    // ---------------------------------------------------------------------

    /**
     * @return current tenant id if set; empty otherwise.
     */
    public static Optional<TenantId> currentTenantId() {
        return Optional.ofNullable(TL_TENANT.get());
    }

    /**
     * @return current tenant id or throws {@link IllegalStateException} if none present.
     */
    public static TenantId requireTenantId() {
        TenantId id = TL_TENANT.get();
        if (id == null) {
            throw new IllegalStateException("TenantId is required but not present in TenantContext");
        }
        return id;
    }

    /**
     * @return whether a tenant is currently bound to the context.
     */
    public static boolean isPresent() {
        return TL_TENANT.get() != null;
    }

    /**
     * Clear ThreadLocal and MDC state for defensive cleanup.
     * (Scopes created via {@link #open(TenantId)} restore automatically on close.)
     */
    public static void clear() {
        TL_TENANT.remove();
        MDC.remove(MDC_TENANT_ID);
    }

    // ---------------------------------------------------------------------
    // Public API – Cross-thread propagation helpers
    // ---------------------------------------------------------------------

    /**
     * Capture the current tenant context and return a {@link Runnable} that re-establishes it
     * for the duration of the task. Use this when submitting to executors or scheduling work.
     */
    public static Runnable wrap(Runnable delegate) {
        Objects.requireNonNull(delegate, "delegate");
        final TenantId captured = TL_TENANT.get(); // may be null
        if (captured == null) {
            return delegate; // nothing to propagate
        }
        return () -> {
            try (var ignored = open(captured)) {
                delegate.run();
            }
        };
    }

    /**
     * Capture the current tenant context and return a {@link Callable} that re-establishes it
     * for the duration of the task. Use this when submitting to executors or scheduling work.
     */
    public static <V> Callable<V> wrap(Callable<V> delegate) {
        Objects.requireNonNull(delegate, "delegate");
        final TenantId captured = TL_TENANT.get(); // may be null
        if (captured == null) {
            return delegate;
        }
        return () -> {
            try (var ignored = open(captured)) {
                return delegate.call();
            }
        };
    }

    // ---------------------------------------------------------------------
    // Scope (AutoCloseable)
    // ---------------------------------------------------------------------

    /**
     * Restores previous TL/MDC state on {@link #close()}. Keep this type minimal and Serializable-safe
     * so it can be used across test utilities if needed.
     */
    public static final class Scope implements AutoCloseable, Serializable {
        @Serial private static final long serialVersionUID = 1L;

        private final TenantId previousTenant;
        private final String previousMdc;

        private Scope(TenantId previousTenant, String previousMdc) {
            this.previousTenant = previousTenant;
            this.previousMdc = previousMdc;
        }

        @Override
        public void close() {
            // Restore prior TL to prevent context bleed across reused platform threads.
            if (previousTenant == null) {
                TL_TENANT.remove();
            } else {
                TL_TENANT.set(previousTenant);
            }
            // Restore MDC
            if (previousMdc == null) {
                MDC.remove(MDC_TENANT_ID);
            } else {
                MDC.put(MDC_TENANT_ID, previousMdc);
            }
        }
    }
}

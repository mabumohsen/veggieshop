package io.veggieshop.platform.domain.consistency;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.Serial;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Objects;

/**
 * ConsistencyToken
 *
 * <p>Enterprise-grade, tamper-evident token that enables read-your-writes and monotonic reads
 * across caches and services, as described in the VeggieShop PRD v2.0. The server issues
 * the token on responses and validates it on subsequent requests.</p>
 *
 * <h2>Headers (PRD §10)</h2>
 * <ul>
 *   <li>Response: {@code ETag: "v&lt;version&gt;"} and {@code X-Consistency-Token: &lt;token&gt;}</li>
 *   <li>Request: {@code If-Consistent-With: v&lt;version&gt;}</li>
 * </ul>
 *
 * <h2>Design</h2>
 * <ul>
 *   <li><b>Integrity:</b> token payload is HMAC-SHA-256 signed using a server-side secret.</li>
 *   <li><b>Privacy:</b> no PII in the payload; includes only versioning metadata, timestamps, nonce.</li>
 *   <li><b>Scoping:</b> optional Associated Data (AAD) is bound into the MAC (e.g., tenant-id, resource key)
 *       to prevent cross-tenant/resource replay. AAD is <i>not</i> encoded into the token.</li>
 *   <li><b>Portability:</b> pure JDK 21, no external deps; compact binary payload with URL-safe Base64.</li>
 *   <li><b>Clock skew:</b> callers may pass a tolerance when validating to account for small skew.</li>
 * </ul>
 *
 *  * <h2>Token formats</h2>
 *  * <ul>
 *  *   <li><b>New (with KID, recommended):</b> {@code base64url(header) + "." + base64url(payload) + "." + base64url(mac)}</li>
 *  *   <li><b>Legacy (without KID):</b> {@code base64url(payload) + "." + base64url(mac)}</li>
 *  * </ul>
 *  * <p>Both header and payload are covered by MAC. AAD (e.g., tenant-id) is also bound.</p>
 *
 * <h3>Typical flow</h3>
 * <pre>{@code
 * // On response (server):
 * ConsistencyToken tok = ConsistencyToken.issue(entityVersion, Duration.ofSeconds(60));
 * String tokenHeader = tok.encode(hmacKeyBytes, tenantId.getBytes(UTF_8)); // AAD binds tenant
 * response.setHeader("ETag", ConsistencyToken.formatETag(entityVersion));
 * response.setHeader(ConsistencyToken.RESPONSE_HEADER, tokenHeader);
 *
 * // On request (server):
 * long clientVersion = ConsistencyToken.parseIfConsistentWith(request.getHeader(
 *     ConsistencyToken.REQUEST_HEADER)).orElseThrow(...);
 * ConsistencyToken verified = ConsistencyToken.decodeAndVerify(
 *     request.getHeader(ConsistencyToken.RESPONSE_HEADER), hmacKeyBytes,
 *     tenantId.getBytes(UTF_8), Duration.ofSeconds(5)); // 5s skew tolerance
 * // Compare versions, allow monotonic reads, or fall back to OLTP as per policy.
 * }</pre>
 */
public final class ConsistencyToken implements Serializable {

    @Serial private static final long serialVersionUID = 1L;

    /** Payload schema version (bump if payload layout changes). */
    public static final int SCHEMA_VERSION = 1;

    /** Packaging (token header) version. Independent from payload schema version. */
    public static final int TOKEN_VERSION = 1;

    /** Response/Request header names. */
    public static final String RESPONSE_HEADER = "X-Consistency-Token";
    public static final String REQUEST_HEADER  = "If-Consistent-With";

    /** ETag prefix used to format entity versions: {@code "v42"}. */
    private static final String ETAG_PREFIX = "v";

    /** MAC algorithm. */
    private static final String HMAC_ALG = "HmacSHA256";

    /** URL-safe Base64 (no padding). */
    private static final Base64.Encoder B64_URL_ENC = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder B64_URL_DEC = Base64.getUrlDecoder();

    /** Random source for nonces. */
    private static final SecureRandom RNG = new SecureRandom();

    // ------------------------ Immutable payload fields ------------------------

    private final long entityVersion;          // non-negative
    private final long issuedAtEpochSeconds;   // iat (seconds)
    private final long expiresAtEpochSeconds;  // exp (seconds)
    private final long nonce;                  // random 64-bit

    private ConsistencyToken(long entityVersion, long issuedAtEpochSeconds, long expiresAtEpochSeconds, long nonce) {
        if (entityVersion < 0) throw new IllegalArgumentException("entityVersion must be >= 0");
        if (expiresAtEpochSeconds <= issuedAtEpochSeconds) {
            throw new IllegalArgumentException("expiresAt must be after issuedAt");
        }
        this.entityVersion = entityVersion;
        this.issuedAtEpochSeconds = issuedAtEpochSeconds;
        this.expiresAtEpochSeconds = expiresAtEpochSeconds;
        this.nonce = nonce;
    }

    // -------------------------------------------------------------------------------------
    // Issue / Encode
    // -------------------------------------------------------------------------------------

    /** Issue a new token for the given version and TTL (uses current clock). */
    public static ConsistencyToken issue(long entityVersion, Duration ttl) {
        return issue(entityVersion, Instant.now(), ttl);
    }

    /** Issue a new token for the given version, explicit clock and TTL. */
    public static ConsistencyToken issue(long entityVersion, Instant now, Duration ttl) {
        Objects.requireNonNull(now, "now");
        Objects.requireNonNull(ttl, "ttl");
        if (ttl.isNegative() || ttl.isZero()) throw new IllegalArgumentException("ttl must be > 0");
        long iat = now.getEpochSecond();
        long exp = now.plus(ttl).getEpochSecond();
        long nonce = RNG.nextLong();
        return new ConsistencyToken(entityVersion, iat, exp, nonce);
    }

    /**
     * Encode (legacy, no KID). Prefer {@link #encode(KeyProvider, String, byte[])} for rotation support.
     * Format: base64url(payload) + "." + base64url(mac).
     */
    public String encode(byte[] hmacKey, byte[] associatedData) {
        Objects.requireNonNull(hmacKey, "hmacKey");
        byte[] payload = serializePayload(this);
        byte[] mac = hmac(hmacKey, /*header=*/null, payload, associatedData);
        return B64_URL_ENC.encodeToString(payload) + "." + B64_URL_ENC.encodeToString(mac);
    }

    /**
     * Encode (recommended, with KID). Format: base64url(header) + "." + base64url(payload) + "." + base64url(mac).
     * Header is bound to the signature. AAD (if provided) is also bound.
     * <p>KeyProvider exceptions are wrapped into IllegalStateException (misconfiguration at issuance).</p>
     */
    public String encode(KeyProvider keyProvider, String kid, byte[] associatedData) {
        Objects.requireNonNull(keyProvider, "keyProvider");
        String safeKid = normalizeKid(kid);
        byte[] header = serializeHeader(safeKid);
        byte[] payload = serializePayload(this);
        byte[] key = requireKeyForIssue(keyProvider, safeKid); // wrap checked -> runtime
        byte[] mac = hmac(key, header, payload, associatedData);
        return B64_URL_ENC.encodeToString(header)
                + "." + B64_URL_ENC.encodeToString(payload)
                + "." + B64_URL_ENC.encodeToString(mac);
    }

    // -------------------------------------------------------------------------------------
    // Decode / Verify
    // -------------------------------------------------------------------------------------

    /** Decode & verify legacy token (no KID) against Instant.now(). */
    public static ConsistencyToken decodeAndVerify(String token, byte[] hmacKey, byte[] associatedData,
                                                   Duration skewTolerance) {
        return decodeAndVerify(token, hmacKey, associatedData, Instant.now(), skewTolerance);
    }

    /** Decode & verify legacy token (no KID) with an explicit clock. */
    public static ConsistencyToken decodeAndVerify(String token, byte[] hmacKey, byte[] associatedData,
                                                   Instant now, Duration skewTolerance) {
        Objects.requireNonNull(token, "token");
        Objects.requireNonNull(hmacKey, "hmacKey");
        Objects.requireNonNull(now, "now");
        Objects.requireNonNull(skewTolerance, "skewTolerance");

        String[] parts = token.split("\\.", 3);
        if (parts.length == 2) {
            byte[] payload = decodeB64Url(parts[0], "payload");
            byte[] macProvided = decodeB64Url(parts[1], "mac");
            byte[] macExpected = hmac(hmacKey, /*header=*/null, payload, associatedData);
            if (!MessageDigest.isEqual(macProvided, macExpected)) {
                throw new SecurityException("Invalid consistency token signature");
            }
            ConsistencyToken parsed = deserializePayload(payload);
            checkExpiry(now, skewTolerance, parsed);
            return parsed;
        } else if (parts.length == 3) {
            // New-form token but a single static key was supplied: still verify (no rotation).
            byte[] header = decodeB64Url(parts[0], "header");
            /* Header presence is covered by HMAC; we don't need its KID here. */
            byte[] payload = decodeB64Url(parts[1], "payload");
            byte[] macProvided = decodeB64Url(parts[2], "mac");
            byte[] macExpected = hmac(hmacKey, header, payload, associatedData);
            if (!MessageDigest.isEqual(macProvided, macExpected)) {
                throw new SecurityException("Invalid consistency token signature");
            }
            ConsistencyToken parsed = deserializePayload(payload);
            checkExpiry(now, skewTolerance, parsed);
            return parsed;
        }
        throw new IllegalArgumentException("Malformed consistency token");
    }

    /**
     * Decode & verify using a KeyProvider (supports rotation via KID).
     * <p>KeyProvider exceptions are wrapped into SecurityException (verification failure).</p>
     */
    public static ConsistencyToken decodeAndVerify(String token, KeyProvider keyProvider, byte[] associatedData,
                                                   Duration skewTolerance) {
        return decodeAndVerify(token, keyProvider, associatedData, Instant.now(), skewTolerance);
    }

    /** Same as above, with explicit clock. */
    public static ConsistencyToken decodeAndVerify(String token, KeyProvider keyProvider, byte[] associatedData,
                                                   Instant now, Duration skewTolerance) {
        Objects.requireNonNull(token, "token");
        Objects.requireNonNull(keyProvider, "keyProvider");
        Objects.requireNonNull(now, "now");
        Objects.requireNonNull(skewTolerance, "skewTolerance");

        String[] parts = token.split("\\.", 3);
        if (parts.length == 2) {
            // Legacy form: payload.mac
            byte[] payload = decodeB64Url(parts[0], "payload");
            byte[] macProvided = decodeB64Url(parts[1], "mac");
            byte[] key = requireKeyForVerify(keyProvider, KeyProvider.LEGACY_KID);
            byte[] macExpected = hmac(key, /*header=*/null, payload, associatedData);
            if (!MessageDigest.isEqual(macProvided, macExpected)) {
                throw new SecurityException("Invalid consistency token signature");
            }
            ConsistencyToken parsed = deserializePayload(payload);
            checkExpiry(now, skewTolerance, parsed);
            return parsed;
        } else if (parts.length == 3) {
            // New form: header.payload.mac
            byte[] header = decodeB64Url(parts[0], "header");
            Header h = deserializeHeader(header);
            byte[] payload = decodeB64Url(parts[1], "payload");
            byte[] macProvided = decodeB64Url(parts[2], "mac");

            byte[] key = requireKeyForVerify(keyProvider, h.kid());
            byte[] macExpected = hmac(key, header, payload, associatedData);
            if (!MessageDigest.isEqual(macProvided, macExpected)) {
                throw new SecurityException("Invalid consistency token signature");
            }
            ConsistencyToken parsed = deserializePayload(payload);
            checkExpiry(now, skewTolerance, parsed);
            return parsed;
        }
        throw new IllegalArgumentException("Malformed consistency token");
    }

    private static void checkExpiry(Instant now, Duration skewTolerance, ConsistencyToken parsed) {
        long nowSec = now.getEpochSecond();
        long allowed = parsed.expiresAtEpochSeconds + Math.max(0, skewTolerance.toSeconds());
        if (nowSec > allowed) throw new SecurityException("Consistency token expired");
    }

    // -------------------------------------------------------------------------------------
    // Header helpers (ETag / If-Consistent-With)
    // -------------------------------------------------------------------------------------

    public static String formatETag(long version) {
        if (version < 0) throw new IllegalArgumentException("version must be >= 0");
        return "\"" + ETAG_PREFIX + version + "\"";
    }

    public static String formatIfConsistentWith(long version) {
        if (version < 0) throw new IllegalArgumentException("version must be >= 0");
        return ETAG_PREFIX + version;
    }

    public static long parseIfConsistentWith(String headerValue) {
        if (headerValue == null) return -1;
        String t = headerValue.trim();
        if (t.isEmpty()) return -1;
        if (t.startsWith(ETAG_PREFIX)) t = t.substring(ETAG_PREFIX.length());
        try {
            long v = Long.parseLong(t);
            return v >= 0 ? v : -1;
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    // -------------------------------------------------------------------------------------
    // Accessors
    // -------------------------------------------------------------------------------------

    public long entityVersion() { return entityVersion; }
    public Instant issuedAt()   { return Instant.ofEpochSecond(issuedAtEpochSeconds); }
    public Instant expiresAt()  { return Instant.ofEpochSecond(expiresAtEpochSeconds); }
    public long nonce()         { return nonce; }

    public boolean isExpired(Instant now) {
        Objects.requireNonNull(now, "now");
        return now.getEpochSecond() > expiresAtEpochSeconds;
    }

    // -------------------------------------------------------------------------------------
    // Object contract
    // -------------------------------------------------------------------------------------

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ConsistencyToken that)) return false;
        return entityVersion == that.entityVersion
                && issuedAtEpochSeconds == that.issuedAtEpochSeconds
                && expiresAtEpochSeconds == that.expiresAtEpochSeconds
                && nonce == that.nonce;
    }

    @Override public int hashCode() {
        return Objects.hash(entityVersion, issuedAtEpochSeconds, expiresAtEpochSeconds, nonce);
    }

    @Override public String toString() {
        // Human-friendly; does NOT expose MAC/secret.
        return "ConsistencyToken{v=" + entityVersion
                + ", iat=" + issuedAtEpochSeconds
                + ", exp=" + expiresAtEpochSeconds
                + ", n=" + Long.toUnsignedString(nonce) + "}";
    }

    // -------------------------------------------------------------------------------------
    // Serialization (binary, compact)
    // Payload Layout: [u8 schemaVersion][s64 entityVersion][s64 issuedAt][s64 expiresAt][s64 nonce]
    // Header  Layout: [u8 tokenVersion][u8 kidLen][kidBytes...]
    // -------------------------------------------------------------------------------------

    private static byte[] serializePayload(ConsistencyToken t) {
        ByteBuffer buf = ByteBuffer.allocate(1 + 8 + 8 + 8 + 8);
        buf.put((byte) SCHEMA_VERSION);
        buf.putLong(t.entityVersion);
        buf.putLong(t.issuedAtEpochSeconds);
        buf.putLong(t.expiresAtEpochSeconds);
        buf.putLong(t.nonce);
        return buf.array();
    }

    private static ConsistencyToken deserializePayload(byte[] payload) {
        if (payload.length != (1 + 8 + 8 + 8 + 8)) {
            throw new IllegalArgumentException("Unexpected payload size");
        }
        ByteBuffer buf = ByteBuffer.wrap(payload);
        int ver = Byte.toUnsignedInt(buf.get());
        if (ver != SCHEMA_VERSION) {
            throw new IllegalArgumentException("Unsupported token schema version: " + ver);
        }
        long entityVersion = buf.getLong();
        long iat = buf.getLong();
        long exp = buf.getLong();
        long nonce = buf.getLong();
        return new ConsistencyToken(entityVersion, iat, exp, nonce);
    }

    private static byte[] serializeHeader(String kid) {
        byte[] kidBytes = kid.getBytes(StandardCharsets.UTF_8);
        if (kidBytes.length == 0 || kidBytes.length > 255) {
            throw new IllegalArgumentException("kid length must be in [1,255]");
        }
        ByteBuffer buf = ByteBuffer.allocate(1 + 1 + kidBytes.length);
        buf.put((byte) TOKEN_VERSION);
        buf.put((byte) kidBytes.length);
        buf.put(kidBytes);
        return buf.array();
    }

    private static Header deserializeHeader(byte[] header) {
        if (header.length < 2) throw new IllegalArgumentException("Unexpected header size");
        ByteBuffer buf = ByteBuffer.wrap(header);
        int ver = Byte.toUnsignedInt(buf.get());
        if (ver != TOKEN_VERSION) {
            throw new IllegalArgumentException("Unsupported token version: " + ver);
        }
        int kidLen = Byte.toUnsignedInt(buf.get());
        if (kidLen == 0 || (2 + kidLen) != header.length) {
            throw new IllegalArgumentException("Invalid kid length in header");
        }
        byte[] kidBytes = new byte[kidLen];
        buf.get(kidBytes);
        return new Header(new String(kidBytes, StandardCharsets.UTF_8));
    }

    private record Header(String kid) {}

    // -------------------------------------------------------------------------------------
    // Crypto helpers
    // -------------------------------------------------------------------------------------

    /**
     * Compute HMAC over domain separator + header? + payload + aad.
     * Layout: "CT" 0x00 [header?] 0x00 payload 0x00 [aad?]
     */
    private static byte[] hmac(byte[] key, byte[] header, byte[] payload, byte[] aad) {
        try {
            Mac mac = Mac.getInstance(HMAC_ALG);
            mac.init(new SecretKeySpec(key, HMAC_ALG));
            mac.update("CT".getBytes(StandardCharsets.UTF_8)); // domain separator
            mac.update((byte) 0x00);
            if (header != null && header.length > 0) mac.update(header);
            mac.update((byte) 0x00);
            mac.update(payload);
            mac.update((byte) 0x00);
            if (aad != null && aad.length > 0) mac.update(aad);
            return mac.doFinal();
        } catch (GeneralSecurityException e) {
            // With a standard JCE provider this should not happen.
            throw new IllegalStateException("HMAC computation failed", e);
        }
    }

    private static byte[] decodeB64Url(String part, String label) {
        try {
            return B64_URL_DEC.decode(part);
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Malformed Base64 for " + label, ex);
        }
    }

    private static String normalizeKid(String kid) {
        if (kid == null) throw new IllegalArgumentException("kid must not be null");
        String k = kid.trim();
        if (k.isEmpty()) throw new IllegalArgumentException("kid must not be blank");
        // Minimal normalization: printable ASCII only.
        for (int i = 0; i < k.length(); i++) {
            char c = k.charAt(i);
            if (!(c >= 0x21 && c <= 0x7E)) throw new IllegalArgumentException("kid must be printable ASCII");
        }
        return k;
    }

    // -------------------------------------------------------------------------------------
    // Key Provider (Rotation support)
    // -------------------------------------------------------------------------------------

    @FunctionalInterface
    public interface KeyProvider {
        /** Special KID used to verify legacy two-part tokens when only a single key exists. */
        String LEGACY_KID = "legacy";
        /** Returns raw HMAC key bytes for the given KID. May throw for unknown/unavailable keys. */
        byte[] hmacKeyFor(String kid) throws GeneralSecurityException;
    }

    /** Wraps provider errors during issuance into IllegalStateException (misconfiguration). */
    private static byte[] requireKeyForIssue(KeyProvider kp, String kid) {
        try {
            return kp.hmacKeyFor(kid);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Failed to obtain HMAC key for kid: " + kid, e);
        }
    }

    /** Wraps provider errors during verification into SecurityException (verification failure). */
    private static byte[] requireKeyForVerify(KeyProvider kp, String kid) {
        try {
            return kp.hmacKeyFor(kid);
        } catch (GeneralSecurityException e) {
            throw new SecurityException("Unknown or unavailable HMAC key for kid: " + kid, e);
        }
    }
}
package io.veggieshop.platform.application.consistency;

import jakarta.validation.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.Optional;

public class ConsistencyService {
    private static final Logger log = LoggerFactory.getLogger(ConsistencyService.class);
    private static final String TOKEN_VERSION = "vct1";
    private static final Base64.Encoder B64URL_ENC = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder B64URL_DEC = Base64.getUrlDecoder();

    private final Clock clock;
    private final ConsistencyProperties props;
    private final TokenSigner signer;

    private static final ThreadLocal<ConsistencyContext> CTX = new ThreadLocal<>();

    public ConsistencyService(Clock clock, ConsistencyProperties props, TokenSigner signer) {
        this.clock = clock;
        this.props = props;
        this.signer = signer;
    }

    // ----- Lifecycle -----
    public ConsistencyContext openRequest(@NotBlank String tenantId,
                                          String ifConsistentWith,
                                          String priorConsistencyTok) {
        Long expected = parseExpectedVersion(ifConsistentWith).orElse(null);
        ParsedToken tok = parseAndValidateToken(priorConsistencyTok).orElse(null);
        ConsistencyContext ctx = new ConsistencyContext(tenantId, expected, tok);
        CTX.set(ctx);
        return ctx;
    }
    public void clear(){ CTX.remove(); }
    public Optional<ConsistencyContext> context(){ return Optional.ofNullable(CTX.get()); }

    // ----- Response helpers -----
    public String etagFor(long version){ return "\"v" + version + "\""; }

    public String newToken(@NotBlank String tenantId, @NotBlank String aggregateType,
                           @NotBlank String aggregateId, long entityVersion) {
        long iat = clock.instant().getEpochSecond();
        long exp = clock.instant().plus(props.window()).getEpochSecond();
        String kid = props.kid();
        String payloadJson = "{\"t\":\"" + json(tenantId) + "\"," +
                "\"a\":\"" + json(aggregateType) + "\"," +
                "\"i\":\"" + json(aggregateId) + "\"," +
                "\"v\":" + entityVersion + "," +
                "\"iat\":" + iat + "," +
                "\"exp\":" + exp + "}";
        String payloadB64 = B64URL_ENC.encodeToString(payloadJson.getBytes(StandardCharsets.UTF_8));
        String sigB64 = B64URL_ENC.encodeToString(signer.hmac(kid, payloadB64.getBytes(StandardCharsets.US_ASCII)));
        return TOKEN_VERSION + ":" + kid + ":" + payloadB64 + ":" + sigB64;
    }

    public Map<String,String> responseHeaders(@NotBlank String tenantId, @NotBlank String aggregateType,
                                              @NotBlank String aggregateId, long entityVersion) {
        return Map.of(
                props.headerEtag(), etagFor(entityVersion),
                props.headerConsistencyToken(), newToken(tenantId, aggregateType, aggregateId, entityVersion),
                "X-Entity-Version", "v" + entityVersion
        );
    }

    // ----- Decisions -----
    public boolean shouldFallbackToOltp(long currentProjectionVersion, Instant projectionRefreshedAt) {
        ConsistencyContext ctx = CTX.get();
        if (ctx == null) return false;

        long expected = ctx.expectedVersionOrElse(-1L);
        if (expected < 0 && ctx.token() != null) expected = ctx.token().version();
        if (expected < 0) return false;

        if (ctx.token() != null && ctx.token().isExpired(clock.instant())) return false;

        boolean versionBehind = currentProjectionVersion < expected;
        boolean timeBehind = ctx.token() != null && projectionRefreshedAt != null
                && projectionRefreshedAt.isBefore(ctx.token().issuedAt());

        return versionBehind || timeBehind;
    }

    public boolean isConsistentWithClient(long authoritativeVersion) {
        ConsistencyContext ctx = CTX.get();
        if (ctx == null) return true;
        Long expected = ctx.expectedVersion();
        return expected == null || expected <= authoritativeVersion;
    }

    // ----- Parsing & validation -----
    private Optional<Long> parseExpectedVersion(String header) {
        if (header == null || header.isBlank()) return Optional.empty();
        String h = header.trim();
        switch (props.ifHeaderPolicy()) {
            case NUMBER_ONLY -> {
                try { long v = Long.parseLong(h); return v >= 0 ? Optional.of(v) : Optional.empty(); }
                catch (NumberFormatException ex) { return Optional.empty(); }
            }
            case ETAG_ONLY -> {
                if (h.startsWith("\"") && h.endsWith("\"")) h = h.substring(1, h.length()-1);
                if (h.startsWith("v")) h = h.substring(1);
                try { long v = Long.parseLong(h); return v >= 0 ? Optional.of(v) : Optional.empty(); }
                catch (NumberFormatException ex) { return Optional.empty(); }
            }
            default -> { // ETAG_OR_NUMBER
                if (h.startsWith("\"") && h.endsWith("\"")) h = h.substring(1, h.length()-1);
                if (h.startsWith("v") || h.startsWith("V")) h = h.substring(1);
                try { long v = Long.parseLong(h); return v >= 0 ? Optional.of(v) : Optional.empty(); }
                catch (NumberFormatException ex) { return Optional.empty(); }
            }
        }
    }

    private Optional<ParsedToken> parseAndValidateToken(String token) {
        if (token == null || token.isBlank()) return Optional.empty();
        try {
            String[] p = token.split(":", 4);
            if (p.length != 4 || !TOKEN_VERSION.equals(p[0])) return Optional.empty();
            String kid = p[1], payloadB64 = p[2], sigB64 = p[3];
            byte[] expected = signer.hmac(kid, payloadB64.getBytes(StandardCharsets.US_ASCII));
            byte[] provided = B64URL_DEC.decode(sigB64);
            if (!cte(expected, provided)) return Optional.empty();
            String json = new String(B64URL_DEC.decode(payloadB64), StandardCharsets.UTF_8);
            ParsedToken parsed = ParsedToken.fromJson(json, kid);
            return Optional.of(parsed);
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    private static boolean cte(byte[] a, byte[] b){
        if (a == null || b == null || a.length != b.length) return false;
        int r=0; for(int i=0;i<a.length;i++) r |= (a[i]^b[i]); return r==0;
    }
    private static String json(String s){ return s.replace("\\","\\\\").replace("\"","\\\""); }

    // ----- Types -----
    public static final class ConsistencyContext {
        private final String tenantId;
        private final Long expectedVersion;
        private final ParsedToken token;
        ConsistencyContext(String tenantId, Long expectedVersion, ParsedToken token) {
            this.tenantId = tenantId; this.expectedVersion = expectedVersion; this.token = token;
        }
        public String tenantId(){ return tenantId; }
        public Long expectedVersion(){ return expectedVersion; }
        public ParsedToken token(){ return token; }
        long expectedVersionOrElse(long fb){ return expectedVersion!=null?expectedVersion:fb; }
    }

    static final class ParsedToken {
        private final String kid, tenantId, aggregateType, aggregateId;
        private final long entityVersion;
        private final Instant iat, exp;
        ParsedToken(String kid, String tenantId, String aggregateType, String aggregateId,
                    long entityVersion, Instant iat, Instant exp){
            this.kid=kid; this.tenantId=tenantId; this.aggregateType=aggregateType; this.aggregateId=aggregateId;
            this.entityVersion=entityVersion; this.iat=iat; this.exp=exp;
        }
        static ParsedToken fromJson(String json, String kid){
            String t = get(json,"t"); String a=get(json,"a"); String i=get(json,"i");
            long v = Long.parseLong(get(json,"v"));
            long issued = Long.parseLong(get(json,"iat"));
            long expires = Long.parseLong(get(json,"exp"));
            return new ParsedToken(kid, t, a, i, v, Instant.ofEpochSecond(issued), Instant.ofEpochSecond(expires));
        }
        private static String get(String json, String key){
            String p="\""+key+"\":";
            int idx=json.indexOf(p); if (idx<0) throw new IllegalArgumentException("Missing "+key);
            int s=idx+p.length(); char c=json.charAt(s);
            if (c=='\"'){ int e=json.indexOf('\"', s+1); return json.substring(s+1,e).replace("\\\"","\"").replace("\\\\","\\"); }
            int e=s; while(e<json.length() && "-0123456789".indexOf(json.charAt(e))>=0) e++;
            return json.substring(s,e);
        }
        long version(){ return entityVersion; }
        Instant issuedAt(){ return iat; }
        boolean isExpired(Instant now){ return now.isAfter(exp); }
    }
}

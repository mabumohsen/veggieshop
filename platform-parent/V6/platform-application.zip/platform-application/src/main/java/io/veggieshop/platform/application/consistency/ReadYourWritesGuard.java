package io.veggieshop.platform.application.consistency;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;

import java.time.Clock;
import java.time.Instant;
import java.util.Optional;
import java.util.function.Supplier;

public class ReadYourWritesGuard {
    private final ConsistencyService consistency;
    private final MeterRegistry metrics;
    private final Clock clock;

    public ReadYourWritesGuard(ConsistencyService consistency, MeterRegistry metrics, Clock clock) {
        this.consistency = consistency; this.metrics = metrics; this.clock = clock;
    }

    public <T> Versioned<T> read(String aggregateType, String aggregateId,
                                 Supplier<Versioned<T>> projection,
                                 Supplier<Versioned<T>> oltp,
                                 Policy policy) {
        Versioned<T> proj;
        try {
            proj = timed("consistency.guard.projection.timer", "aggregate", aggregateType, projection);
            metrics.counter("consistency.guard.projection.hit","aggregate",aggregateType).increment();
        } catch (RuntimeException ex) {
            metrics.counter("consistency.guard.projection.errors","aggregate",aggregateType).increment();
            if (policy == Policy.FAIL_OPEN_STALE) return Versioned.empty();
            metrics.counter("consistency.guard.fallback","aggregate",aggregateType,"reason","projection_error").increment();
            return timed("consistency.guard.oltp.timer","aggregate",aggregateType, oltp);
        }

        long v = proj.version();
        Instant refreshed = proj.refreshedAt().orElse(null);
        consistency.context().ifPresent(ctx -> {
            var tok = ctx.token();
            if (tok != null && tok.isExpired(clock.instant())) {
                metrics.counter("consistency.guard.window.expired","aggregate",aggregateType).increment();
            }
        });

        if (consistency.shouldFallbackToOltp(v, refreshed)) {
            metrics.counter("consistency.guard.fallback","aggregate",aggregateType,"reason","expectation").increment();
            return timed("consistency.guard.oltp.timer","aggregate",aggregateType, oltp);
        }
        return proj;
    }

    public <T> Versioned<T> read(String agg, String id, Supplier<Versioned<T>> proj, Supplier<Versioned<T>> oltp) {
        return read(agg, id, proj, oltp, Policy.FAIL_CLOSED_OLTP);
    }

    private <R> R timed(String timer, String tagK, String tagV, Supplier<R> body){
        Timer.Sample s = Timer.start(metrics);
        R r = body.get();
        s.stop(Timer.builder(timer).tag(tagK, tagV).register(metrics));
        return r;
    }

    public enum Policy { FAIL_CLOSED_OLTP, FAIL_OPEN_STALE }

    public static final class Versioned<T> {
        private final T value; private final long version; private final Instant refreshedAt;
        private Versioned(T v, long ver, Instant ra){ this.value=v; this.version=ver; this.refreshedAt=ra; }
        public static <T> Versioned<T> of(T v, long ver, Instant ra){ return new Versioned<>(v,ver,ra); }
        public static <T> Versioned<T> of(T v, long ver){ return new Versioned<>(v,ver,null); }
        public static <T> Versioned<T> empty(){ return new Versioned<>(null,-1,null); }
        public Optional<T> value(){ return Optional.ofNullable(value); }
        public T orNull(){ return value; }
        public long version(){ return version; }
        public Optional<Instant> refreshedAt(){ return Optional.ofNullable(refreshedAt); }
        public String toString(){ return "Versioned{version="+version+", refreshedAt="+refreshedAt+"}"; }
    }

    public <T> Optional<T> monotonic(Supplier<Optional<T>> read) {
        try {
            return read.get();
        } catch (RuntimeException ex) {
            throw ex;
        }
    }
}

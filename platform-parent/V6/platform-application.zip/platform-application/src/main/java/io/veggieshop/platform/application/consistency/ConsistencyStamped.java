package io.veggieshop.platform.application.consistency;

public interface ConsistencyStamped {
    String tenantId();
    String aggregateType();
    String aggregateId();
    long version();
}

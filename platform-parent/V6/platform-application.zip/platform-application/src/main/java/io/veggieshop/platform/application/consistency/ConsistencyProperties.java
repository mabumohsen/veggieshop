package io.veggieshop.platform.application.consistency;

import java.time.Duration;
import java.util.Objects;

public final class ConsistencyProperties {
    public enum IfHeaderPolicy { ETAG_OR_NUMBER, NUMBER_ONLY, ETAG_ONLY }

    private Duration window = Duration.ofSeconds(60);
    private String kid = "consistency-default";
    /** أسماء الهيدرز */
    private String headerIfConsistentWith = "If-Consistent-With";
    private String headerConsistencyToken = "X-Consistency-Token";
    private String headerEtag = "ETag";
    /** سياسة قراءة If-Consistent-With */
    private IfHeaderPolicy ifHeaderPolicy = IfHeaderPolicy.ETAG_OR_NUMBER;

    public Duration window() { return window; }
    public ConsistencyProperties window(Duration v){ this.window = Objects.requireNonNull(v); return this; }

    public String kid() { return kid; }
    public ConsistencyProperties kid(String v){ this.kid = Objects.requireNonNull(v); return this; }

    public String headerIfConsistentWith(){ return headerIfConsistentWith; }
    public ConsistencyProperties headerIfConsistentWith(String v){ this.headerIfConsistentWith = Objects.requireNonNull(v); return this; }

    public String headerConsistencyToken(){ return headerConsistencyToken; }
    public ConsistencyProperties headerConsistencyToken(String v){ this.headerConsistencyToken = Objects.requireNonNull(v); return this; }

    public String headerEtag(){ return headerEtag; }
    public ConsistencyProperties headerEtag(String v){ this.headerEtag = Objects.requireNonNull(v); return this; }

    public IfHeaderPolicy ifHeaderPolicy(){ return ifHeaderPolicy; }
    public ConsistencyProperties ifHeaderPolicy(IfHeaderPolicy v){ this.ifHeaderPolicy = Objects.requireNonNull(v); return this; }
}

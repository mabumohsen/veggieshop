package io.veggieshop.platform.application.pii;

import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.veggieshop.platform.application.consistency.ReadYourWritesGuard;
import io.veggieshop.platform.application.security.AbacPolicyEngine;
import io.veggieshop.platform.domain.security.RiskLevel;
import io.veggieshop.platform.domain.tenant.TenantId;
import jakarta.annotation.Nullable;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.time.Duration;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;

/**
 * Strongly-typed PII Vault client orchestrating ABAC, RYW, retries and observability.
 * <p>
 * IMPORTANT: Never log PII maps or field values here.
 */
@Service
public class PiiVaultClient {

    private static final Logger log = LoggerFactory.getLogger(PiiVaultClient.class);

    // Guardrails (use days for broad JDK compatibility)
    private static final Duration MIN_RETENTION = Duration.ofDays(1);
    private static final Duration MAX_RETENTION = Duration.ofDays(365L * 7);

    private final PiiVaultPort port;
    private final AbacPolicyEngine abac;
    private final ReadYourWritesGuard readYourWrites;
    private final Tracer tracer;
    private final Clock clock;

    public PiiVaultClient(
            PiiVaultPort port,
            AbacPolicyEngine abac,
            ReadYourWritesGuard readYourWrites,
            Tracer tracer,
            Clock clock
    ) {
        this.port = Objects.requireNonNull(port, "port");
        this.abac = Objects.requireNonNull(abac, "abac");
        this.readYourWrites = Objects.requireNonNull(readYourWrites, "readYourWrites");
        this.tracer = Objects.requireNonNull(tracer, "tracer");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    /**
     * Create or update PII for a subject.
     */
    @Transactional
    public PiiHandle upsert(
            @NotNull TenantId tenantId,
            @NotBlank String subjectType,
            @NotBlank String subjectId,
            @NotNull Map<String, String> pii,
            @Nullable Duration retention,
            @Nullable Map<String, String> tags,
            @Nullable String idempotencyKey,
            @NotNull RiskLevel risk
    ) {
        authorize(tenantId, PiiAction.WRITE, risk);
        final var clampedRetention = clampRetention(retention);
        final Span span = tracer.spanBuilder("pii.upsert").startSpan();
        span.setAttribute("tenant.id", tenantId.value());
        span.setAttribute("pii.subject.type", subjectType);
        span.setAttribute("pii.tags.count", tags == null ? 0 : tags.size());
        span.setAttribute("pii.fields.count", pii.size());
        try {
            return withRetry("pii.upsert", () ->
                    port.upsert(tenantId, subjectType, subjectId, pii, clampedRetention, tags, idempotencyKey)
            );
        } catch (RuntimeException e) {
            span.recordException(e).setStatus(StatusCode.ERROR);
            throw e;
        } finally {
            span.end();
        }
    }

    /**
     * Resolve (decrypt and return) PII by handle. The result is never logged or traced.
     * Uses ReadYourWritesGuard.monotonic(...) to ensure monotonicity when applicable.
     */
    @Transactional(readOnly = true)
    public Optional<Map<String, String>> resolve(
            @NotNull TenantId tenantId,
            @NotNull String ref,
            @NotNull RiskLevel risk
    ) {
        authorize(tenantId, PiiAction.READ, risk);
        final Span span = tracer.spanBuilder("pii.resolve").startSpan();
        span.setAttribute("tenant.id", tenantId.value());
        span.setAttribute("pii.ref.len", ref.length());
        try {
            return readYourWrites.monotonic(() -> port.read(tenantId, ref));
        } catch (RuntimeException e) {
            span.recordException(e).setStatus(StatusCode.ERROR);
            throw e;
        } finally {
            // Do NOT attach any PII to the span.
            span.end();
        }
    }

    /**
     * Redact selected fields from a PII record.
     */
    @Transactional
    public PiiHandle redact(
            @NotNull TenantId tenantId,
            @NotNull String ref,
            @NotNull Set<String> fieldsToRemove,
            @NotNull RiskLevel risk
    ) {
        authorize(tenantId, PiiAction.REDACT, risk);
        if (fieldsToRemove.isEmpty()) {
            return currentHandle(tenantId, ref);
        }
        final Span span = tracer.spanBuilder("pii.redact").startSpan();
        span.setAttribute("tenant.id", tenantId.value());
        span.setAttribute("pii.ref.len", ref.length());
        span.setAttribute("pii.redact.count", fieldsToRemove.size());
        try {
            return withRetry("pii.redact", () -> port.redactFields(tenantId, ref, fieldsToRemove));
        } catch (RuntimeException e) {
            span.recordException(e).setStatus(StatusCode.ERROR);
            throw e;
        } finally {
            span.end();
        }
    }

    /**
     * Rotate encryption keys for the referenced PII payload.
     */
    @Transactional
    public PiiHandle rotate(
            @NotNull TenantId tenantId,
            @NotNull String ref,
            @NotNull RiskLevel risk
    ) {
        authorize(tenantId, PiiAction.ROTATE, risk);
        final Span span = tracer.spanBuilder("pii.rotate").startSpan();
        span.setAttribute("tenant.id", tenantId.value());
        span.setAttribute("pii.ref.len", ref.length());
        try {
            return withRetry("pii.rotate", () -> port.rotate(tenantId, ref));
        } catch (RuntimeException e) {
            span.recordException(e).setStatus(StatusCode.ERROR);
            throw e;
        } finally {
            span.end();
        }
    }

    /**
     * Delete a PII record (soft/hard).
     */
    @Transactional
    public boolean delete(
            @NotNull TenantId tenantId,
            @NotNull String ref,
            boolean hardDelete,
            @NotNull RiskLevel risk
    ) {
        authorize(tenantId, hardDelete ? PiiAction.HARD_DELETE : PiiAction.DELETE, risk);
        final Span span = tracer.spanBuilder("pii.delete").startSpan();
        span.setAttribute("tenant.id", tenantId.value());
        span.setAttribute("pii.ref.len", ref.length());
        span.setAttribute("pii.delete.hard", hardDelete);
        try {
            return withRetry("pii.delete", () -> port.delete(tenantId, ref, hardDelete));
        } catch (RuntimeException e) {
            span.recordException(e).setStatus(StatusCode.ERROR);
            throw e;
        } finally {
            span.end();
        }
    }

    /**
     * Fetch current handle (ref + version) without exposing payload.
     */
    @Transactional(readOnly = true)
    public PiiHandle currentHandle(@NotNull TenantId tenantId, @NotNull String ref) {
        return port.currentHandle(tenantId, ref);
    }

    // ---------- Helpers ----------

    private void authorize(TenantId tenantId, PiiAction action, RiskLevel risk) {
        abac.require(tenantId, "PII_VAULT", action.name(), risk);
    }

    private Duration clampRetention(@Nullable Duration requested) {
        if (requested == null) return null; // use storage default
        if (requested.compareTo(MIN_RETENTION) < 0) return MIN_RETENTION;
        if (requested.compareTo(MAX_RETENTION) > 0) return MAX_RETENTION;
        return requested;
    }

    private <T> T withRetry(String opName, Supplier<T> supplier) {
        final int maxAttempts = 3;
        int attempt = 0;
        while (true) {
            attempt++;
            try {
                return supplier.get();
            } catch (DataAccessException e) {
                if (attempt >= maxAttempts) {
                    log.warn("PII op '{}' failed after {} attempts (transient). Escalating.", opName, attempt);
                    throw e;
                }
                // Exponential backoff with jitter; cap at 250ms.
                long base = (long) Math.pow(2, attempt - 1) * 25L;
                long jitter = ThreadLocalRandom.current().nextLong(10, 30);
                long sleepMs = Math.min(base + jitter, 250L);
                try {
                    Thread.sleep(sleepMs);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    // ---------- Types & Port (Application-level contract) ----------

    /**
     * Opaque handle to a PII record (reference and optimistic version).
     */
    public record PiiHandle(@NotNull String ref, long version) {
        public PiiHandle {
            if (ref == null || ref.isBlank()) throw new IllegalArgumentException("ref must not be blank");
            if (version < 0) throw new IllegalArgumentException("version must be >= 0");
        }
    }

    /**
     * Application port implemented in infrastructure (e.g., JDBC adapter with FLE + RLS).
     * MUST NOT leak PII to logs/traces/metrics.
     */
    public interface PiiVaultPort {
        PiiHandle upsert(
                @NotNull TenantId tenantId,
                @NotBlank String subjectType,
                @NotBlank String subjectId,
                @NotNull Map<String, String> pii,
                @Nullable Duration retention,
                @Nullable Map<String, String> tags,
                @Nullable String idempotencyKey
        );

        @Transactional(readOnly = true)
        Optional<Map<String, String>> read(@NotNull TenantId tenantId, @NotBlank String ref);

        PiiHandle redactFields(@NotNull TenantId tenantId, @NotBlank String ref, @NotNull Set<String> fieldsToRemove);

        PiiHandle rotate(@NotNull TenantId tenantId, @NotBlank String ref);

        boolean delete(@NotNull TenantId tenantId, @NotBlank String ref, boolean hardDelete);

        @Transactional(readOnly = true)
        PiiHandle currentHandle(@NotNull TenantId tenantId, @NotBlank String ref);
    }

    /**
     * Actions recognized by policies. Keep names stable for policy-as-code.
     */
    public enum PiiAction {READ, WRITE, REDACT, ROTATE, DELETE, HARD_DELETE}
}

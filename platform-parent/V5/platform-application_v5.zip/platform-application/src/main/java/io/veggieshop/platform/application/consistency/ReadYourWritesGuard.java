package io.veggieshop.platform.application.consistency;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * ReadYourWritesGuard centralizes the decision logic for dual-read guardrails:
 * prefer fast projections, but fallback to OLTP when a caller presents a stronger
 * read-your-writes expectation (If-Consistent-With / X-Consistency-Token) and we are
 * within the configured fallback window.
 *
 * <p>Use on projection/search-backed reads. Do NOT use on commit paths.</p>
 */
@Service
public class ReadYourWritesGuard {

    private static final Logger log = LoggerFactory.getLogger(ReadYourWritesGuard.class);

    private final ConsistencyService consistency;
    private final MeterRegistry metrics;
    private final Clock clock;

    public ReadYourWritesGuard(ConsistencyService consistency, MeterRegistry metrics, Clock clock) {
        this.consistency = Objects.requireNonNull(consistency, "consistency");
        this.metrics = Objects.requireNonNull(metrics, "metrics");
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    /**
     * Execute a guarded read with dual-read semantics.
     *
     * @param aggregateType human-readable type (e.g., "order", "cart", "product")
     * @param aggregateId   aggregate identity (for logs only)
     * @param projection    supplier returning a {@link Versioned} projection result
     * @param oltp          supplier returning a {@link Versioned} OLTP result
     * @param policy        fallback behavior on projection failure
     * @return the chosen (possibly OLTP) {@link Versioned} result
     */
    public <T> Versioned<T> read(
            @NotBlank String aggregateType,
            @NotBlank String aggregateId,
            @NotNull Supplier<Versioned<T>> projection,
            @NotNull Supplier<Versioned<T>> oltp,
            @NotNull Policy policy
    ) {
        final String agg = aggregateType;
        final String aggId = aggregateId;

        try (var mdc = mdc(
                "consistency.agg", agg,
                "consistency.aggId.tail", tail(aggId),
                "consistency.policy", policy.name()
        )) {
            // 1) Try projection
            Versioned<T> proj;
            try {
                proj = timed("consistency.guard.projection.timer", "aggregate", agg, projection);
                metrics.counter("consistency.guard.projection.hit", "aggregate", agg).increment();
            } catch (RuntimeException ex) {
                metrics.counter("consistency.guard.projection.errors", "aggregate", agg).increment();
                log.warn("Projection read failed (aggregate={} id=****{}). Policy={}, err={}",
                        agg, tail(aggId), policy, ex.toString());

                if (policy == Policy.FAIL_OPEN_STALE) {
                    return Versioned.empty();
                }
                // Fail-closed: go straight to OLTP
                metrics.counter("consistency.guard.fallback", "aggregate", agg, "reason", "projection_error").increment();
                return timed("consistency.guard.oltp.timer", "aggregate", agg, oltp);
            }

            // 2) Apply expectation policy (read-your-writes)
            long projVersion = proj.version();
            Instant projRefreshedAt = proj.refreshedAt().orElse(null);

            // If client had a token but the window expired, record awareness
            consistency.context().ifPresent(ctx -> {
                var tok = ctx.token();
                if (tok != null && tok.isExpired(clock.instant())) {
                    metrics.counter("consistency.guard.window.expired", "aggregate", agg).increment();
                }
            });

            boolean shouldFallback = consistency.shouldFallbackToOltp(projVersion, projRefreshedAt);
            if (shouldFallback) {
                metrics.counter("consistency.guard.fallback", "aggregate", agg, "reason", "expectation").increment();
                if (log.isDebugEnabled()) {
                    log.debug("Falling back to OLTP to honor read-your-writes (agg={} id=****{}, projV={}, refreshedAt={})",
                            agg, tail(aggId), projVersion, projRefreshedAt);
                }
                return timed("consistency.guard.oltp.timer", "aggregate", agg, oltp);
            }

            // 3) Projection is acceptable
            return proj;
        }
    }

    /** Convenience overload using {@link Policy#FAIL_CLOSED_OLTP}. */
    public <T> Versioned<T> read(
            @NotBlank String aggregateType,
            @NotBlank String aggregateId,
            @NotNull Supplier<Versioned<T>> projection,
            @NotNull Supplier<Versioned<T>> oltp
    ) {
        return read(aggregateType, aggregateId, projection, oltp, Policy.FAIL_CLOSED_OLTP);
    }

    /** Simple RYW helper: execute the read supplier as-is. */
    public <T> T monotonic(Supplier<T> read) {
        return read.get();
    }

    // ------------------------------------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------------------------------------

    private static String tail(String id) {
        if (id == null) return "null";
        return id.length() <= 4 ? id : id.substring(id.length() - 4);
    }

    // Quiet AutoCloseable (no checked exceptions)
    private interface QuietAutoCloseable extends AutoCloseable {
        @Override
        void close(); // no checked exception
    }

    private static QuietAutoCloseable mdc(String k1, String v1, String k2, String v2, String k3, String v3) {
        MDC.put(k1, v1);
        MDC.put(k2, v2);
        MDC.put(k3, v3);
        return () -> {
            MDC.remove(k1);
            MDC.remove(k2);
            MDC.remove(k3);
        };
    }

    private <R> R timed(String timerName, String tagKey, String tagValue, Supplier<R> body) {
        Timer.Sample sample = Timer.start(metrics); // Micrometer 1.10+: start with registry
        R res = body.get();
        sample.stop(Timer.builder(timerName).tag(tagKey, tagValue).register(metrics));
        return res;
    }

    // ------------------------------------------------------------------------------------------------
    // Types
    // ------------------------------------------------------------------------------------------------

    /** Fallback policy on projection issues. */
    public enum Policy {
        FAIL_CLOSED_OLTP,
        FAIL_OPEN_STALE
    }

    /**
     * Value + monotonic version + optional last-refreshed time.
     * version >= 0 => known; -1 => unknown (e.g., miss).
     */
    public static final class Versioned<T> {
        private final T value;
        private final long version;
        private final Instant refreshedAt; // nullable

        private Versioned(T value, long version, Instant refreshedAt) {
            this.value = value;
            this.version = version;
            this.refreshedAt = refreshedAt;
        }

        /** Create a versioned value with known version and optional refresh timestamp. */
        public static <T> Versioned<T> of(T value, long version, Instant refreshedAt) {
            return new Versioned<>(value, version, refreshedAt);
        }

        /** Create a versioned value with known version and no refresh timestamp. */
        public static <T> Versioned<T> of(T value, long version) {
            return new Versioned<>(value, version, null);
        }

        /** Create an empty/unknown version result (e.g., projection miss). */
        public static <T> Versioned<T> empty() {
            return new Versioned<>(null, -1, null);
        }

        public Optional<T> value() {
            return Optional.ofNullable(value);
        }

        public T orNull() {
            return value;
        }

        /** Monotonic entity version (or -1 if unknown). */
        public long version() {
            return version;
        }

        /** The instant when the projection was refreshed for this aggregate (may be null). */
        public Optional<Instant> refreshedAt() {
            return Optional.ofNullable(refreshedAt);
        }

        @Override
        public String toString() {
            return "Versioned{version=" + version + ", refreshedAt=" + refreshedAt + ", value=" +
                    (value == null ? "null" : value.getClass().getSimpleName()) + "}";
        }
    }
}

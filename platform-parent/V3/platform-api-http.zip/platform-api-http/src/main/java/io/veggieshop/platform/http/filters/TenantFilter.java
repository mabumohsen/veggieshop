package io.veggieshop.platform.http.filters;

import io.veggieshop.platform.domain.error.ProblemTypes;
import io.veggieshop.platform.domain.error.VeggieException;
import io.veggieshop.platform.domain.tenant.TenantContext;
import io.veggieshop.platform.domain.tenant.TenantId;
import io.veggieshop.platform.domain.tenant.TenantResolver;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.lang.NonNull;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.*;

@Order(TenantFilter.ORDER)
public final class TenantFilter extends OncePerRequestFilter {

    /** Run early, after correlation filter. */
    public static final int ORDER = Ordered.HIGHEST_PRECEDENCE + 20;

    /** Canonical header & MDC keys (keep in sync with TenantContext). */
    public static final String HEADER_TENANT_ID = TenantContext.REQUEST_HEADER;
    public static final String DEFAULT_MDC_KEY = TenantContext.MDC_TENANT_ID;

    /** Always-allowed exact paths (error/static). */
    private static final Set<String> ALLOWLIST_EXACT = Set.of("/error", "/favicon.ico");

    /** Ant-style matcher for public paths. */
    private static final AntPathMatcher ANT = new AntPathMatcher();

    // ---------------- Dependencies & Configuration (immutable) ----------------

    private final TenantResolver tenantResolver;

    private final String headerName;
    private final boolean required;
    private final List<String> publicPaths;
    private final String mdcKey;

    /**
     * Primary constructor used by auto-configuration.
     */
    public TenantFilter(
            TenantResolver tenantResolver,
            String headerName,
            boolean required,
            List<String> publicPaths,
            String mdcKey
    ) {
        this.tenantResolver = Objects.requireNonNull(tenantResolver, "tenantResolver");
        this.headerName = (headerName == null || headerName.isBlank())
                ? HEADER_TENANT_ID : headerName.trim();
        this.required = required;
        this.publicPaths = (publicPaths == null) ? List.of() : List.copyOf(publicPaths);
        this.mdcKey = (mdcKey == null || mdcKey.isBlank()) ? DEFAULT_MDC_KEY : mdcKey.trim();
    }

    // ---------------- Filter logic ----------------

    @Override
    protected boolean shouldNotFilter(@NonNull HttpServletRequest request) {
        // CORS preflight: let it pass
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())
                && request.getHeader("Access-Control-Request-Method") != null) {
            return true;
        }
        final String path = request.getRequestURI();
        if (path == null || path.isEmpty()) return false;

        if (ALLOWLIST_EXACT.contains(path)) return true;

        // Public paths (Ant patterns) from properties
        for (String pattern : publicPaths) {
            if (ANT.match(pattern, path)) return true;
        }
        return false;
    }

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain) throws ServletException, IOException {

        // Extract first header token (proxies may join with commas)
        final String rawHeader = firstHeaderValue(request.getHeader(this.headerName));

        if ((rawHeader == null || rawHeader.isBlank())) {
            if (required) {
                throw VeggieException.builder(ProblemTypes.TENANT_REQUIRED)
                        .detail("Missing required header: " + this.headerName)
                        .captureStackTrace(false)
                        .build();
            } else {
                // Not required: just continue without setting tenant context
                filterChain.doFilter(request, response);
                return;
            }
        }

        // Validate/normalize the explicit tenant from the configured header
        final TenantId explicitTenantId;
        try {
            explicitTenantId = TenantId.of(rawHeader.trim());
        } catch (IllegalArgumentException ex) {
            throw VeggieException.builder(ProblemTypes.TENANT_UNKNOWN)
                    .detail("Invalid " + this.headerName + " value")
                    .cause(ex)
                    .captureStackTrace(false)
                    .build();
        }

        // Build a simple headers map and resolve with consistency checks across aliases
        final Map<String, String> headersMap = headersMap(request);
        final TenantId tenantId;
        try {
            TenantResolver.Resolution res = tenantResolver.resolve(
                    explicitTenantId,                  // strongest precedence (your configured header)
                    headersMap,                        // HTTP headers (case-insensitive)
                    /* jwtClaims */ null,
                    /* messageHeadersBytes */ null,
                    /* enforceConsistency */ true
            );
            tenantId = res.tenantId();
        } catch (NoSuchElementException e) {
            // Shouldn't happen because we already had an explicit header, but handle defensively
            throw VeggieException.builder(ProblemTypes.TENANT_REQUIRED)
                    .detail("Tenant could not be resolved from request")
                    .captureStackTrace(false)
                    .build();
        } catch (IllegalStateException e) {
            // Conflicting sources (e.g., multiple headers/claims disagree)
            throw VeggieException.builder(ProblemTypes.TENANT_MISMATCH)
                    .detail("Conflicting tenant identifiers provided by multiple sources")
                    .cause(e)
                    .captureStackTrace(false)
                    .build();
        }

        // Scope the request under the tenant; TenantContext handles the canonical MDC key.
        try (var ignored = TenantContext.open(tenantId)) {
            // Also put the custom MDC key if different
            if (!DEFAULT_MDC_KEY.equals(this.mdcKey)) {
                MDC.put(this.mdcKey, tenantId.value());
            }
            request.setAttribute(attrTenantId(), tenantId);

            filterChain.doFilter(request, response);
        } finally {
            request.removeAttribute(attrTenantId());
            if (!DEFAULT_MDC_KEY.equals(this.mdcKey)) {
                MDC.remove(this.mdcKey);
            }
            // TenantContext scope auto-restores MDC and clears ThreadLocal on close
        }
    }

    // ---------------- Helpers ----------------

    private static String firstHeaderValue(String raw) {
        if (raw == null) return null;
        int comma = raw.indexOf(',');
        return (comma >= 0 ? raw.substring(0, comma) : raw).trim();
    }

    private static Map<String, String> headersMap(HttpServletRequest request) {
        Map<String, String> map = new LinkedHashMap<>();
        Enumeration<String> names = request.getHeaderNames();
        if (names == null) return map;
        while (names.hasMoreElements()) {
            String name = names.nextElement();
            String value = firstHeaderValue(request.getHeader(name));
            if (value != null) {
                map.put(name, value);
            }
        }
        return map;
    }

    private static String attrTenantId() {
        return TenantFilter.class.getName() + ".TENANT_ID";
    }
}

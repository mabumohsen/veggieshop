package io.veggieshop.platform.http.error;

import io.veggieshop.platform.domain.tenant.TenantContext;
import io.veggieshop.platform.domain.tenant.TenantId;
import io.veggieshop.platform.http.filters.CorrelationIdFilter;
import io.veggieshop.platform.http.filters.PiiLogGuardFilter;
import io.veggieshop.problem.core.RequestContext;
import org.slf4j.MDC;

import jakarta.servlet.http.HttpServletRequest;
import java.util.Enumeration;
import java.util.Map;

public final class RequestContextExtractor {

    private RequestContextExtractor() {}

    @SuppressWarnings("unchecked")
    public static RequestContext from(HttpServletRequest req) {
        String method = req.getMethod();
        String path = safe(req.getRequestURI());

        String tenant = TenantContext.currentTenantId().map(TenantId::value).orElse(null);
        if (tenant == null) tenant = MDC.get(TenantContext.MDC_TENANT_ID);

        String traceId = MDC.get("traceId");
        String spanId = MDC.get("spanId");
        String requestId = MDC.get(CorrelationIdFilter.MDC_REQUEST_ID);
        String correlationId = MDC.get(CorrelationIdFilter.MDC_CORRELATION_ID);

        int headerCount = 0;
        int paramCount = 0;

        Map<String, ?> safeHeaders = (Map<String, ?>) req.getAttribute(PiiLogGuardFilter.ATTR_SANITIZED_HEADERS);
        Map<String, ?> safeParams  = (Map<String, ?>) req.getAttribute(PiiLogGuardFilter.ATTR_SANITIZED_PARAMETERS);

        if (safeHeaders != null) {
            headerCount = safeHeaders.size();
        } else {
            Enumeration<String> hn = req.getHeaderNames();
            while (hn != null && hn.hasMoreElements()) { hn.nextElement(); headerCount++; }
        }
        if (safeParams != null) {
            paramCount = safeParams.size();
        } else {
            paramCount = req.getParameterMap().size();
        }

        long ts = System.currentTimeMillis();

        return new RequestContext(method, path, tenant, traceId, spanId, requestId, correlationId, headerCount, paramCount, ts);
    }

    private static String safe(String s) {
        return (s == null || s.isBlank()) ? "/" : s;
    }
}

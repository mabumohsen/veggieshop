package io.veggieshop.platform.starter.messaging.autoconfig;

public class KafkaDefaultsConfiguration {
}

package io.veggieshop.platform.messaging.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.AuthorizationException;
import org.apache.kafka.common.errors.InvalidTopicException;
import org.apache.kafka.common.errors.RecordDeserializationException;
import org.apache.kafka.common.errors.RetriableException;
import org.apache.kafka.common.errors.UnsupportedVersionException;
import org.apache.kafka.common.header.internals.RecordHeaders;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.listener.RetryListener;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.support.serializer.DeserializationException;
import org.springframework.messaging.converter.MessageConversionException;

import org.springframework.util.backoff.BackOff;
import org.springframework.util.backoff.BackOffExecution;
import org.springframework.kafka.support.ExponentialBackOffWithMaxRetries;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.Locale;
import java.util.Optional;

import static io.veggieshop.platform.messaging.kafka.Headers.*;

/**
 * Centralized error handling for Kafka consumers.
 *
 * <p>Objectives aligned with PRD:
 * <ul>
 *   <li>Classify fatal vs transient errors; bounded retries with exponential backoff + jitter (max=3).</li>
 *   <li>Quarantine (DLQ) to <code>&lt;topic&gt;.quarantine</code> with rich evidence headers for bounded/observable replay.</li>
 *   <li>No PII in headers/logs; include only routing/diagnostic metadata.</li>
 *   <li>Preserve trace and tenant headers; attach platform envelope to DLQ records.</li>
 * </ul>
 * </p>
 */
@Configuration
public class ConsumerErrorHandler {

    private static final Logger log = LoggerFactory.getLogger(ConsumerErrorHandler.class);

    /**
     * Dead-letter recoverer that publishes failed records to "<topic>.quarantine" and enriches headers.
     */
    @Bean
    DeadLetterPublishingRecoverer quarantineRecoverer(KafkaTemplate<Object, Object> kafkaTemplate) {
        DeadLetterPublishingRecoverer recoverer = new DeadLetterPublishingRecoverer(
                kafkaTemplate,
                // Route to "<topic>.quarantine" preserving partition
                (record, ex) -> new TopicPartition(record.topic() + ".quarantine", record.partition())
        );

        // Add evidence headers to the quarantined record
        recoverer.setHeadersFunction((record, ex) -> {
            org.apache.kafka.common.header.internals.RecordHeaders h = new org.apache.kafka.common.header.internals.RecordHeaders();

            // Copy safe inbound headers (tenant/trace/schema/etc) without PII
            Headers.copy(record.headers(), h, Headers.Keys::isSafeToPropagate);

            // Compute diagnostics
            String exceptionClass = ex.getClass().getName();
            String rootClass = rootCause(ex).getClass().getName();
            String msg = safeTruncate(Optional.ofNullable(ex.getMessage()).orElse(rootClass), 512);
            String stackHash = sha256Hex(stackTraceAsString(ex));
            int attempt = deliveryAttempt(record).orElse(1);

            // Evidence headers
            Headers.put(h, "x-error-class", exceptionClass);
            Headers.put(h, "x-error-root-class", rootClass);
            Headers.put(h, "x-error-message", msg); // keep short; do not include payload fragments
            Headers.put(h, "x-error-stack-hash", stackHash);
            Headers.putInt(h, "x-retry-attempt", attempt);
            Headers.putInstant(h, "x-quarantined-at", Instant.now());

            // Attach/ensure platform envelope keys (no overwrite)
            Headers.attachEnvelope(
                    h,
                    Headers.getAsString(record.headers(), Keys.TENANT_ID).orElse(null),
                    Headers.getAsString(record.headers(), Keys.TRACE_ID).orElse(null),
                    Headers.getAsString(record.headers(), Keys.SCHEMA_FINGERPRINT).orElse(null),
                    Headers.getAsLong(record.headers(), Keys.ENTITY_VERSION).orElse(null)
            );

            // Propagate W3C trace context if present
            Headers.propagateW3CTraceContext(record.headers(), h);

            return h;
        });

        return recoverer;
    }

    /**
     * Spring Kafka error handler with bounded retries and jittered exponential backoff.
     * Non-retryable exceptions are sent immediately to the quarantine topic.
     */
    @Bean
    DefaultErrorHandler kafkaConsumerErrorHandler(DeadLetterPublishingRecoverer quarantineRecoverer) {
        // Exponential backoff with max=3 attempts (initial 250ms, multiplier 2.0, max 5s), wrapped with jitter ±20%
        ExponentialBackOffWithMaxRetries base = new ExponentialBackOffWithMaxRetries(3);
        base.setInitialInterval(250L);
        base.setMultiplier(2.0);
        base.setMaxInterval(5_000L);

        BackOff jittering = new JitteringBackOff(base, 0.2); // ±20%

        DefaultErrorHandler handler = new DefaultErrorHandler(quarantineRecoverer, jittering);

        // Classify non-retryable exceptions (fail-fast to quarantine)
        handler.addNotRetryableExceptions(
                DeserializationException.class,
                RecordDeserializationException.class,
                MessageConversionException.class,
                InvalidTopicException.class,
                AuthorizationException.class,
                UnsupportedVersionException.class
        );

        // Explicitly mark RetriableException as retryable (transient broker/network issues)
        handler.addRetryableExceptions(RetriableException.class);

        // Ensure offset is committed for recovered (DLQ) records
        handler.setCommitRecovered(true);

        // Structured attempt logging for observability (no payload)
        handler.setRetryListeners(new RetryListener() {
            @Override
            public void failedDelivery(ConsumerRecord<?, ?> record, Exception ex, int deliveryAttempt) {
                log.warn("consumer_retry_failed topic={} partition={} offset={} attempt={} errorClass={} rootClass={} traceId={}",
                        record.topic(),
                        record.partition(),
                        record.offset(),
                        deliveryAttempt,
                        ex.getClass().getName(),
                        rootCause(ex).getClass().getName(),
                        Headers.getAsString(record.headers(), Keys.TRACE_ID).orElse("-")
                );
            }
        });

        return handler;
    }

    // -----------------------------------------------------------------------------------------
    // Backoff with jitter
    // -----------------------------------------------------------------------------------------

    /**
     * BackOff wrapper that applies +/- jitter to the delegate's nextBackOff() value.
     * Helps reduce thundering herds during bursts of failures.
     */
    static final class JitteringBackOff implements BackOff {
        private final BackOff delegate;
        private final double jitter; // e.g., 0.2 means ±20%
        JitteringBackOff(BackOff delegate, double jitter) {
            this.delegate = delegate;
            this.jitter = Math.max(0.0, Math.min(jitter, 0.9));
        }
        @Override
        public BackOffExecution start() {
            BackOffExecution exec = delegate.start();
            return new BackOffExecution() {
                @Override
                public long nextBackOff() {
                    long base = exec.nextBackOff();
                    if (base == STOP) return STOP;
                    double delta = (Math.random() * 2 - 1) * jitter; // [-jitter, +jitter]
                    return Math.max(0L, Math.round(base + base * delta));
                }
            };
        }
    }

    // -----------------------------------------------------------------------------------------
    // Utilities
    // -----------------------------------------------------------------------------------------

    /** Attempt to extract Spring's delivery attempt header (kafka_deliveryAttempt). */
    private static Optional<Integer> deliveryAttempt(ConsumerRecord<?, ?> record) {
        if (record == null || record.headers() == null) return Optional.empty();
        org.apache.kafka.common.header.Header attempt = record.headers().lastHeader("kafka_deliveryAttempt");
        if (attempt == null || attempt.value() == null) return Optional.empty();
        try {
            String asText = new String(attempt.value(), StandardCharsets.UTF_8);
            return Optional.of(Integer.parseInt(asText.trim()));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    /** Return the root cause of an exception. */
    private static Throwable rootCause(Throwable ex) {
        Throwable t = ex;
        while (t.getCause() != null && t.getCause() != t) {
            t = t.getCause();
        }
        return t;
    }

    /** Truncate a string to a safe length. */
    private static String safeTruncate(String s, int max) {
        if (s == null) return null;
        if (s.length() <= max) return s;
        return s.substring(0, Math.max(0, max - 3)) + "...";
    }

    /** Compute a short hex SHA-256 of the stack trace string for grouping. */
    private static String sha256Hex(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] out = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(out.length * 2);
            for (byte b : out) sb.append(String.format(Locale.ROOT, "%02x", b));
            // Keep short (first 16 bytes -> 32 hex chars) to fit within header budgets
            return sb.substring(0, Math.min(sb.length(), 32));
        } catch (Exception e) {
            return "na";
        }
    }

    /** Convert a stack trace to string (without message to reduce PII risk). */
    private static String stackTraceAsString(Throwable t) {
        StringBuilder sb = new StringBuilder(1024);
        sb.append(t.getClass().getName()).append('\n');
        for (StackTraceElement el : t.getStackTrace()) {
            sb.append("  at ").append(el.toString()).append('\n');
            if (sb.length() > 8_192) break; // cap size
        }
        return sb.toString();
    }
}

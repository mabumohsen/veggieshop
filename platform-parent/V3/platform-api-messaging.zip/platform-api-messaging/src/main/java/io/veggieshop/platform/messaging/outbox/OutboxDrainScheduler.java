package io.veggieshop.platform.messaging.outbox;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.lang.Nullable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.Duration;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import static java.lang.Math.min;

/**
 * OutboxDrainScheduler coordinates periodic draining of the transactional outbox using {@link OutboxPublisher}.
 *
 * <h3>Why a dedicated scheduler?</h3>
 * <ul>
 *   <li>Centralized control over cadence and burst behavior per tick.</li>
 *   <li>Local non-overlap guard to avoid concurrent drains in the same JVM.</li>
 *   <li>Adaptive behavior: perform multiple consecutive {@code drainOnce()} calls
 *       within a single tick to reduce end-to-end latency when backlog exists.</li>
 *   <li>Observability-first: per-tick OpenTelemetry span and Micrometer metrics.</li>
 * </ul>
 *
 * <p><b>Cluster-safety:</b> The outbox drain uses <code>SELECT ... FOR UPDATE SKIP LOCKED</code>
 * to safely scale horizontally across pods without double-publishing. Running multiple schedulers
 * concurrently across pods is safe and recommended for throughput.</p>
 *
 * <p><b>Note:</b> If you enable this scheduler, set
 * {@code veggieshop.outbox.scheduling.enabled=false} on {@link OutboxPublisher}
 * to avoid running two independent loops.</p>
 */
@Component
public class OutboxDrainScheduler {

    private static final Logger log = LoggerFactory.getLogger(OutboxDrainScheduler.class);

    private final OutboxPublisher outboxPublisher;
    private final MeterRegistry metrics;
    private final Tracer tracer;
    private final Clock clock;
    private final JdbcTemplate jdbc;

    private final boolean enabled;
    private final int burstBatches;
    private final Duration maxBurstDuration;
    private final Duration idleSleep;
    private final boolean backlogMetricsEnabled;
    private final String outboxTable;

    // Local guard that prevents overlapping ticks in the same JVM
    private final AtomicBoolean inFlight = new AtomicBoolean(false);

    // Simple “empty-streak” heuristic to back off a bit when consistently idle
    private volatile int emptyStreak = 0;

    public OutboxDrainScheduler(OutboxPublisher outboxPublisher,
                                MeterRegistry meterRegistry,
                                Clock clock,
                                JdbcTemplate jdbc,
                                @Value("${veggieshop.outbox.scheduler.enabled:true}") boolean enabled,
                                @Value("${veggieshop.outbox.scheduler.burst-batches:3}") int burstBatches,
                                @Value("${veggieshop.outbox.scheduler.max-burst-duration:PT2S}") Duration maxBurstDuration,
                                @Value("${veggieshop.outbox.scheduler.idle-sleep:PT1S}") Duration idleSleep,
                                @Value("${veggieshop.outbox.scheduler.backlog-metrics-enabled:true}") boolean backlogMetricsEnabled,
                                @Value("${veggieshop.outbox.table:platform_outbox}") String outboxTable) {
        this.outboxPublisher = Objects.requireNonNull(outboxPublisher, "outboxPublisher");
        this.metrics = Objects.requireNonNull(meterRegistry, "meterRegistry");
        this.tracer = GlobalOpenTelemetry.get().getTracer("io.veggieshop.platform.outbox");
        this.clock = Objects.requireNonNull(clock, "clock");
        this.jdbc = Objects.requireNonNull(jdbc, "jdbc");
        this.enabled = enabled;
        this.burstBatches = burstBatches;
        this.maxBurstDuration = Objects.requireNonNull(maxBurstDuration, "maxBurstDuration");
        this.idleSleep = Objects.requireNonNull(idleSleep, "idleSleep");
        this.backlogMetricsEnabled = backlogMetricsEnabled;
        this.outboxTable = Objects.requireNonNull(outboxTable, "outboxTable");

        log.info("outbox_scheduler_init enabled={} burstBatches={} maxBurst={} idleSleep={} backlogMetricsEnabled={} table={}",
                enabled, burstBatches, maxBurstDuration, idleSleep, backlogMetricsEnabled, outboxTable);
    }

    /**
     * Main scheduler tick. Uses fixed delay for natural backpressure and performs
     * a small "burst" of drain calls when there is apparent backlog.
     *
     * <p>Cadence is configured via:
     * <ul>
     *   <li>{@code veggieshop.outbox.scheduler.interval} (fixedDelay)</li>
     *   <li>{@code veggieshop.outbox.scheduler.initial-delay}</li>
     * </ul>
     * </p>
     */
    @Scheduled(
            fixedDelayString = "${veggieshop.outbox.scheduler.interval:250}",
            initialDelayString = "${veggieshop.outbox.scheduler.initial-delay:1500}"
    )
    public void tick() {
        if (!enabled) {
            return;
        }
        if (!inFlight.compareAndSet(false, true)) {
            // Overlapping invocation on the same node; skip politely
            metrics.counter("outbox.scheduler.skipped.overlap").increment();
            return;
        }

        final long wallStart = System.nanoTime();
        final Span tick = tracer.spanBuilder("outbox.scheduler.tick")
                .setSpanKind(SpanKind.INTERNAL)
                .startSpan();

        int totalPublished = 0;
        int totalAttempts = 0;
        int loops = 0;

        try {
            // Optional: measure backlog (cheap count) to feed a gauge
            if (backlogMetricsEnabled) {
                Long backlog = estimateBacklog();
                if (backlog != null) {
                    metrics.gauge("outbox.backlog", backlog);
                    tick.setAttribute("outbox.backlog", backlog);
                }
            }

            // Perform a short burst: multiple drainOnce() within the same tick
            final long maxBurstNanos = maxBurstDuration.toNanos();
            final long burstStart = System.nanoTime();
            final int window = min(Math.max(burstBatches, 1), 20); // safety cap

            for (int i = 0; i < window; i++) {
                loops++;
                totalAttempts++;
                int published = outboxPublisher.drainOnce();
                totalPublished += published;

                // If nothing was published, we likely have no due rows → break early
                if (published == 0) {
                    break;
                }
                // Stop the burst if we exceeded the max burst wall time
                if ((System.nanoTime() - burstStart) > maxBurstNanos) {
                    break;
                }
            }

            // Idle backoff heuristic: add a small sleep when empty to ease DB pressure.
            if (totalPublished == 0) {
                emptyStreak = Math.min(emptyStreak + 1, 5);
                Duration extra = idleSleep.multipliedBy(emptyStreak);
                try {
                    // Keep it bounded to avoid excessive sleeps
                    long boundedMs = Math.min(extra.toMillis(), idleSleep.multipliedBy(5).toMillis());
                    if (boundedMs > 0) {
                        Thread.sleep(boundedMs);
                    }
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            } else {
                emptyStreak = 0;
            }

            tick.setAttribute("outbox.published", totalPublished);
            tick.setAttribute("outbox.attempts", totalAttempts);
            tick.setAttribute("outbox.loops", loops);
            tick.setStatus(StatusCode.OK);
            metrics.counter("outbox.scheduler.ticks").increment();
            metrics.counter("outbox.scheduler.published").increment(totalPublished);
            metrics.summary("outbox.scheduler.published.per.tick").record(totalPublished);

        } catch (Exception e) {
            tick.recordException(e);
            tick.setStatus(StatusCode.ERROR, safeMsg(e));
            io.micrometer.core.instrument.Counter.builder("outbox.scheduler.error")
                    .tag("class", e.getClass().getSimpleName())
                    .register(metrics)
                    .increment();
            log.warn("outbox_scheduler_tick_error class={} msg={}", e.getClass().getSimpleName(), safeMsg(e));
        } finally {
            long wallNs = System.nanoTime() - wallStart;
            metrics.timer("outbox.scheduler.tick.latency").record(wallNs, TimeUnit.NANOSECONDS);
            tick.end();
            inFlight.set(false);
        }
    }

    /**
     * Lightweight backlog estimator to power a gauge and dashboards.
     * Counts rows that are due to be processed (NEW/RETRY where next_attempt_at <= now()).
     * Never logs payload, keys, or PII.
     */
    @Nullable
    private Long estimateBacklog() {
        try {
            String sql = """
                SELECT count(*) FROM %s
                WHERE status IN ('NEW','RETRY') AND next_attempt_at <= now()
                """.formatted(outboxTable);
            return jdbc.queryForObject(sql, Long.class);
        } catch (Exception e) {
            // Swallow errors: metrics not critical to scheduling
            metrics.counter("outbox.scheduler.backlog.query_error").increment();
            return null;
        }
    }

    private static String safeMsg(Throwable t) {
        String m = t.getMessage();
        if (m == null || m.isBlank()) return t.getClass().getSimpleName();
        return m.length() > 400 ? m.substring(0, 400) + "..." : m;
    }
}

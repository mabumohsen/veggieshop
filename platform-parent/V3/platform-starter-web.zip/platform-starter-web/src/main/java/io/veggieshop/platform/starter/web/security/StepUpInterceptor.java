package io.veggieshop.platform.starter.web.security;

import io.veggieshop.platform.application.security.StepUpService;
import io.veggieshop.platform.domain.error.ProblemTypes;
import io.veggieshop.platform.domain.error.VeggieException;
import io.veggieshop.platform.domain.security.RiskLevel;
import io.veggieshop.platform.domain.tenant.TenantContext;
import io.veggieshop.platform.domain.tenant.TenantId;
import io.veggieshop.platform.http.filters.HmacAuthFilter;
import io.veggieshop.platform.http.filters.OidcJwtAuthFilter;
import io.veggieshop.platform.http.filters.TenantFilter;
import io.veggieshop.platform.http.security.RequireStepUp;
import io.veggieshop.platform.http.security.StepUpSettings;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.Ordered;
import org.springframework.lang.NonNull;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import java.time.Clock;
import java.util.*;

/**
 * Enforces "step-up" (MFA / stronger auth) for high-risk operations.
 *
 * Framework-light: no stereotypes or conditions here.
 * Register it from starter-web via WebMvcConfigurer when enabled in properties.
 */
public final class StepUpInterceptor implements HandlerInterceptor {

    /** Execute late in preHandle chain, just before controllers. */
    public static final int ORDER = Ordered.LOWEST_PRECEDENCE - 150;

    private static final String HDR_WWW_AUTHENTICATE = "WWW-Authenticate";
    private static final String HDR_STEPUP_REQUIRED  = "X-Step-Up-Required";
    private static final String HDR_STEPUP_RISK      = "X-Step-Up-Risk";
    private static final String HDR_STEPUP_MAX_AGE   = "X-Step-Up-Max-Age";
    private static final String HDR_TENANT_ID        = TenantFilter.HEADER_TENANT_ID;
    private static final String HDR_AUTHORIZATION    = "Authorization";

    private final StepUpService stepUpService;
    private final StepUpSettings settings;
    private final Clock clock;

    public StepUpInterceptor(StepUpService stepUpService, StepUpSettings settings, Clock clock) {
        this.stepUpService = Objects.requireNonNull(stepUpService, "StepUpService");
        this.settings = Objects.requireNonNull(settings, "StepUpSettings");
        this.clock = (clock == null ? Clock.systemUTC() : clock);
    }

    @Override
    public boolean preHandle(@NonNull HttpServletRequest request,
                             @NonNull HttpServletResponse response,
                             @NonNull Object handler) {

        RequireStepUp requirement = resolveRequirement(handler);
        if (requirement == null) return true;

        // --- Resolve tenant (TenantFilter should already ensure this) ---
        TenantId tenant = TenantContext.currentTenantId().orElseGet(() -> {
            String hdr = firstHeaderValue(request.getHeader(HDR_TENANT_ID));
            if (hdr == null || hdr.isBlank()) {
                throw VeggieException.builder(ProblemTypes.TENANT_REQUIRED)
                        .detail("Missing required header: " + HDR_TENANT_ID)
                        .captureStackTrace(false)
                        .build();
            }
            return TenantId.of(hdr);
        });

        // --- Resolve authenticated principal (prefer OIDC; optionally accept HMAC if configured) ---
        PrincipalView principal = principalFromRequest(request)
                .orElseThrow(() -> unauthorized(response, "Missing authenticated principal"));

        // --- Short-circuit if role/scope allow-list matches ---
        if (matchesAny(principal.roles, requirement.anyRole())
                || matchesAny(principal.scopes, requirement.anyScope())) {
            return true;
        }

        // --- Determine policy ---
        RiskLevel risk = requirement.value();
        long maxAgeSeconds = (requirement.maxAgeSeconds() > 0
                ? requirement.maxAgeSeconds()
                : settings.defaultMaxAge().getSeconds());

        // --- Satisfaction: (A) AMR+auth_time fresh OR (B) elevation present in store ---
        boolean amrSatisfied = looksLikeRecentMfa(principal.amr, principal.authTimeEpochSec, maxAgeSeconds);
        boolean elevationSatisfied = stepUpService.activeElevation(tenant.value(), principal.subject).isPresent();

        if (amrSatisfied || elevationSatisfied) return true;

        // --- Not satisfied → send hints + error ---
        attachHints(response, risk, maxAgeSeconds);
        throw VeggieException.builder(ProblemTypes.STEP_UP_REQUIRED)
                .detail("Step-up authentication is required for this operation.")
                .captureStackTrace(false)
                .build();
    }

    // ---------------------------------------------------------------------------------------------
    // Requirement resolution
    // ---------------------------------------------------------------------------------------------
    private static RequireStepUp resolveRequirement(Object handler) {
        if (handler instanceof HandlerMethod hm) {
            RequireStepUp onMethod = hm.getMethodAnnotation(RequireStepUp.class);
            return (onMethod != null ? onMethod : hm.getBeanType().getAnnotation(RequireStepUp.class));
        }
        return null;
    }

    // ---------------------------------------------------------------------------------------------
    // Principal extraction (no reflection)
    // ---------------------------------------------------------------------------------------------
    private Optional<PrincipalView> principalFromRequest(HttpServletRequest req) {
        Object oidcAttr = req.getAttribute(OidcJwtAuthFilter.REQUEST_ATTR_PRINCIPAL);
        if (oidcAttr instanceof OidcJwtAuthFilter.OidcPrincipal p) {
            return Optional.of(new PrincipalView(
                    p.subject(),
                    p.roles(),
                    p.scopes(),
                    p.amr(),
                    p.authTimeEpochSeconds().orElse(null)
            ));
        }

        Object hmacAttr = req.getAttribute(HmacAuthFilter.REQUEST_ATTR_PRINCIPAL);
        if (hmacAttr instanceof HmacAuthFilter.HmacPrincipal hp) {
            if (!settings.allowHmacPrincipals()) return Optional.empty();
            // HMAC principals rarely have AMR/auth_time → normally they cannot satisfy step-up by AMR.
            return Optional.of(new PrincipalView(
                    "hmac:" + hp.keyId(),
                    hp.roles(),
                    hp.scopes(),
                    Set.of(),
                    null
            ));
        }

        // If we got here with a Bearer header, we still consider it missing principal.
        if (req.getHeader(HDR_AUTHORIZATION) != null) {
            return Optional.empty();
        }
        return Optional.empty();
    }

    // ---------------------------------------------------------------------------------------------
    // Evaluation helpers
    // ---------------------------------------------------------------------------------------------
    private boolean looksLikeRecentMfa(Set<String> amr, Long authTimeEpochSec, long maxAgeSeconds) {
        if (amr == null || amr.isEmpty() || authTimeEpochSec == null) return false;
        boolean hasMfa = amr.stream()
                .filter(Objects::nonNull)
                .map(String::toLowerCase)
                .anyMatch(settings.mfaAmrHints()::contains);
        if (!hasMfa) return false;

        long now = clock.instant().getEpochSecond();
        long age = Math.max(0, now - authTimeEpochSec);
        return age <= maxAgeSeconds;
    }

    private static boolean matchesAny(Set<String> bag, String[] requiredAny) {
        if (bag == null || bag.isEmpty() || requiredAny == null || requiredAny.length == 0) return false;
        Set<String> lower = new HashSet<>(bag.size());
        for (String s : bag) if (s != null) lower.add(s.toLowerCase(Locale.ROOT));
        for (String r : requiredAny) {
            if (r != null && lower.contains(r.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    // ---------------------------------------------------------------------------------------------
    // HTTP utilities
    // ---------------------------------------------------------------------------------------------
    private static String firstHeaderValue(String raw) {
        if (raw == null) return null;
        int comma = raw.indexOf(',');
        return (comma >= 0 ? raw.substring(0, comma) : raw).trim();
    }

    private static VeggieException unauthorized(HttpServletResponse res, String msg) {
        // RFC 6750 doesn’t define a “step-up” code; we advertise the need via hints + 401.
        res.setHeader(HDR_WWW_AUTHENTICATE,
                "Bearer error=\"insufficient_authentication\", error_description=\"step-up required\"");
        return VeggieException.builder(ProblemTypes.AUTHENTICATION_FAILED)
                .detail(msg)
                .captureStackTrace(false)
                .build();
    }

    private static void attachHints(HttpServletResponse res, RiskLevel risk, long maxAgeSeconds) {
        res.setHeader(HDR_WWW_AUTHENTICATE,
                "Bearer error=\"insufficient_authentication\", error_description=\"step-up required\"");
        res.setHeader(HDR_STEPUP_REQUIRED, "true");
        res.setHeader(HDR_STEPUP_RISK, risk.name());
        res.setHeader(HDR_STEPUP_MAX_AGE, String.valueOf(maxAgeSeconds));
    }

    // ---------------------------------------------------------------------------------------------
    // Local view model
    // ---------------------------------------------------------------------------------------------
    private static final class PrincipalView {
        final String subject;
        final Set<String> roles;
        final Set<String> scopes;
        final Set<String> amr;
        final Long authTimeEpochSec;

        PrincipalView(String subject, Set<String> roles, Set<String> scopes, Set<String> amr, Long authTimeEpochSec) {
            this.subject = Objects.requireNonNullElse(subject, "unknown");
            this.roles = roles == null ? Set.of() : Set.copyOf(roles);
            this.scopes = scopes == null ? Set.of() : Set.copyOf(scopes);
            this.amr = amr == null ? Set.of() : Set.copyOf(amr);
            this.authTimeEpochSec = authTimeEpochSec;
        }
    }
}

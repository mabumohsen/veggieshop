package io.veggieshop.platform.application.crypto;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.DigestInputStream;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.Base64;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Enterprise-grade hashing utilities for deterministic fingerprints, request hashing, audit chains,
 * and HMACs used across the platform (e.g., idempotency request hashes, event schema fingerprints,
 * audit record chaining).
 *
 * <h3>Design notes</h3>
 * <ul>
 *   <li><b>Algorithms:</b> Defaults to modern, widely available JCA algorithms (SHA-256, SHA-512/256, SHA3-256, HMAC-SHA256/512).</li>
 *   <li><b>Thread-safety:</b> JCA {@link MessageDigest} is not thread-safe. We use per-thread instances via {@link ThreadLocal}.</li>
 *   <li><b>Determinism:</b> Helper methods for canonical JSON (sorted keys, no whitespace) to ensure stable hashes.</li>
 *   <li><b>Binary-safe framing:</b> When composing multi-part hashes, we use length-prefixed framing to avoid collisions.</li>
 *   <li><b>No secrets/PII in outputs:</b> Never log or expose raw inputs to these methods. This class only returns digests/HMACs.</li>
 *   <li><b>Passwords:</b> This is <b>not</b> a password hashing service. Use a dedicated KDF (Argon2id, scrypt, PBKDF2) elsewhere.</li>
 * </ul>
 */
@Service
public final class HashingService {

    private static final int STREAM_BUFFER = 16 * 1024;

    // Dedicated mapper for canonical JSON hashing (independent of global ObjectMapper).
    private static final ObjectMapper CANONICAL_JSON = new ObjectMapper()
            .enable(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS)
            .disable(SerializationFeature.INDENT_OUTPUT);

    private final EnumMap<HashAlgorithm, ThreadLocal<MessageDigest>> digests =
            new EnumMap<>(HashAlgorithm.class);

    public HashingService() {
        // Verify and warm up available digests per algorithm once.
        for (HashAlgorithm alg : HashAlgorithm.values()) {
            digests.put(alg, ThreadLocal.withInitial(() -> newDigest(alg.jcaName)));
        }
    }

    // ------------------------------------------------------------------------
    // Public API — Message digests
    // ------------------------------------------------------------------------

    /**
     * Compute a digest of the given bytes.
     */
    public byte[] digest(@NotNull byte[] input, @NotNull HashAlgorithm alg) {
        Objects.requireNonNull(input, "input");
        Objects.requireNonNull(alg, "alg");
        final MessageDigest md = digests.get(alg).get();
        md.reset();
        return md.digest(input);
    }

    /**
     * Compute a digest of the given string after Unicode normalization (NFKC).
     * This helps reduce canonicalization differences across clients.
     */
    public byte[] digest(@NotNull String input, @NotNull HashAlgorithm alg) {
        Objects.requireNonNull(input, "input");
        final String norm = Normalizer.normalize(input, Normalizer.Form.NFKC);
        return digest(norm.getBytes(StandardCharsets.UTF_8), alg);
    }

    /**
     * Streaming digest for large payloads.
     */
    public byte[] digest(@NotNull InputStream in, @NotNull HashAlgorithm alg) throws IOException {
        Objects.requireNonNull(in, "in");
        final MessageDigest md = digests.get(alg).get();
        md.reset();
        try (DigestInputStream dis = new DigestInputStream(in, md)) {
            dis.skipNBytes(0); // no-op, ensures stream is wired
            final byte[] buf = new byte[STREAM_BUFFER];
            while (dis.read(buf) != -1) {
                // no-op; DigestInputStream updates the digest
            }
        }
        return md.digest();
    }

    /**
     * Compute a "scheme:hex" fingerprint (e.g., {@code sha256:deadbeef...}) commonly used in headers.
     */
    public String fingerprintHex(@NotNull byte[] input, @NotNull HashAlgorithm alg) {
        return alg.scheme + ":" + HexFormat.of().formatHex(digest(input, alg));
    }

    /**
     * Compute a Base64-encoded digest (URL-safe if requested).
     */
    public String digestBase64(@NotNull byte[] input, @NotNull HashAlgorithm alg, boolean urlSafe) {
        final byte[] d = digest(input, alg);
        return (urlSafe ? Base64.getUrlEncoder().withoutPadding() : Base64.getEncoder()).encodeToString(d);
    }

    // ------------------------------------------------------------------------
    // Public API — HMAC
    // ------------------------------------------------------------------------

    /**
     * Compute HMAC for the given message using the provided secret key bytes.
     */
    public byte[] hmac(@NotNull byte[] secretKey, @NotNull byte[] message, @NotNull HmacAlgorithm alg) {
        Objects.requireNonNull(secretKey, "secretKey");
        Objects.requireNonNull(message, "message");
        Objects.requireNonNull(alg, "alg");
        try {
            final Mac mac = Mac.getInstance(alg.jcaName);
            mac.init(new SecretKeySpec(secretKey, alg.jcaName));
            return mac.doFinal(message);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("HMAC algorithm not available: " + alg.jcaName, e);
        }
    }

    public String hmacHex(@NotNull byte[] secretKey, @NotNull byte[] message, @NotNull HmacAlgorithm alg) {
        return HexFormat.of().formatHex(hmac(secretKey, message, alg));
    }

    public String hmacBase64(@NotNull byte[] secretKey, @NotNull byte[] message, @NotNull HmacAlgorithm alg, boolean urlSafe) {
        final byte[] mac = hmac(secretKey, message, alg);
        return (urlSafe ? Base64.getUrlEncoder().withoutPadding() : Base64.getEncoder()).encodeToString(mac);
    }

    // ------------------------------------------------------------------------
    // Public API — Canonical JSON hashing
    // ------------------------------------------------------------------------

    /**
     * Compute a stable digest for an arbitrary JSON-serializable value using canonical JSON (sorted keys, UTF-8).
     * Useful for schema fingerprints, quote/pricing snapshots, etc.
     */
    public byte[] digestCanonicalJson(@NotNull Object value, @NotNull HashAlgorithm alg) {
        try {
            final byte[] canonical = CANONICAL_JSON.writeValueAsBytes(value);
            return digest(canonical, alg);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Failed to serialize value to canonical JSON", e);
        }
    }

    /**
     * Compute a stable "request hash" for idempotency: method + path + selected headers + body digest,
     * all length-prefixed to avoid collisions. Header names are canonicalized to lower-case and sorted.
     * <p>IMPORTANT: Do not pass any PII headers or secrets here; prefer non-sensitive, semantic headers only.</p>
     */
    public byte[] computeRequestHash(
            @NotBlank String httpMethod,
            @NotBlank String path,
            @NotNull Map<String, String> selectedHeaders,
            @NotNull byte[] body,
            @NotNull HashAlgorithm alg
    ) {
        final Map<String, String> canonicalHeaders = new LinkedHashMap<>();
        selectedHeaders.entrySet().stream()
                .sorted(Comparator.comparing(e -> e.getKey().toLowerCase()))
                .forEach(e -> canonicalHeaders.put(e.getKey().toLowerCase(), e.getValue() == null ? "" : e.getValue()));

        final byte[] methodBytes = Normalizer.normalize(httpMethod.trim(), Normalizer.Form.NFKC)
                .getBytes(StandardCharsets.UTF_8);
        final byte[] pathBytes = Normalizer.normalize(path, Normalizer.Form.NFKC)
                .getBytes(StandardCharsets.UTF_8);
        final byte[] headersBytes = canonicalHeaders.toString().getBytes(StandardCharsets.UTF_8); // stable due to ordering

        final byte[] framed = frame(methodBytes, pathBytes, headersBytes, body);
        return digest(framed, alg);
    }

    // ------------------------------------------------------------------------
    // Public API — Audit chain helpers
    // ------------------------------------------------------------------------

    /**
     * Chain an audit hash H = Hash( len(prev) | prev | len(payload) | payload ).
     * The previous hash must be the raw digest bytes of the prior record (not hex).
     */
    public byte[] chainAudit(@NotNull byte[] previousHashOrEmpty, @NotNull byte[] payload, @NotNull HashAlgorithm alg) {
        final byte[] framed = frame(previousHashOrEmpty, payload);
        return digest(framed, alg);
    }

    /**
     * Chain using hex-encoded previous hash (convenience).
     */
    public byte[] chainAuditHex(@NotNull String previousHashHexOrEmpty, @NotNull byte[] payload, @NotNull HashAlgorithm alg) {
        final byte[] prev = previousHashHexOrEmpty.isBlank()
                ? new byte[0]
                : HexFormat.of().parseHex(previousHashHexOrEmpty);
        return chainAudit(prev, payload, alg);
    }

    // ------------------------------------------------------------------------
    // Public API — Utilities
    // ------------------------------------------------------------------------

    /**
     * Constant-time comparison to prevent timing attacks when comparing MACs/digests.
     */
    public boolean constantTimeEquals(@NotNull byte[] a, @NotNull byte[] b) {
        if (a.length != b.length) return false;
        int result = 0;
        for (int i = 0; i < a.length; i++) {
            result |= (a[i] ^ b[i]);
        }
        return result == 0;
    }

    /**
     * Parse a "scheme:hex" fingerprint and validate the scheme matches the provided algorithm.
     */
    public byte[] parseFingerprint(@NotBlank String fingerprint, @NotNull HashAlgorithm expectedAlg) {
        final int idx = fingerprint.indexOf(':');
        if (idx <= 0) throw new IllegalArgumentException("Invalid fingerprint (missing scheme): " + fingerprint);
        final String scheme = fingerprint.substring(0, idx);
        if (!scheme.equalsIgnoreCase(expectedAlg.scheme)) {
            throw new IllegalArgumentException("Unexpected scheme: " + scheme + " (expected " + expectedAlg.scheme + ")");
        }
        final String hex = fingerprint.substring(idx + 1);
        return HexFormat.of().parseHex(hex);
    }

    public String toHex(@NotNull byte[] bytes) {
        return HexFormat.of().formatHex(bytes);
    }

    public String toBase64(@NotNull byte[] bytes, boolean urlSafe) {
        return (urlSafe ? Base64.getUrlEncoder().withoutPadding() : Base64.getEncoder()).encodeToString(bytes);
    }

    // ------------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------------

    private static MessageDigest newDigest(String jcaName) {
        try {
            return MessageDigest.getInstance(jcaName);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Digest algorithm not available: " + jcaName, e);
        }
    }

    /**
     * Length-prefixed framing for collision-safe composition: [len(x1)][x1][len(x2)][x2]...
     */
    private static byte[] frame(byte[]... parts) {
        int size = 0;
        for (byte[] p : parts) size += 4 + p.length;
        final ByteBuffer buf = ByteBuffer.allocate(size);
        for (byte[] p : parts) {
            buf.putInt(p.length);
            buf.put(p);
        }
        return buf.array();
    }

    // ------------------------------------------------------------------------
    // Enums
    // ------------------------------------------------------------------------

    /**
     * Supported message-digest algorithms.
     */
    public enum HashAlgorithm {
        SHA_256("sha256", "SHA-256"),
        SHA_512_256("sha512-256", "SHA-512/256"),
        SHA3_256("sha3-256", "SHA3-256");

        public final String scheme;   // lowercase name used in "scheme:hex" fingerprints
        public final String jcaName;  // JCA standard name

        HashAlgorithm(String scheme, String jcaName) {
            this.scheme = scheme;
            this.jcaName = jcaName;
        }
    }

    /**
     * Supported HMAC algorithms.
     */
    public enum HmacAlgorithm {
        HMAC_SHA256("HmacSHA256"),
        HMAC_SHA512("HmacSHA512");

        public final String jcaName;

        HmacAlgorithm(String jcaName) {
            this.jcaName = jcaName;
        }
    }
}

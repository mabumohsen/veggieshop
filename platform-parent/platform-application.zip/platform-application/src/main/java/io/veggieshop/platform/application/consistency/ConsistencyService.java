package io.veggieshop.platform.application.consistency;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * ConsistencyService centralizes "read-your-writes" semantics for the platform.
 *
 * <h3>What this provides</h3>
 * <ul>
 *   <li>Generates response headers: <b>ETag</b> and <b>X-Consistency-Token</b>.</li>
 *   <li>Parses request headers: <b>If-Consistent-With</b> and (optional) prior <b>X-Consistency-Token</b>.</li>
 *   <li>Decides whether a caller should <b>fallback to OLTP</b> (bypass projections/caches) based on
 *       version expectations and a bounded fallback window (default ≤ 60s).</li>
 *   <li>Protects tokens with HMAC (kid + rotating secret) and enforces anti-tamper validation.</li>
 *   <li>Thread-local request context to be consulted by repository/search layers.</li>
 * </ul>
 *
 * <p><b>Token format (compact, signed):</b>
 * <pre>vct1:&lt;kid&gt;:&lt;base64url( JSON { t, a, i, v, iat, exp } )&gt;:&lt;base64url( HMAC-SHA256(payload) )&gt;</pre>
 * Where:
 * <ul>
 *   <li><code>t</code> tenantId</li>
 *   <li><code>a</code> aggregate type (e.g., "order", "cart")</li>
 *   <li><code>i</code> aggregate id</li>
 *   <li><code>v</code> entity version (long)</li>
 *   <li><code>iat</code> issued-at epoch seconds</li>
 *   <li><code>exp</code> expiry epoch seconds (= iat + window)</li>
 * </ul>
 *
 * <p><b>ETag convention:</b> strong tag <code>"v{version}"</code> (e.g., <code>"v42"</code>).</p>
 *
 * <p>Usage flow:
 * <ol>
 *   <li>On mutate (POST/PATCH): compute entity version → return ETag + new consistency token.</li>
 *   <li>On read: call {@link #openRequest(String, String, String)} at boundary (e.g., web layer) to
 *       capture If-Consistent-With/Token, then consult {@link #shouldFallbackToOltp(long, Instant)} in the
 *       repository/search layer to decide whether to bypass projections.</li>
 * </ol>
 */
public class ConsistencyService {

    private static final Logger log = LoggerFactory.getLogger(ConsistencyService.class);

    private static final String TOKEN_VERSION = "vct1";
    private static final Base64.Encoder B64URL_ENC = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder B64URL_DEC = Base64.getUrlDecoder();
    private static final String HMAC_ALG = "HmacSHA256";

    private final Clock clock;
    private final Props props;
    private final TokenSigner signer;

    /** Per-request context holder. Cleared by the web boundary after the request completes. */
    private static final ThreadLocal<ConsistencyContext> CTX = new ThreadLocal<>();

    public ConsistencyService(Clock clock, Props props) {
        this(clock, props, new DefaultTokenSigner(props));
    }

    ConsistencyService(Clock clock, Props props, TokenSigner signer) {
        this.clock = Objects.requireNonNull(clock, "clock");
        this.props = Objects.requireNonNull(props, "props");
        this.signer = Objects.requireNonNull(signer, "signer");
    }

    // ------------------------------------------------------------------------------------------------
    // Request lifecycle
    // ------------------------------------------------------------------------------------------------

    /**
     * Parse inbound headers and establish a thread-local consistency context.
     *
     * @param tenantId            required tenant id (from auth)
     * @param ifConsistentWith    header value like "v42" or "42" (nullable)
     * @param priorConsistencyTok optional X-Consistency-Token sent back by the client (nullable)
     * @return active context (also stored in ThreadLocal)
     */
    public ConsistencyContext openRequest(
            @NotBlank String tenantId,
            String ifConsistentWith,
            String priorConsistencyTok
    ) {
        Long expectedVersion = parseExpectedVersion(ifConsistentWith).orElse(null);
        ParsedToken token = parseAndValidateToken(priorConsistencyTok).orElse(null);

        ConsistencyContext ctx = new ConsistencyContext(tenantId, expectedVersion, token);
        CTX.set(ctx);

        if (log.isDebugEnabled()) {
            log.debug("ConsistencyContext opened: tenant={}, expectedVersion={}, token={}{}",
                    safe(tenantId), expectedVersion, token != null ? token.summary() : "<none>",
                    (token != null && token.isExpired(clock.instant())) ? " (expired)" : "");
        }
        return ctx;
    }

    /** Clear thread-local context (call at the end of request). */
    public void clear() {
        CTX.remove();
    }

    /** Get current request context, if present. */
    public Optional<ConsistencyContext> context() {
        return Optional.ofNullable(CTX.get());
    }

    // ------------------------------------------------------------------------------------------------
    // Response helpers
    // ------------------------------------------------------------------------------------------------

    /** Build ETag header value for a concrete entity version (strong validator). */
    public String etagFor(long version) {
        return "\"v" + version + "\"";
    }

    /**
     * Issue a new X-Consistency-Token to the caller, binding tenant + aggregate identity + version.
     * Typically used together with {@link #etagFor(long)} on mutation responses.
     */
    public String newToken(
            @NotBlank String tenantId,
            @NotBlank String aggregateType,
            @NotBlank String aggregateId,
            long entityVersion
    ) {
        Instant now = clock.instant();
        long iat = now.getEpochSecond();
        long exp = now.plusSeconds(props.window().toSeconds()).getEpochSecond();

        String kid = props.kid();
        String payloadJson = "{\"t\":\"" + json(tenantId) + "\","
                + "\"a\":\"" + json(aggregateType) + "\","
                + "\"i\":\"" + json(aggregateId) + "\","
                + "\"v\":" + entityVersion + ","
                + "\"iat\":" + iat + ","
                + "\"exp\":" + exp + "}";

        String payloadB64 = B64URL_ENC.encodeToString(payloadJson.getBytes(StandardCharsets.UTF_8));
        String sigB64 = B64URL_ENC.encodeToString(signer.hmac(kid, payloadB64.getBytes(StandardCharsets.US_ASCII)));
        return TOKEN_VERSION + ":" + kid + ":" + payloadB64 + ":" + sigB64;
    }

    /** Convenience: minimal map of response headers to attach. */
    public Map<String, String> responseHeaders(
            @NotBlank String tenantId,
            @NotBlank String aggregateType,
            @NotBlank String aggregateId,
            long entityVersion
    ) {
        return Map.of(
                "ETag", etagFor(entityVersion),
                "X-Consistency-Token", newToken(tenantId, aggregateType, aggregateId, entityVersion),
                "X-Entity-Version", "v" + entityVersion
        );
    }

    // ------------------------------------------------------------------------------------------------
    // Decision helpers for repositories/search layers
    // ------------------------------------------------------------------------------------------------

    /**
     * Whether the currently served read should bypass projections/caches
     * and fallback to OLTP (source-of-truth) to honor read-your-writes.
     *
     * <p>Heuristics (all must be true for fallback):</p>
     * <ul>
     *   <li>A client expectation exists (If-Consistent-With or a valid token claims a higher version).</li>
     *   <li>Projection/version is behind that expectation.</li>
     *   <li>We are still within the configured fallback window (token not expired).</li>
     * </ul>
     *
     * @param currentProjectionVersion the version number available in the projection/index (or -1 if unknown)
     * @param projectionRefreshedAt    when the projection was last refreshed for this aggregate (nullable)
     */
    public boolean shouldFallbackToOltp(long currentProjectionVersion, Instant projectionRefreshedAt) {
        ConsistencyContext ctx = CTX.get();
        if (ctx == null) return false;

        long expected = ctx.expectedVersionOrElse(-1L);

        // If the explicit header is missing but a token is present, use token's version.
        if (expected < 0 && ctx.token() != null) {
            expected = ctx.token().version();
        }

        if (expected < 0) return false; // No expectation — projection is acceptable.

        // Refuse OLTP if outside fallback window.
        if (ctx.token() != null && ctx.token().isExpired(clock.instant())) {
            return false;
        }

        // Projection is stale if its version is lower than expected.
        boolean versionBehind = currentProjectionVersion < expected;

        // Optional: add staleness guard if the projection hasn't been refreshed since token issuance.
        boolean timeBehind = ctx.token() != null
                && projectionRefreshedAt != null
                && projectionRefreshedAt.isBefore(ctx.token().issuedAt());

        return versionBehind || timeBehind;
    }

    /**
     * Whether the server can assert the read is consistent with the client's stated expectation.
     * Returns true if:
     * <ul>
     *   <li>No expectation was provided, or</li>
     *   <li>Expectation (If-Consistent-With) ≤ current authoritative version.</li>
     * </ul>
     */
    public boolean isConsistentWithClient(long authoritativeVersion) {
        ConsistencyContext ctx = CTX.get();
        if (ctx == null) return true;
        Long expected = ctx.expectedVersion();
        return expected == null || expected <= authoritativeVersion;
    }

    // ------------------------------------------------------------------------------------------------
    // Parsing & validation
    // ------------------------------------------------------------------------------------------------

    private Optional<Long> parseExpectedVersion(String header) {
        if (header == null || header.isBlank()) return Optional.empty();
        String h = header.trim();
        // Accept "v42", "\"v42\"", or plain "42"
        if (h.startsWith("\"") && h.endsWith("\"")) {
            h = h.substring(1, h.length() - 1);
        }
        if (h.startsWith("v") || h.startsWith("V")) {
            h = h.substring(1);
        }
        try {
            long v = Long.parseLong(h);
            return v >= 0 ? Optional.of(v) : Optional.empty();
        } catch (NumberFormatException ex) {
            log.warn("Invalid If-Consistent-With header value (ignored)");
            return Optional.empty();
        }
    }

    private Optional<ParsedToken> parseAndValidateToken(String token) {
        if (token == null || token.isBlank()) return Optional.empty();
        try {
            String[] parts = token.split(":", 4);
            if (parts.length != 4 || !TOKEN_VERSION.equals(parts[0])) {
                log.debug("Unsupported consistency token format");
                return Optional.empty();
            }
            String kid = parts[1];
            String payloadB64 = parts[2];
            String sigB64 = parts[3];

            byte[] expectedSig = signer.hmac(kid, payloadB64.getBytes(StandardCharsets.US_ASCII));
            byte[] providedSig = B64URL_DEC.decode(sigB64);

            if (!constantTimeEquals(expectedSig, providedSig)) {
                log.warn("Consistency token signature mismatch (kid={})", kid);
                return Optional.empty();
            }

            String json = new String(B64URL_DEC.decode(payloadB64), StandardCharsets.UTF_8);
            ParsedToken parsed = ParsedToken.fromJson(json, kid);
            return Optional.of(parsed);
        } catch (Exception e) {
            log.warn("Failed to parse/validate consistency token (ignored): {}", e.getMessage());
            return Optional.empty();
        }
    }

    // ------------------------------------------------------------------------------------------------
    // Utilities
    // ------------------------------------------------------------------------------------------------

    private static boolean constantTimeEquals(byte[] a, byte[] b) {
        if (a == null || b == null || a.length != b.length) return false;
        int r = 0;
        for (int i = 0; i < a.length; i++) r |= (a[i] ^ b[i]);
        return r == 0;
    }

    private static String json(String s) {
        // Minimal JSON string escape for quotes and backslashes.
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private static String safe(String s) {
        // Redact most of the token/tenant in logs; keep last 4 chars if available.
        if (s == null) return "<null>";
        if (s.length() <= 4) return "****";
        return "****" + s.substring(s.length() - 4);
    }

    // =================================================================================================
    // Context & token models
    // =================================================================================================

    /**
     * Request-scoped consistency context derived from incoming headers.
     */
    public static final class ConsistencyContext {
        private final String tenantId;
        private final Long expectedVersion;
        private final ParsedToken token;

        ConsistencyContext(String tenantId, Long expectedVersion, ParsedToken token) {
            this.tenantId = tenantId;
            this.expectedVersion = expectedVersion;
            this.token = token;
        }

        public String tenantId() { return tenantId; }
        public Long expectedVersion() { return expectedVersion; }
        public ParsedToken token() { return token; }

        long expectedVersionOrElse(long fallback) { return expectedVersion != null ? expectedVersion : fallback; }

        @Override public String toString() {
            return "ConsistencyContext{tenant=" + safe(tenantId)
                    + ", expected=" + expectedVersion
                    + ", token=" + (token != null ? token.summary() : "<none>") + "}";
        }
    }

    /**
     * Parsed and validated token payload.
     */
    static final class ParsedToken {
        private final String version;        // token envelope version (e.g., vct1)
        private final String kid;
        private final String tenantId;
        private final String aggregateType;
        private final String aggregateId;
        private final long entityVersion;
        private final Instant issuedAt;
        private final Instant expiresAt;

        ParsedToken(String version, String kid, String tenantId, String aggregateType, String aggregateId,
                    long entityVersion, Instant issuedAt, Instant expiresAt) {
            this.version = version;
            this.kid = kid;
            this.tenantId = tenantId;
            this.aggregateType = aggregateType;
            this.aggregateId = aggregateId;
            this.entityVersion = entityVersion;
            this.issuedAt = issuedAt;
            this.expiresAt = expiresAt;
        }

        static ParsedToken fromJson(String json, String kid) {
            // Extremely small, dependency-free JSON extraction (inputs are controlled by our own generator).
            String t = get(json, "t");
            String a = get(json, "a");
            String i = get(json, "i");
            long v = Long.parseLong(get(json, "v"));
            long iat = Long.parseLong(get(json, "iat"));
            long exp = Long.parseLong(get(json, "exp"));
            return new ParsedToken(TOKEN_VERSION, kid, t, a, i, v, Instant.ofEpochSecond(iat), Instant.ofEpochSecond(exp));
        }

        private static String get(String json, String key) {
            // Looks for "key":value in a flat JSON object; values may be quoted or numeric.
            String p = "\"" + key + "\":";
            int idx = json.indexOf(p);
            if (idx < 0) throw new IllegalArgumentException("Missing field: " + key);
            int start = idx + p.length();
            char c = json.charAt(start);
            if (c == '"') {
                int end = json.indexOf('"', start + 1);
                if (end < 0) throw new IllegalArgumentException("Unterminated string for: " + key);
                String raw = json.substring(start + 1, end);
                return raw.replace("\\\"", "\"").replace("\\\\", "\\");
            } else {
                // numeric
                int end = start;
                while (end < json.length() && "-0123456789".indexOf(json.charAt(end)) >= 0) end++;
                return json.substring(start, end);
            }
        }

        public long version() { return entityVersion; }
        public Instant issuedAt() { return issuedAt; }
        public boolean isExpired(Instant now) { return now.isAfter(expiresAt); }

        public String summary() {
            return "{kid=" + kid + ", agg=" + aggregateType + "#" + safe(aggregateId) + ", v=" + entityVersion + "}";
        }
    }

    // =================================================================================================
    // Signing
    // =================================================================================================

    interface TokenSigner {
        byte[] hmac(@NotBlank String kid, @NotNull byte[] payload);
    }

    static final class DefaultTokenSigner implements TokenSigner {
        private final Props props;

        DefaultTokenSigner(Props props) {
            this.props = props;
        }

        @Override
        public byte[] hmac(String kid, byte[] payload) {
            try {
                Assert.isTrue(kid.equals(props.kid()), "Unknown KID");
                SecretKeySpec key = new SecretKeySpec(props.secret(), "HmacSHA256");
                Mac mac = Mac.getInstance(HMAC_ALG);
                mac.init(key);
                return mac.doFinal(payload);
            } catch (GeneralSecurityException e) {
                throw new IllegalStateException("HMAC failure", e);
            }
        }
    }

    // =================================================================================================
    // Configuration properties
    // =================================================================================================

    /**
     * Configuration for consistency semantics.
     *
     * <p>Example (application.yaml):</p>
     * <pre>
     * veggieshop:
     *   consistency:
     *     window: 60s
     *     kid: consistency-2025-01
     *     secretBase64: AbCdEf... (32+ bytes recommended)
     * </pre>
     */
    @Configuration
    public static class Props {
        /**
         * Fallback window during which OLTP reads are allowed to satisfy read-your-writes.
         * Defaults to 60 seconds per PRD.
         */
        private Duration window = Duration.ofSeconds(60);

        /** Current signing key id for tokens (rotatable). */
        private String kid = "consistency-default";

        /** Base64-encoded HMAC secret (≥ 32 bytes). */
        private String secretBase64;

        public Duration window() { return window; }
        public void setWindow(Duration window) { this.window = window; }

        public String kid() { return kid; }
        public void setKid(String kid) { this.kid = kid; }

        public String secretBase64() { return secretBase64; }
        public void setSecretBase64(String secretBase64) { this.secretBase64 = secretBase64; }

        byte[] secret() {
            Assert.hasText(secretBase64, "veggieshop.consistency.secretBase64 must be configured");
            return Base64.getDecoder().decode(secretBase64);
        }
    }
}

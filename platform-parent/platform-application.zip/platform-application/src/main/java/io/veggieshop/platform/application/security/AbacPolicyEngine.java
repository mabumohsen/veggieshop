package io.veggieshop.platform.application.security;

import io.micrometer.core.instrument.MeterRegistry;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.util.*;

/**
 * ABAC (Attribute-Based Access Control) policy engine for VeggieShop.
 *
 * <p>This engine centralizes coarse RBAC gates with fine-grained, attribute-based policies
 * that reflect the PRD requirements:
 *
 * <ul>
 *   <li>Strict tenant isolation (subject.tenantId == resource.tenantId).</li>
 *   <li>Vendor ownership enforcement for vendor-scoped resources.</li>
 *   <li>Sensitivity- and risk-aware rules (PII/Confidential/Restricted).</li>
 *   <li>Step-up MFA and two-person approval for high-risk admin actions.</li>
 *   <li>Explainable decisions with obligations for callers (e.g., perform step-up MFA).</li>
 * </ul>
 *
 * <p>The engine is deterministic, side-effect free, and safe for use on virtual threads.
 * All configuration defaults are conservative and align with "fail-closed" semantics on
 * sensitive data paths.</p>
 */
@Service
public class AbacPolicyEngine {

    private static final Logger log = LoggerFactory.getLogger(AbacPolicyEngine.class);

    private final MeterRegistry metrics;
    private final Clock clock;
    private final AbacDefaults defaults;

    public AbacPolicyEngine(MeterRegistry metrics, Clock clock) {
        this(metrics, clock, AbacDefaults.strict());
    }

    public AbacPolicyEngine(MeterRegistry metrics, Clock clock, AbacDefaults defaults) {
        this.metrics = Objects.requireNonNull(metrics, "metrics");
        this.clock = Objects.requireNonNull(clock, "clock");
        this.defaults = Objects.requireNonNull(defaults, "defaults");
    }

    /**
     * Evaluate a request and return an authorization decision.
     *
     * <p>The decision includes an {@link Effect} and optional {@link Obligation}s that
     * the caller must satisfy before retrying (e.g., require strong MFA, require a
     * second approver).</p>
     */
    public Decision authorize(@NotNull Request req) {
        Objects.requireNonNull(req, "req");
        final Instant now = clock.instant();

        // ---- 0) Basic sanity / tenant isolation --------------------------------------------
        if (isBlank(req.tenantId()) || isBlank(req.subject().tenantId())) {
            return deny("Missing tenant context");
        }
        if (!req.tenantId().equals(req.subject().tenantId())) {
            // Hard deny on tenant mismatch regardless of roles/elevation.
            return deny("Tenant mismatch");
        }
        if (req.resource() != null && !req.tenantId().equals(req.resource().tenantId())) {
            return deny("Resource not in caller tenant");
        }

        // ---- 1) Coarse RBAC allowlist (mandatory baseline) --------------------------------
        if (!isRolePermittedForAction(req.subject().roles(), req.action())) {
            return deny("RBAC does not permit action " + req.action());
        }

        // ---- 2) Vendor ownership (for non-admin callers) -----------------------------------
        if (!req.subject().roles().contains(Role.ADMIN)
                && req.resource() != null
                && req.resource().vendorOwnerId().isPresent()) {

            String owner = req.resource().vendorOwnerId().get();
            String callerVendor = req.subject().vendorId().orElse("<none>");
            if (!owner.equals(callerVendor)) {
                return deny("Vendor ownership required");
            }
        }

        // ---- 3) Sensitivity gating ----------------------------------------------------------
        Sensitivity sensitivity = Optional.ofNullable(req.resource())
                .map(Resource::sensitivity)
                .orElse(Sensitivity.INTERNAL);

        // Restricted PII: ADMIN only + strong MFA + (for some actions) two-person approval.
        if (sensitivity == Sensitivity.RESTRICTED_PII) {
            if (!req.subject().roles().contains(Role.ADMIN)) {
                return deny("Restricted PII requires ADMIN role");
            }
            if (!hasStrongMfa(req.subject(), now)) {
                return challenge(Obligation.requireMfa("strong"), "Strong MFA required for restricted PII");
            }
        }

        // Confidential data: SUPPORT and ADMIN can read; writes require ADMIN with strong MFA.
        if (sensitivity == Sensitivity.CONFIDENTIAL && isWrite(req.action())) {
            if (!req.subject().roles().contains(Role.ADMIN)) {
                return deny("Confidential writes require ADMIN");
            }
            if (!hasStrongMfa(req.subject(), now)) {
                return challenge(Obligation.requireMfa("strong"), "Strong MFA required for confidential writes");
            }
        }

        // ---- 4) Action risk gates (step-up MFA / two-person approval) ----------------------
        Risk risk = defaults.riskOf(req.action());
        if (risk != Risk.LOW) {
            // Medium+ always requires at least "strong" MFA unless emergency break-glass is set.
            if (!req.environment().breakGlass()
                    && !hasStrongMfa(req.subject(), now)) {
                return challenge(Obligation.requireMfa("strong"), "Step-up MFA required for " + risk + " risk");
            }
        }

        if (risk == Risk.HIGH) {
            // High risk requires ADMIN + two-person approval, unless break-glass.
            if (!req.subject().roles().contains(Role.ADMIN)) {
                return deny("High-risk action requires ADMIN");
            }
            if (!req.environment().breakGlass()) {
                if (!req.environment().secondApprover().isPresent()) {
                    return challenge(Obligation.requireTwoPerson(), "Second approver required");
                }
                // Basic anti-self-approval guard
                if (req.environment().secondApprover().get().equals(req.subject().userId())) {
                    return deny("Second approver must differ from requester");
                }
            }
        }

        // ---- 5) Environment risk escalation (e.g., anomalous IP, off-hours) ----------------
        if (req.environment().riskScore() >= defaults.environmentRiskMfaThreshold()
                && !req.environment().breakGlass()
                && !hasStrongMfa(req.subject(), now)) {
            return challenge(Obligation.requireMfa("strong"), "Environment risk requires step-up MFA");
        }

        // ---- 6) Time-bounded just-in-time elevation ----------------------------------------
        if (requiresElevation(req.action())) {
            if (!hasValidElevation(req.subject(), now)) {
                return challenge(Obligation.requireElevation(defaults.minElevationMinutes()),
                        "Just-in-time elevation required");
            }
        }

        // ---- 7) Support role is read-only except tickets/notes -----------------------------
        if (req.subject().roles().contains(Role.SUPPORT) && isWrite(req.action())) {
            return deny("Support role is read-only");
        }

        // Permit. Record metrics and return an explainable permit.
        metrics.counter("abac.permit", "action", req.action().name(), "sensitivity", sensitivity.name()).increment();
        return Decision.permit("Permit by ABAC policy");
    }

    // =========================================================================================
    // RBAC baseline
    // =========================================================================================
    private boolean isRolePermittedForAction(Set<Role> roles, Action action) {
        if (roles.contains(Role.ADMIN)) return true;

        return switch (action) {
            case READ -> roles.stream().anyMatch(r -> r == Role.BUYER || r == Role.VENDOR || r == Role.SUPPORT);
            case CREATE, UPDATE -> roles.contains(Role.VENDOR);
            case DELETE -> false; // Delete is privileged: ADMIN only
            case APPROVE_PRICE_OVERRIDE, MANAGE_SECRETS, EXPORT_PII, MANAGE_TENANT_CONFIG -> false; // ADMIN only
        };
    }

    private static boolean isWrite(Action action) {
        return action == Action.CREATE || action == Action.UPDATE || action == Action.DELETE
                || action == Action.APPROVE_PRICE_OVERRIDE
                || action == Action.MANAGE_SECRETS
                || action == Action.EXPORT_PII
                || action == Action.MANAGE_TENANT_CONFIG;
    }

    private static boolean requiresElevation(Action action) {
        // JIT elevation for operations that change security posture or money movement risk.
        return action == Action.MANAGE_SECRETS
                || action == Action.MANAGE_TENANT_CONFIG
                || action == Action.APPROVE_PRICE_OVERRIDE;
    }

    private static boolean hasStrongMfa(Subject s, Instant now) {
        return s.mfaLevel() == MfaLevel.STRONG
                || (s.elevationUntil().isPresent() && s.elevationUntil().get().isAfter(now));
    }

    private static boolean hasValidElevation(Subject s, Instant now) {
        return s.elevationUntil().isPresent() && s.elevationUntil().get().isAfter(now);
    }

    // =========================================================================================
    // Outcomes
    // =========================================================================================
    private Decision deny(String reason) {
        metrics.counter("abac.deny").increment();
        log.debug("ABAC DENY: {}", reason);
        return Decision.deny(reason);
    }

    private Decision challenge(Obligation obligation, String reason) {
        metrics.counter("abac.challenge", "obligation", obligation.type().name()).increment();
        log.debug("ABAC CHALLENGE: {} (obligation={})", reason, obligation);
        return Decision.challenge(reason, Set.of(obligation));
    }

    private static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    // =========================================================================================
    // Types (records/enums) kept local for single-class portability
    // =========================================================================================

    /** Authorization decision effect. */
    public enum Effect { PERMIT, DENY, CHALLENGE }

    /** Risk classification for actions. */
    public enum Risk { LOW, MEDIUM, HIGH }

    /** Resource sensitivity aligned with PRD. */
    public enum Sensitivity { PUBLIC, INTERNAL, CONFIDENTIAL, RESTRICTED_PII }

    /** Coarse RBAC roles. */
    public enum Role { BUYER, VENDOR, ADMIN, SUPPORT }

    /** Supported actions; extend as needed per bounded context. */
    public enum Action {
        READ,
        CREATE,
        UPDATE,
        DELETE,
        APPROVE_PRICE_OVERRIDE,
        MANAGE_SECRETS,
        EXPORT_PII,
        MANAGE_TENANT_CONFIG
    }

    /** MFA levels understood by the engine. */
    public enum MfaLevel { NONE, WEAK, STRONG }

    /** Caller context (subject). */
    public record Subject(
            @NotBlank String userId,
            @NotBlank String tenantId,
            Set<Role> roles,
            Optional<String> vendorId,
            MfaLevel mfaLevel,
            Optional<Instant> elevationUntil // JIT elevation expiry (step-up window)
    ) {
        public Subject {
            roles = roles == null ? Set.of() : Set.copyOf(roles);
            vendorId = vendorId == null ? Optional.empty() : vendorId;
            elevationUntil = elevationUntil == null ? Optional.empty() : elevationUntil;
        }
    }

    /** Resource attributes relevant for ABAC. */
    public record Resource(
            @NotBlank String tenantId,
            Optional<String> vendorOwnerId,
            @NotNull Sensitivity sensitivity,
            String resourceType // free-form (e.g., product, price, order, secret)
    ) {
        public Resource {
            vendorOwnerId = vendorOwnerId == null ? Optional.empty() : vendorOwnerId;
            sensitivity = sensitivity == null ? Sensitivity.INTERNAL : sensitivity;
        }
    }

    /** Environment attributes for risk-aware decisions. */
    public record Environment(
            int riskScore,                    // 0..100 (aggregated risk from device/IP/geo anomalies)
            boolean breakGlass,               // emergency override (still audited)
            Optional<String> secondApprover   // userId of second approver when required
    ) {
        public Environment {
            secondApprover = secondApprover == null ? Optional.empty() : secondApprover;
            riskScore = Math.max(0, Math.min(100, riskScore));
        }
    }

    /** ABAC evaluation request. */
    public record Request(
            @NotBlank String tenantId,
            @NotNull Subject subject,
            @NotNull Action action,
            Resource resource,
            @NotNull Environment environment
    ) {}

    /** Obligation returned with CHALLENGE effect. */
    public record Obligation(Type type, Map<String, String> params) {
        public enum Type { REQUIRE_MFA, REQUIRE_TWO_PERSON, REQUIRE_ELEVATION }
        public static Obligation requireMfa(String strength) {
            return new Obligation(Type.REQUIRE_MFA, Map.of("strength", strength));
        }
        public static Obligation requireTwoPerson() {
            return new Obligation(Type.REQUIRE_TWO_PERSON, Map.of());
        }
        public static Obligation requireElevation(int minutes) {
            return new Obligation(Type.REQUIRE_ELEVATION, Map.of("minDurationMinutes", String.valueOf(minutes)));
        }
    }

    /** Authorization decision with optional obligations. */
    public record Decision(
            @NotNull Effect effect,
            @NotNull String reason,
            Set<Obligation> obligations
    ) {
        public static Decision permit(String reason) {
            return new Decision(Effect.PERMIT, reason, Set.of());
        }
        public static Decision deny(String reason) {
            return new Decision(Effect.DENY, reason, Set.of());
        }
        public static Decision challenge(String reason, Set<Obligation> obligations) {
            return new Decision(Effect.CHALLENGE, reason, obligations == null ? Set.of() : Set.copyOf(obligations));
        }
    }

    /**
     * Default policy knobs. In a real deployment these can be bound with
     * {@code @ConfigurationProperties("security.abac")} and refreshed dynamically.
     */
    public record AbacDefaults(
            int environmentRiskMfaThreshold, // riskScore >= threshold → require strong MFA
            Map<Action, Risk> actionRiskMap,
            int minElevationMinutes
    ) {
        public static AbacDefaults strict() {
            Map<Action, Risk> map = new EnumMap<>(Action.class);
            map.put(Action.READ, Risk.LOW);
            map.put(Action.CREATE, Risk.MEDIUM);
            map.put(Action.UPDATE, Risk.MEDIUM);
            map.put(Action.DELETE, Risk.HIGH);
            map.put(Action.APPROVE_PRICE_OVERRIDE, Risk.HIGH);
            map.put(Action.MANAGE_SECRETS, Risk.HIGH);
            map.put(Action.EXPORT_PII, Risk.HIGH);
            map.put(Action.MANAGE_TENANT_CONFIG, Risk.HIGH);
            return new AbacDefaults(60, Map.copyOf(map), 15);
        }

        public Risk riskOf(Action action) {
            return actionRiskMap.getOrDefault(action, Risk.MEDIUM);
        }
    }
}

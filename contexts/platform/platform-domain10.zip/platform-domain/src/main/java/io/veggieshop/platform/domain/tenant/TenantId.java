package io.veggieshop.platform.domain.tenant;

import java.io.Serial;
import java.io.Serializable;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * TenantId
 *
 * <p>Enterprise-grade value object representing a VeggieShop tenant identifier.</p>
 *
 * <h2>Principles (aligned with PRD v2.0)</h2>
 * <ul>
 *   <li><b>Stable across layers:</b> Safe for use in HTTP headers (X-Tenant-Id), Kafka headers, Postgres schema suffixes,
 *       Redis prefixes, and OpenSearch index names.</li>
 *   <li><b>Strict invariants:</b> Lowercase ASCII, digits and hyphen only; must start/end with alphanumeric; length 3..63.</li>
 *   <li><b>Immutable & comparable:</b> Implements {@link Comparable} and {@link Serializable}; normalization on construction.</li>
 *   <li><b>No framework coupling:</b> Pure domain type (no Spring/JPA/Jackson annotations). Adapters live in infrastructure.</li>
 * </ul>
 *
 * <h3>Allowed format</h3>
 * <pre>
 *   ^[a-z0-9](?:[a-z0-9-]*[a-z0-9])$     // 3..63 chars, lowercase letters, digits, single hyphens (no leading/trailing '-')
 *   No consecutive "--"                   // avoid awkward path/index tokens
 * </pre>
 *
 * <h3>Usage</h3>
 * <pre>{@code
 * TenantId tid = TenantId.of("acme-market");       // normalized & validated
 * String header = tid.value();                      // "acme-market"
 * }</pre>
 */
public record TenantId(String value) implements Comparable<TenantId>, Serializable {

    @Serial private static final long serialVersionUID = 1L;

    /** Minimum and maximum lengths chosen to be safe for DNS-like/index/schema tokens. */
    public static final int MIN_LENGTH = 3;
    public static final int MAX_LENGTH = 63;

    /** Strict pattern: lowercase alnum with internal hyphens, no leading/trailing hyphen. */
    private static final Pattern ALLOWED = Pattern.compile("^[a-z0-9](?:[a-z0-9-]*[a-z0-9])$");

    /**
     * Compact canonical constructor: normalizes and validates the identifier.
     *
     * @throws IllegalArgumentException if the identifier is null/blank or violates invariants
     */
    public TenantId {
        Objects.requireNonNull(value, "tenantId must not be null");
        String normalized = normalize(value);
        if (!isValid(normalized)) {
            throw new IllegalArgumentException("Invalid tenantId: '%s' (must match %s, length %d..%d, no \"--\")"
                    .formatted(value, ALLOWED.pattern(), MIN_LENGTH, MAX_LENGTH));
        }
        value = normalized; // assign the normalized value to the record component
    }

    // ------------------------------------------------------------------------------------------------
    // Factories
    // ------------------------------------------------------------------------------------------------

    /**
     * Create a {@link TenantId} after normalization/validation.
     */
    public static TenantId of(String raw) {
        return new TenantId(raw);
    }

    /**
     * Attempt to parse; returns empty if invalid.
     */
    public static Optional<TenantId> tryParse(String raw) {
        if (raw == null) return Optional.empty();
        String normalized = normalize(raw);
        return isValid(normalized) ? Optional.of(new TenantId(normalized)) : Optional.empty();
    }

    // ------------------------------------------------------------------------------------------------
    // Validation & normalization
    // ------------------------------------------------------------------------------------------------

    /**
     * Normalize input: trim + lowercase (Locale.ROOT).
     */
    private static String normalize(String raw) {
        return raw.trim().toLowerCase(Locale.ROOT);
    }

    /**
     * Public predicate for adapters/guards.
     */
    public static boolean isValid(String candidate) {
        if (candidate == null) return false;
        int len = candidate.length();
        if (len < MIN_LENGTH || len > MAX_LENGTH) return false;
        if (!ALLOWED.matcher(candidate).matches()) return false;
        // Defensive: disallow consecutive "--" (helps readability in URIs/index names).
        if (candidate.contains("--")) return false;
        return true;
    }

    // ------------------------------------------------------------------------------------------------
    // Utilities
    // ------------------------------------------------------------------------------------------------

    /**
     * Short obfuscated form suitable for logs where tenant enumeration risk should be reduced.
     * This is not PII, but can be useful to keep logs tidy during high-volume traces.
     */
    public String obfuscated() {
        int len = value.length();
        if (len <= 5) return "***";
        return value.substring(0, 3) + "…" + value.substring(len - 2);
    }

    @Override
    public int compareTo(TenantId other) {
        return this.value.compareTo(other.value);
    }

    /**
     * For logs, the raw value is safe and intentional (no PII). Keep toString minimal.
     */
    @Override
    public String toString() {
        return value;
    }
}

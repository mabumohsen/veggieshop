// module: platform-starter-application
package io.veggieshop.platform.starter.application.autoconfig;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.core.instrument.MeterRegistry;
import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Tracer;
import io.veggieshop.platform.application.consistency.ConsistencyService;
import io.veggieshop.platform.application.consistency.ReadYourWritesGuard;
import io.veggieshop.platform.application.pii.PiiVaultClient;
import io.veggieshop.platform.application.security.AbacDefaults;
import io.veggieshop.platform.application.security.AbacPolicyEngine;
import io.veggieshop.platform.infrastructure.pii.PiiVaultJdbcAdapter;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.*;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.Clock;

@AutoConfiguration
@EnableConfigurationProperties(VeggiePiiVaultProperties.class)
public class PiiVaultAutoConfiguration {

    @Bean @ConditionalOnMissingBean
    Clock appClock(){ return Clock.systemUTC(); }

    @Bean
    @ConditionalOnMissingBean
    AbacPolicyEngine abacPolicyEngine(MeterRegistry metrics,
                                      Clock clock,
                                      ObjectProvider<AbacDefaults> defaultsProvider) {
        AbacDefaults defaults = defaultsProvider.getIfAvailable(AbacDefaults::strict);
        return new AbacPolicyEngine(metrics, clock, defaults);
    }

    @Bean
    @ConditionalOnMissingBean
    AbacDefaults abacDefaults() {
        return AbacDefaults.strict();
    }

    @Bean
    @ConditionalOnMissingBean
    ReadYourWritesGuard readYourWritesGuard(ConsistencyService consistency,
                                            MeterRegistry metrics,
                                            Clock clock) {
        return new ReadYourWritesGuard(consistency, metrics, clock);
    }

    @Bean @ConditionalOnMissingBean
    Tracer piiTracer(){ return GlobalOpenTelemetry.get().getTracer("io.veggieshop.platform.pii"); }

    @Bean
    @ConditionalOnMissingBean(PiiVaultClient.PiiVaultPort.class)
    @ConditionalOnClass(JdbcTemplate.class)
    PiiVaultClient.PiiVaultPort piiVaultPort(JdbcTemplate jdbc,
                                             VeggiePiiVaultProperties props,
                                             ObjectMapper om,
                                             ObjectProvider<MeterRegistry> meters) {
        return new PiiVaultJdbcAdapter(jdbc, props, meters.getIfAvailable(), om);
    }

    @Bean @ConditionalOnMissingBean
    PiiVaultClient piiVaultClient(PiiVaultClient.PiiVaultPort port,
                                  AbacPolicyEngine abac,
                                  ReadYourWritesGuard ryw,
                                  Tracer tracer,
                                  Clock clock) {
        return new PiiVaultClient(port, abac, ryw, tracer, clock);
    }
}

package io.veggieshop.platform.application.consistency;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public interface TokenSigner {
    byte[] hmac(@NotBlank String kid, @NotNull byte[] payload);
}

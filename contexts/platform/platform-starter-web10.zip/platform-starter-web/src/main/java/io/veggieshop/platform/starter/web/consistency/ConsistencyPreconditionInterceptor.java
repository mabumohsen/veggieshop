package io.veggieshop.platform.starter.web.consistency;

import io.veggieshop.platform.application.consistency.ConsistencyService;
import io.veggieshop.platform.domain.error.ProblemTypes;
import io.veggieshop.platform.domain.error.VeggieException;
import io.veggieshop.platform.domain.tenant.TenantResolver;
import io.veggieshop.platform.domain.tenant.TenantId;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.lang.NonNull;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.*;

@Order(ConsistencyPreconditionInterceptor.ORDER)
public final class ConsistencyPreconditionInterceptor implements HandlerInterceptor {

    public static final int ORDER = Ordered.LOWEST_PRECEDENCE - 200;

    public static final String HDR_IF_CONSISTENT_WITH = "If-Consistent-With";
    public static final String HDR_IF_MATCH          = "If-Match";
    public static final String HDR_TENANT_ID         = "X-Tenant-Id";
    public static final String HDR_CONSISTENCY_TOKEN = "X-Consistency-Token";

    public static final String ATTR_IF_CONSISTENT_WITH =
            ConsistencyHeadersInterceptor.ATTR_IF_CONSISTENT_WITH;
    public static final String ATTR_FALLBACK_DEADLINE_EPOCH_MS =
            ConsistencyHeadersInterceptor.ATTR_FALLBACK_DEADLINE_EPOCH_MS;
    public static final String ATTR_IF_MATCH_RAW =
            ConsistencyPreconditionInterceptor.class.getName() + ".IF_MATCH_RAW";

    private static final Set<String> ALLOWLIST_PREFIXES = Set.of("/actuator", "/internal", "/_internal");
    private static final Set<String> ALLOWLIST_EXACT    = Set.of("/error", "/favicon.ico");

    private final ConsistencyService consistency;
    private final VeggieConsistencyProperties props;

    public ConsistencyPreconditionInterceptor(ConsistencyService consistency,
                                              VeggieConsistencyProperties props) {
        this.consistency = Objects.requireNonNull(consistency, "ConsistencyService is required");
        this.props = Objects.requireNonNull(props, "VeggieConsistencyProperties is required");
    }

    @Override
    public boolean preHandle(@NonNull HttpServletRequest request,
                             @NonNull HttpServletResponse response,
                             @NonNull Object handler) {

        if (shouldBypass(request)) {
            return true;
        }

        // حلّ التينانت من الهيدرز (وإلا نرمي TENANT_REQUIRED)
        Map<String, String> headers = headersMap(request);
        TenantId tenantId = TenantResolver.resolve(null, new HashMap<>(headers), null, null, false).tenantId();

        final String method  = request.getMethod();
        final boolean isRead = ("GET".equals(method) || "HEAD".equals(method));
        final boolean isWrite = ("POST".equals(method) || "PUT".equals(method) ||
                "PATCH".equals(method) || "DELETE".equals(method));

        final String ifConsistentWith = trimOrNull(request.getHeader(HDR_IF_CONSISTENT_WITH));
        final String priorToken       = trimOrNull(request.getHeader(HDR_CONSISTENCY_TOKEN));

        // افتح سياق الاتساق للطلب
        consistency.openRequest(tenantId.value(), ifConsistentWith, priorToken);

        // نافذة fallback
        if (isRead && ifConsistentWith != null) {
            request.setAttribute(ATTR_IF_CONSISTENT_WITH, ifConsistentWith);
            long deadlineMs = System.currentTimeMillis() + (props.getFallbackWindowSeconds() * 1000L);
            request.setAttribute(ATTR_FALLBACK_DEADLINE_EPOCH_MS, deadlineMs);
        }

        // ETag precondition للكتابة
        if (isWrite) {
            final String ifMatch = trimOrNull(request.getHeader(HDR_IF_MATCH));
            if (ifMatch != null) {
                request.setAttribute(ATTR_IF_MATCH_RAW, ifMatch);
            }
        }

        return true;
    }

    private static boolean shouldBypass(HttpServletRequest request) {
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())
                && request.getHeader("Access-Control-Request-Method") != null) {
            return true;
        }
        String path = request.getRequestURI();
        if (path == null || path.isEmpty()) return false;
        if (ALLOWLIST_EXACT.contains(path)) return true;
        for (String p : ALLOWLIST_PREFIXES) if (path.startsWith(p)) return true;
        return false;
    }

    private static String trimOrNull(String s) { return (s == null) ? null : s.trim(); }

    private static Map<String, String> headersMap(HttpServletRequest req) {
        Map<String, String> map = new HashMap<>();
        for (Enumeration<String> e = req.getHeaderNames(); e != null && e.hasMoreElements();) {
            String name = e.nextElement();
            String value = req.getHeader(name);
            if (value != null) map.put(name, value);
        }
        return map;
    }
}

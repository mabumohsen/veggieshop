package io.veggieshop.platform.starter.web.consistency;

import io.veggieshop.platform.application.consistency.ConsistencyService;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * Auto-config for consistency (headers + preconditions + stamping).
 */
@AutoConfiguration
@EnableConfigurationProperties(VeggieConsistencyProperties.class)
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnClass(WebMvcConfigurer.class)
@ConditionalOnProperty(prefix = "veggieshop.web.consistency", name = "enabled",
        havingValue = "true", matchIfMissing = true)
public class ConsistencyWebAutoConfiguration {

    // --- Interceptors/Advice beans -----------------------------------------

    @Bean
    @ConditionalOnMissingBean
    public ConsistencyHeadersInterceptor consistencyHeadersInterceptor(VeggieConsistencyProperties props) {
        return new ConsistencyHeadersInterceptor(
                props.getIfConsistentWithHeader(),
                props.getWindow()
        );
    }

    @Bean
    @ConditionalOnMissingBean
    public ResponseBodyAdvice<Object> consistencyStampingAdvice(
            ConsistencyService consistency, VeggieConsistencyProperties props) {
        return new ETagResponseAdvice(consistency, props);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(prefix = "veggieshop.web.consistency", name = "preconditions-enabled",
            havingValue = "true", matchIfMissing = true)
    public ConsistencyPreconditionInterceptor consistencyPreconditionInterceptor(
            ConsistencyService consistency, VeggieConsistencyProperties props) {
        return new ConsistencyPreconditionInterceptor(consistency, props);
    }

    // --- MVC registration (orders) -----------------------------------------

    @Bean
    public WebMvcConfigurer consistencyMvcConfigurer(
            ConsistencyHeadersInterceptor headersInterceptor,
            org.springframework.beans.factory.ObjectProvider<ConsistencyPreconditionInterceptor> preconditionProvider) {

        return new WebMvcConfigurer() {
            @Override public void addInterceptors(InterceptorRegistry registry) {
                registry.addInterceptor(headersInterceptor).order(Ordered.HIGHEST_PRECEDENCE + 20);
                ConsistencyPreconditionInterceptor pre = preconditionProvider.getIfAvailable();
                if (pre != null) {
                    registry.addInterceptor(pre).order(Ordered.HIGHEST_PRECEDENCE + 30);
                }
            }
        };
    }
}

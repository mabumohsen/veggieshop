package io.veggieshop.platform.starter.web.consistency;

import jakarta.validation.constraints.NotNull;
import java.time.Duration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties(prefix = "veggieshop.web.consistency")
public class VeggieConsistencyProperties {

    private boolean enabled = true;
    private boolean addVary = true;

    @NotNull
    private String ifConsistentWithHeader = "If-Consistent-With";

    @NotNull
    private Duration window = Duration.ofSeconds(60);

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public boolean isAddVary() { return addVary; }
    public void setAddVary(boolean addVary) { this.addVary = addVary; }

    public String getIfConsistentWithHeader() { return ifConsistentWithHeader; }
    public void setIfConsistentWithHeader(String ifConsistentWithHeader) { this.ifConsistentWithHeader = ifConsistentWithHeader; }

    public Duration getWindow() { return window; }
    public void setWindow(Duration window) { this.window = window; }

    /** سugar للمنديات التي تحتاج قيمة بالثواني */
    public long getFallbackWindowSeconds() { return window.toSeconds(); }
}

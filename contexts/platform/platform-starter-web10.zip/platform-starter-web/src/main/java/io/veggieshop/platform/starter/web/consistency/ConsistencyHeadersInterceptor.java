package io.veggieshop.platform.starter.web.consistency;

import io.veggieshop.platform.domain.tenant.TenantResolver;
import io.veggieshop.platform.domain.tenant.TenantId;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.time.Duration;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;

public final class ConsistencyHeadersInterceptor implements HandlerInterceptor {

    public static final String ATTR_TENANT_ID = "veggieshop.tenantId";
    public static final String ATTR_IF_CONSISTENT_WITH = "veggieshop.consistency.ifConsistentWith";
    public static final String ATTR_WINDOW = "veggieshop.consistency.window";
    public static final String ATTR_FALLBACK_DEADLINE_EPOCH_MS = "veggieshop.consistency.fallbackDeadlineEpochMs";

    private static final Logger log = LoggerFactory.getLogger(ConsistencyHeadersInterceptor.class);

    private final String ifConsistentWithHeader;
    private final Duration window;

    public ConsistencyHeadersInterceptor(String ifConsistentWithHeader, Duration window) {
        this.ifConsistentWithHeader = ifConsistentWithHeader;
        this.window = window;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // حلّ التينانت من هيدرز HTTP باستخدام دومين Resolver (static)
        Map<String, String> headers = headersMap(request);
        TenantResolver.resolveFromHttpHeaders(new HashMap<>(headers)) // Map<String, ?>
                .map(TenantResolver.Resolution::tenantId)
                .map(TenantId::value)
                .ifPresent(t -> request.setAttribute(ATTR_TENANT_ID, t));

        String ifConsistentWith = headerTrimmed(request, ifConsistentWithHeader);
        if (ifConsistentWith != null) {
            request.setAttribute(ATTR_IF_CONSISTENT_WITH, ifConsistentWith);
        }
        request.setAttribute(ATTR_WINDOW, window);
        return true;
    }

    private static String headerTrimmed(HttpServletRequest req, String name) {
        String v = req.getHeader(name);
        if (v == null) return null;
        v = v.trim();
        return v.isEmpty() ? null : v;
    }

    private static Map<String, String> headersMap(HttpServletRequest req) {
        Map<String, String> map = new HashMap<>();
        for (Enumeration<String> e = req.getHeaderNames(); e != null && e.hasMoreElements();) {
            String name = e.nextElement();
            String value = req.getHeader(name);
            if (value != null) map.put(name, value);
        }
        return map;
    }
}
